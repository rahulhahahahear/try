<?php
/**
 * Test of Bubu 💗 - Admin API: Update Questions & Options
 * POST /api/admin-update-questions.php
 * Body JSON: { admin_password, quiz_id, questions: [ { id, question_text, options: [ { id, option_text, option_emoji, is_correct } ] } ] }
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/security.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

$rawInput = file_get_contents('php://input');
$data     = json_decode($rawInput, true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid JSON input.']);
    exit;
}

// --- Admin Auth ---
$adminPass = trim($data['admin_password'] ?? '');
if (!defined('ADMIN_PASSWORD') || $adminPass !== ADMIN_PASSWORD || $adminPass === '') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Invalid admin password.']);
    exit;
}

$quizId    = (int)($data['quiz_id'] ?? 0);
$questions = $data['questions'] ?? [];

if ($quizId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid quiz ID.']);
    exit;
}

if (!is_array($questions) || count($questions) === 0) {
    echo json_encode(['success' => false, 'error' => 'No questions provided.']);
    exit;
}

$db = getDb();

// Verify quiz exists
$stmtCheck = $db->prepare("SELECT id FROM quizzes WHERE id = :id AND deleted_at IS NULL LIMIT 1");
$stmtCheck->execute(['id' => $quizId]);
if (!$stmtCheck->fetch()) {
    echo json_encode(['success' => false, 'error' => 'Quiz not found.']);
    exit;
}

$db->beginTransaction();
try {
    $stmtUpdateQ   = $db->prepare("UPDATE questions SET question_text = :text WHERE id = :id AND quiz_id = :quiz_id");
    $stmtUpdateOpt = $db->prepare("UPDATE options SET option_text = :text, option_emoji = :emoji, is_correct = :correct WHERE id = :id AND question_id = :qid");

    foreach ($questions as $qi => $q) {
        $qId   = (int)($q['id'] ?? 0);
        $qText = trim($q['question_text'] ?? '');

        if ($qId <= 0 || $qText === '') {
            throw new Exception("Question " . ($qi + 1) . " is invalid.");
        }

        $stmtUpdateQ->execute(['text' => $qText, 'id' => $qId, 'quiz_id' => $quizId]);

        $options     = $q['options'] ?? [];
        $correctCount = 0;

        foreach ($options as $opt) {
            if (!empty($opt['is_correct'])) {
                $correctCount++;
            }
        }

        if ($correctCount !== 1) {
            throw new Exception("Question " . ($qi + 1) . " must have exactly one correct answer.");
        }

        foreach ($options as $oi => $opt) {
            $optId    = (int)($opt['id'] ?? 0);
            $optText  = trim($opt['option_text'] ?? '');
            $optEmoji = trim($opt['option_emoji'] ?? '');
            $isCorrect = !empty($opt['is_correct']) ? 1 : 0;

            if ($optId <= 0 || $optText === '') {
                throw new Exception("Option " . chr(65 + $oi) . " in Question " . ($qi + 1) . " is invalid.");
            }

            $stmtUpdateOpt->execute([
                'text'    => $optText,
                'emoji'   => $optEmoji !== '' ? $optEmoji : null,
                'correct' => $isCorrect,
                'id'      => $optId,
                'qid'     => $qId
            ]);
        }
    }

    $db->commit();
    echo json_encode(['success' => true, 'message' => 'Quiz questions & options updated successfully! 💗']);
} catch (Exception $e) {
    $db->rollBack();
    error_log("Admin update questions error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

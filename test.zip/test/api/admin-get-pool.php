<?php
/**
 * Test of Bubu 💗 - Admin API: Get Default Question Pool
 * GET /api/admin-get-pool.php?admin_password=X
 * Returns the current pool (override JSON if exists, else hardcoded defaults)
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/question-pool.php';

$adminPass = trim($_GET['admin_password'] ?? '');
if (!defined('ADMIN_PASSWORD') || $adminPass !== ADMIN_PASSWORD || $adminPass === '') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Invalid admin password.']);
    exit;
}

$pool = getMasterQuestionPool();
echo json_encode(['success' => true, 'pool' => $pool]);

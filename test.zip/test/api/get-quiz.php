<?php
/**
 * Test of Bubu 💗 - API: Get Quiz
 * GET /api/get-quiz.php?code=XYZ
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

$code = trim($_GET['code'] ?? '');
if ($code === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Missing quiz code.']);
    exit;
}

$quiz = findQuizWithQuestions($code, false); // false = never include correct answers!

if (!$quiz) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => "Hmm... we couldn't find this Bubu test. Check the link and try again! 💗"]);
    exit;
}

if ($quiz['status'] === 'expired' || strtotime($quiz['expires_at']) <= time()) {
    http_response_code(410); // 410 Gone
    echo json_encode([
        'success'    => false, 
        'error'      => 'This quiz link has expired. Ask your person to make a fresh one! 🫠💗',
        'is_expired' => true
    ]);
    exit;
}

if ($quiz['status'] !== 'active') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'This quiz is currently unavailable.']);
    exit;
}

// Clean response: remove creator_token_hash and internal ids
unset($quiz['creator_token_hash'], $quiz['deleted_at']);

echo json_encode([
    'success' => true,
    'quiz'    => $quiz
]);

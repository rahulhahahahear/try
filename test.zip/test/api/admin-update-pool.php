<?php
/**
 * Test of Bubu 💗 - Admin API: Update Default Question Pool
 * POST /api/admin-update-pool.php
 * Body JSON: { admin_password, pool: [ { id, question_text, category, options: [ { id, text, emoji, image } ] } ] }
 * Saves to config/question_pool.json
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/question-pool.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

$rawInput = file_get_contents('php://input');
$data     = json_decode($rawInput, true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid JSON input.']);
    exit;
}

// --- Auth ---
$adminPass = trim($data['admin_password'] ?? '');
if (!defined('ADMIN_PASSWORD') || $adminPass !== ADMIN_PASSWORD || $adminPass === '') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Invalid admin password.']);
    exit;
}

$pool = $data['pool'] ?? [];

if (!is_array($pool) || count($pool) !== 10) {
    echo json_encode(['success' => false, 'error' => 'Pool must have exactly 10 questions.']);
    exit;
}

// Validate and sanitize each question and its options
$defaults = getDefaultQuestionPool();
$sanitized = [];

foreach ($pool as $qi => $q) {
    $qNum     = $qi + 1;
    $qText    = trim($q['question_text'] ?? '');
    $category = trim($q['category'] ?? ($defaults[$qi]['category'] ?? 'general'));
    $qId      = (int)($q['id'] ?? ($qi + 1));

    if ($qText === '') {
        echo json_encode(['success' => false, 'error' => "Question {$qNum} text cannot be empty."]);
        exit;
    }

    $options = $q['options'] ?? [];

    if (!is_array($options) || count($options) < 2) {
        echo json_encode(['success' => false, 'error' => "Question {$qNum} must have at least 2 options."]);
        exit;
    }

    // Preserve up to 8 options
    $sanitizedOpts = [];
    foreach ($options as $oi => $opt) {
        $optText  = trim($opt['text'] ?? '');
        $optEmoji = trim($opt['emoji'] ?? '');
        $optImage = trim($opt['image'] ?? ($defaults[$qi]['options'][$oi]['image'] ?? ''));
        $optId    = (int)($opt['id'] ?? ($oi + 1));

        if ($optText === '') {
            echo json_encode(['success' => false, 'error' => "Option " . chr(65 + $oi) . " in Question {$qNum} cannot be empty."]);
            exit;
        }

        $sanitizedOpts[] = [
            'id'    => $optId,
            'text'  => $optText,
            'emoji' => $optEmoji,
            'image' => $optImage,
        ];
    }

    $sanitized[] = [
        'id'            => $qId,
        'question_text' => $qText,
        'category'      => $category,
        'options'       => $sanitizedOpts,
    ];
}

// Write to config/question_pool.json
$savePath = __DIR__ . '/../config/question_pool.json';
$jsonOut  = json_encode($sanitized, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

if (file_put_contents($savePath, $jsonOut) === false) {
    echo json_encode(['success' => false, 'error' => 'Failed to write question pool file. Check folder permissions.']);
    exit;
}

echo json_encode(['success' => true, 'message' => 'Default question pool updated successfully! 💗 New quizzes will use these questions.']);

<?php
/**
 * Test of Bubu 💗 - Admin API: Get Quiz (with correct answers)
 * GET /api/admin-get-quiz.php?quiz_id=X&admin_password=Y
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/security.php';

$adminPass = trim($_GET['admin_password'] ?? '');
if (!defined('ADMIN_PASSWORD') || $adminPass !== ADMIN_PASSWORD || $adminPass === '') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Invalid admin password.']);
    exit;
}

$quizId = (int)($_GET['quiz_id'] ?? 0);
if ($quizId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid quiz ID.']);
    exit;
}

$db = getDb();

$stmtQuiz = $db->prepare("SELECT id, public_code, creator_nickname, quiz_title, status, created_at, expires_at FROM quizzes WHERE id = :id AND deleted_at IS NULL LIMIT 1");
$stmtQuiz->execute(['id' => $quizId]);
$quiz = $stmtQuiz->fetch();

if (!$quiz) {
    echo json_encode(['success' => false, 'error' => 'Quiz not found.']);
    exit;
}

$stmtQ = $db->prepare("SELECT id, question_text, question_order FROM questions WHERE quiz_id = :qid ORDER BY question_order ASC");
$stmtQ->execute(['qid' => $quizId]);
$questions = $stmtQ->fetchAll();

$questionIds = array_column($questions, 'id');
$optsByQ = [];

if (!empty($questionIds)) {
    $inQuery = implode(',', array_fill(0, count($questionIds), '?'));
    $stmtOpts = $db->prepare("SELECT id, question_id, option_text, option_emoji, is_correct, option_order FROM options WHERE question_id IN ({$inQuery}) ORDER BY option_order ASC");
    $stmtOpts->execute($questionIds);
    $allOpts = $stmtOpts->fetchAll();
    foreach ($allOpts as $opt) {
        $optsByQ[$opt['question_id']][] = $opt;
    }
}

foreach ($questions as &$q) {
    $q['options'] = $optsByQ[$q['id']] ?? [];
}
unset($q);

$quiz['questions'] = $questions;

echo json_encode(['success' => true, 'quiz' => $quiz]);

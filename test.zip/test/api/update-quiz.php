<?php
/**
 * Test of Bubu 💗 - API: Update Quiz Settings (Creator Protected)
 * POST /api/update-quiz.php
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/security.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid JSON input.']);
    exit;
}

$code  = trim($data['public_code'] ?? '');
$token = trim($data['creator_token'] ?? '');

if ($code === '' || $token === '') {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized: Creator credentials required.']);
    exit;
}

$quiz = findQuizForCreator($code, $token);
if (!$quiz) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Invalid creator authorization token.']);
    exit;
}

$db = getDb();
$updates = [];
$params = ['id' => $quiz['id']];

if (isset($data['allow_repeat_attempts'])) {
    $updates[] = 'allow_repeat_attempts = :allow_repeat';
    $params['allow_repeat'] = !empty($data['allow_repeat_attempts']) ? 1 : 0;
}

if (isset($data['reveal_detailed_answers'])) {
    $updates[] = 'reveal_detailed_answers = :reveal_answers';
    $params['reveal_answers'] = !empty($data['reveal_detailed_answers']) ? 1 : 0;
}

if (isset($data['status']) && in_array($data['status'], ['active', 'disabled', 'expired'], true)) {
    $updates[] = 'status = :status';
    $params['status'] = $data['status'];
}

if (empty($updates)) {
    echo json_encode(['success' => true, 'message' => 'No changes submitted.']);
    exit;
}

$sql = "UPDATE quizzes SET " . implode(', ', $updates) . " WHERE id = :id";
$stmt = $db->prepare($sql);
$stmt->execute($params);

echo json_encode(['success' => true, 'message' => 'Settings updated successfully! 💗']);

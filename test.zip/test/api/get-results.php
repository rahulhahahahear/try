<?php
/**
 * Test of Bubu 💗 - API: Get Quiz Results (Creator Protected)
 * GET /api/get-results.php?code=XYZ&token=ABC
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

$code  = trim($_GET['code'] ?? '');
$token = trim($_GET['token'] ?? '');

if ($code === '' || $token === '') {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized: Creator credentials required.']);
    exit;
}

$quiz = findQuizForCreator($code, $token);
if (!$quiz) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Invalid creator credentials.']);
    exit;
}

$attempts = getQuizAttempts((int)$quiz['id']);

$attemptId = isset($_GET['attempt_id']) ? (int)$_GET['attempt_id'] : 0;
$detailedAnswers = [];
if ($attemptId > 0) {
    $detailedAnswers = getAttemptDetailedAnswers($attemptId);
}

echo json_encode([
    'success'          => true,
    'quiz_title'       => $quiz['quiz_title'],
    'creator_nickname' => $quiz['creator_nickname'],
    'status'           => $quiz['status'],
    'expires_at'       => $quiz['expires_at'],
    'attempts_count'   => count($attempts),
    'attempts'         => $attempts,
    'detailed_answers' => $detailedAnswers
]);

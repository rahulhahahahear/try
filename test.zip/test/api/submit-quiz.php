<?php
/**
 * Test of Bubu 💗 - API: Submit Quiz Answers
 * POST /api/submit-quiz.php
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/security.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

// Rate limit: max 20 submissions per minute
if (!checkRateLimit('submit_quiz', 20, 60)) {
    http_response_code(429);
    echo json_encode(['success' => false, 'error' => 'Whoa! Please wait a moment before submitting again. 🐻']);
    exit;
}

$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid JSON input.']);
    exit;
}

$publicCode  = trim($data['public_code'] ?? '');
$nickname    = trim($data['participant_nickname'] ?? 'Your Bubu');
$attemptToken = trim($data['attempt_token'] ?? '');
$answers     = $data['answers'] ?? [];

if ($publicCode === '' || empty($answers) || $attemptToken === '') {
    http_response_code(422);
    echo json_encode(['success' => false, 'error' => 'Missing quiz code, answers, or attempt token.']);
    exit;
}

$result = submitQuizAttempt($publicCode, $nickname, $answers, $attemptToken);

if (!$result['success']) {
    if (!empty($result['is_expired'])) {
        http_response_code(410);
    } else {
        http_response_code(422);
    }
}

echo json_encode($result);

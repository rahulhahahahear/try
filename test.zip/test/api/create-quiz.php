<?php
/**
 * Test of Bubu 💗 - API: Create Quiz
 * POST /api/create-quiz.php
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/security.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

// Rate limiting: max 10 quiz creations per minute
if (!checkRateLimit('create_quiz', 10, 60)) {
    http_response_code(429);
    echo json_encode(['success' => false, 'error' => 'Slow down, cutie! Too many quizzes created recently. Please wait a minute. 🐻']);
    exit;
}

// CSRF check
$csrfHeader = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null;
if (!verifyCsrfToken($csrfHeader)) {
    // If not matching header, check body or session
    // For relaxed friction in edge cases, if session token exists:
    if (!empty($_SESSION['csrf_token']) && $csrfHeader !== $_SESSION['csrf_token']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Invalid session security token. Please refresh the page.']);
        exit;
    }
}

$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid JSON input.']);
    exit;
}

$result = createQuiz($data);

if (!$result['success']) {
    http_response_code(422);
}

echo json_encode($result);

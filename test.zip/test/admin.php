﻿<?php
/**
 * Test of Bubu - Admin Panel
 * Protected by ADMIN_PASSWORD from config.php
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/security.php';

sendSecurityHeaders();
if (session_status() === PHP_SESSION_NONE) session_start();

$authError = '';
if (isset($_POST['admin_login'])) {
    $enteredPass = trim($_POST['admin_password'] ?? '');
    if ($enteredPass === ADMIN_PASSWORD) {
        $_SESSION['admin_authed'] = true;
        header('Location: ' . BASE_URL . '/admin.php');
        exit;
    } else {
        $authError = 'Incorrect password. Try again!';
    }
}
if (isset($_POST['admin_logout'])) {
    unset($_SESSION['admin_authed']);
    header('Location: ' . BASE_URL . '/admin.php');
    exit;
}

$isAuthed = !empty($_SESSION['admin_authed']);
$quizzes = [];
if ($isAuthed) {
    $db   = getDb();
    $stmt = $db->prepare("SELECT id, public_code, creator_nickname, quiz_title, status, created_at, expires_at FROM quizzes WHERE deleted_at IS NULL ORDER BY created_at DESC");
    $stmt->execute();
    $quizzes = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel | <?= APP_NAME ?></title>
    <meta name="robots" content="noindex, nofollow">
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/images/favicon.png">
    <meta name="theme-color" content="#FF82AC">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;500;600;700&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <style>
        :root{--admin-bg:#0f0f1a;--admin-card:#1a1a2e;--admin-card2:#16213e;--admin-border:rgba(255,130,172,0.18);--admin-accent:#FF82AC;--admin-accent2:#a78bfa;--admin-accent3:#34d399;--admin-text:#f0f0f8;--admin-muted:#9090b0;--admin-danger:#f87171;--admin-warning:#fbbf24;--glow-pink:0 0 24px rgba(255,130,172,0.25);--glow-purple:0 0 24px rgba(167,139,250,0.2);}
        body{background:var(--admin-bg)!important;color:var(--admin-text)!important;min-height:100vh;}
        .site-wrapper{background:transparent!important;}
        .main-header{background:rgba(26,26,46,0.95)!important;border-bottom:1px solid var(--admin-border)!important;backdrop-filter:blur(12px);}
        .main-footer{background:var(--admin-card)!important;border-top:1px solid var(--admin-border)!important;}
        .floating-bg-decor{opacity:0.04;}
        @keyframes slideUp{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}
        @keyframes spin{to{transform:rotate(360deg)}}

        /* LOGIN */
        .admin-login-wrap{display:flex;align-items:center;justify-content:center;min-height:calc(100vh - 140px);padding:2rem;}
        .admin-login-card{background:var(--admin-card);border:1.5px solid var(--admin-border);border-radius:24px;padding:2.5rem 2rem;max-width:420px;width:100%;box-shadow:var(--glow-pink),0 32px 80px rgba(0,0,0,0.5);text-align:center;animation:slideUp .5s cubic-bezier(.22,1,.36,1);}
        .admin-login-icon{font-size:3.5rem;margin-bottom:.75rem;display:block;filter:drop-shadow(0 0 12px rgba(255,130,172,.5));}
        .admin-login-card h1{font-family:'Fredoka',sans-serif;font-size:1.9rem;font-weight:700;color:var(--admin-accent);margin-bottom:.35rem;}
        .admin-login-card p.sub{color:var(--admin-muted);font-size:.9rem;margin-bottom:1.5rem;}
        .admin-input{width:100%;padding:.8rem 1rem;border-radius:12px;border:1.5px solid var(--admin-border);background:rgba(255,255,255,.05);color:var(--admin-text);font-family:'Nunito',sans-serif;font-size:1rem;outline:none;transition:border-color .2s,box-shadow .2s;margin-bottom:1rem;box-sizing:border-box;}
        .admin-input:focus{border-color:var(--admin-accent);box-shadow:0 0 0 3px rgba(255,130,172,.15);}
        .admin-btn-login{width:100%;padding:.85rem;background:linear-gradient(135deg,#FF82AC,#a855f7);color:#fff;font-family:'Fredoka',sans-serif;font-size:1.1rem;font-weight:600;border:none;border-radius:14px;cursor:pointer;transition:opacity .2s,transform .15s;}
        .admin-btn-login:hover{opacity:.88;transform:translateY(-1px);}
        .admin-error-msg{background:rgba(248,113,113,.12);border:1px solid rgba(248,113,113,.3);color:var(--admin-danger);border-radius:10px;padding:.6rem .9rem;font-size:.88rem;margin-bottom:1rem;}

        /* PANEL */
        .admin-panel{max-width:1100px;margin:0 auto;padding:2rem 1rem 4rem;}
        .admin-topbar{display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap;margin-bottom:2rem;animation:slideUp .4s ease;}
        .admin-topbar h1{font-family:'Fredoka',sans-serif;font-size:2rem;font-weight:700;background:linear-gradient(135deg,var(--admin-accent),var(--admin-accent2));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;margin:0;}
        .admin-topbar p{color:var(--admin-muted);font-size:.9rem;margin:0;}
        .btn-logout{padding:.5rem 1.1rem;background:rgba(248,113,113,.12);color:var(--admin-danger);border:1px solid rgba(248,113,113,.3);border-radius:10px;cursor:pointer;font-family:'Nunito',sans-serif;font-size:.88rem;font-weight:700;transition:background .2s;}
        .btn-logout:hover{background:rgba(248,113,113,.22);}

        .admin-stats{display:flex;gap:1rem;flex-wrap:wrap;margin-bottom:1.75rem;}
        .admin-stat-chip{background:var(--admin-card2);border:1px solid var(--admin-border);border-radius:14px;padding:.65rem 1.2rem;display:flex;align-items:center;gap:.5rem;font-size:.9rem;font-weight:700;}
        .admin-stat-chip span.val{color:var(--admin-accent);font-size:1.1rem;}

        .admin-section-title{font-family:'Fredoka',sans-serif;font-size:1.35rem;font-weight:600;color:var(--admin-text);margin-bottom:1rem;display:flex;align-items:center;gap:.5rem;}
        .admin-table-wrap{background:var(--admin-card);border:1px solid var(--admin-border);border-radius:18px;overflow:hidden;margin-bottom:2.5rem;box-shadow:0 8px 40px rgba(0,0,0,.3);}
        .admin-table{width:100%;border-collapse:collapse;}
        .admin-table th{background:rgba(255,130,172,.08);padding:.75rem 1rem;text-align:left;font-size:.8rem;font-weight:700;color:var(--admin-muted);text-transform:uppercase;letter-spacing:.06em;border-bottom:1px solid var(--admin-border);}
        .admin-table td{padding:.8rem 1rem;border-bottom:1px solid rgba(255,130,172,.06);vertical-align:middle;font-size:.9rem;}
        .admin-table tr:last-child td{border-bottom:none;}
        .admin-table tr:hover td{background:rgba(255,130,172,.04);}
        .quiz-title-cell{font-weight:700;color:var(--admin-text);}
        .quiz-code-cell{color:var(--admin-muted);font-size:.82rem;}
        .status-badge{display:inline-block;padding:.2rem .65rem;border-radius:99px;font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;}
        .status-active{background:rgba(52,211,153,.15);color:var(--admin-accent3);border:1px solid rgba(52,211,153,.3);}
        .status-expired{background:rgba(251,191,36,.12);color:var(--admin-warning);border:1px solid rgba(251,191,36,.3);}
        .status-disabled{background:rgba(248,113,113,.12);color:var(--admin-danger);border:1px solid rgba(248,113,113,.3);}
        .btn-edit-quiz{padding:.4rem 1rem;background:linear-gradient(135deg,rgba(255,130,172,.15),rgba(167,139,250,.15));color:var(--admin-accent2);border:1px solid rgba(167,139,250,.3);border-radius:10px;cursor:pointer;font-family:'Nunito',sans-serif;font-size:.82rem;font-weight:700;transition:all .2s;}
        .btn-edit-quiz:hover{background:linear-gradient(135deg,rgba(255,130,172,.25),rgba(167,139,250,.25));transform:translateY(-1px);}

        /* EDITOR */
        #editor-panel{display:none;animation:slideUp .45s cubic-bezier(.22,1,.36,1);}
        #editor-panel.visible{display:block;}
        .editor-header{display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap;margin-bottom:1.25rem;padding:1.25rem 1.5rem;background:var(--admin-card);border:1px solid var(--admin-border);border-radius:18px;box-shadow:var(--glow-purple);}
        .editor-quiz-meta h2{font-family:'Fredoka',sans-serif;font-size:1.5rem;color:var(--admin-accent);margin:0 0 .2rem;}
        .editor-quiz-meta p{color:var(--admin-muted);font-size:.85rem;margin:0;}
        .editor-actions{display:flex;gap:.75rem;flex-wrap:wrap;}
        .btn-save-all{padding:.6rem 1.4rem;background:linear-gradient(135deg,#FF82AC,#a855f7);color:#fff;border:none;border-radius:12px;font-family:'Fredoka',sans-serif;font-size:1rem;font-weight:600;cursor:pointer;transition:opacity .2s,transform .15s;display:flex;align-items:center;gap:.4rem;}
        .btn-save-all:hover{opacity:.88;transform:translateY(-1px);}
        .btn-save-all:disabled{opacity:.5;cursor:not-allowed;transform:none;}
        .btn-close-editor{padding:.6rem 1.1rem;background:rgba(255,255,255,.05);color:var(--admin-muted);border:1px solid var(--admin-border);border-radius:12px;font-family:'Nunito',sans-serif;font-size:.9rem;font-weight:700;cursor:pointer;transition:background .2s;}
        .btn-close-editor:hover{background:rgba(255,255,255,.1);}

        .questions-list{display:flex;flex-direction:column;gap:1.25rem;}
        .question-card{background:var(--admin-card);border:1px solid var(--admin-border);border-radius:18px;padding:1.25rem 1.5rem;transition:border-color .2s,box-shadow .2s;}
        .question-card:hover{border-color:rgba(255,130,172,.35);box-shadow:var(--glow-pink);}
        .question-card-header{display:flex;align-items:center;gap:.75rem;margin-bottom:.85rem;}
        .q-number{width:32px;height:32px;background:linear-gradient(135deg,var(--admin-accent),var(--admin-accent2));border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Fredoka',sans-serif;font-size:.9rem;font-weight:700;color:#fff;flex-shrink:0;}
        .question-card-header label{font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--admin-muted);}
        .admin-field{width:100%;padding:.7rem .95rem;border-radius:10px;border:1.5px solid rgba(255,255,255,.08);background:rgba(255,255,255,.04);color:var(--admin-text);font-family:'Nunito',sans-serif;font-size:.95rem;outline:none;transition:border-color .2s,box-shadow .2s;box-sizing:border-box;}
        .admin-field:focus{border-color:var(--admin-accent);box-shadow:0 0 0 3px rgba(255,130,172,.12);}

        .options-grid{display:grid;grid-template-columns:1fr 1fr;gap:.75rem;margin-top:1rem;}
        @media(max-width:600px){.options-grid{grid-template-columns:1fr;}}
        .option-row{background:rgba(255,255,255,.03);border:1.5px solid rgba(255,255,255,.06);border-radius:12px;padding:.75rem;transition:border-color .2s,background .2s;position:relative;}
        .option-row.is-correct-opt{border-color:rgba(52,211,153,.4);background:rgba(52,211,153,.06);}
        .option-row-top{display:flex;align-items:center;gap:.5rem;margin-bottom:.5rem;}
        .opt-letter{width:26px;height:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.75rem;font-weight:800;background:rgba(255,130,172,.12);color:var(--admin-accent);flex-shrink:0;}
        .option-row.is-correct-opt .opt-letter{background:rgba(52,211,153,.2);color:var(--admin-accent3);}
        .opt-emoji-input{width:56px;padding:.4rem .5rem;border-radius:8px;border:1.5px solid rgba(255,255,255,.08);background:rgba(255,255,255,.05);color:var(--admin-text);font-size:1rem;text-align:center;outline:none;}
        .opt-emoji-input:focus{border-color:var(--admin-accent);}
        .opt-text-input{flex:1;padding:.4rem .65rem;border-radius:8px;border:1.5px solid rgba(255,255,255,.08);background:rgba(255,255,255,.05);color:var(--admin-text);font-size:.88rem;outline:none;transition:border-color .2s;}
        .opt-text-input:focus{border-color:var(--admin-accent);}
        .opt-correct-btn{display:flex;align-items:center;gap:.4rem;font-size:.78rem;font-weight:700;cursor:pointer;color:var(--admin-muted);background:none;border:none;padding:0;font-family:'Nunito',sans-serif;transition:color .2s;}
        .opt-correct-btn .dot{width:14px;height:14px;border-radius:50%;border:2px solid var(--admin-muted);transition:background .2s,border-color .2s;flex-shrink:0;}
        .option-row.is-correct-opt .opt-correct-btn{color:var(--admin-accent3);}
        .option-row.is-correct-opt .opt-correct-btn .dot{background:var(--admin-accent3);border-color:var(--admin-accent3);}
        .correct-indicator{position:absolute;top:.5rem;right:.75rem;font-size:.72rem;font-weight:800;color:var(--admin-accent3);text-transform:uppercase;letter-spacing:.06em;opacity:0;transition:opacity .2s;}
        .option-row.is-correct-opt .correct-indicator{opacity:1;}

        .editor-loading{text-align:center;padding:3rem;color:var(--admin-muted);}
        .spinner{display:inline-block;width:36px;height:36px;border:3px solid rgba(255,130,172,.2);border-top-color:var(--admin-accent);border-radius:50%;animation:spin .8s linear infinite;margin-bottom:.75rem;}

        .admin-toast{position:fixed;bottom:2rem;right:2rem;background:var(--admin-card);border:1.5px solid var(--admin-border);border-radius:14px;padding:.85rem 1.3rem;font-family:'Nunito',sans-serif;font-size:.92rem;font-weight:700;color:var(--admin-text);box-shadow:0 8px 32px rgba(0,0,0,.4);z-index:9999;transform:translateY(20px);opacity:0;transition:all .35s cubic-bezier(.22,1,.36,1);max-width:360px;}
        .admin-toast.show{transform:translateY(0);opacity:1;}
        .admin-toast.toast-success{border-color:rgba(52,211,153,.4);color:var(--admin-accent3);}
        .admin-toast.toast-error{border-color:rgba(248,113,113,.4);color:var(--admin-danger);}

        .admin-empty{text-align:center;padding:3rem 1rem;color:var(--admin-muted);}
        .admin-empty .big-emoji{font-size:3rem;margin-bottom:.75rem;display:block;}
    </style>
    <script>
        window.ADMIN_CONFIG = {
            baseUrl: "<?= BASE_URL ?>",
            adminPassword: "<?= e(ADMIN_PASSWORD) ?>"
        };
    </script>
</head>
<body>
<div class="site-wrapper">
    <div class="floating-bg-decor" aria-hidden="true">
        <span class="decor-heart h1">&#x1F497;</span>
        <span class="decor-heart h2">&#x2728;</span>
        <span class="decor-heart h3">&#x1F338;</span>
        <span class="decor-heart h4">&#x1F496;</span>
        <span class="decor-heart h5">&#x1F43B;</span>
        <span class="decor-heart h6">&#x2B50;</span>
    </div>
    <header class="main-header" role="banner">
        <div class="container header-container">
            <a href="<?= BASE_URL ?>/" class="brand-logo" aria-label="Test of Bubu Home">
                <span class="logo-icon">&#x1F43B;&#x1F497;</span>
                <span class="logo-text">Test of Bubu</span>
            </a>
            <nav class="header-nav">
                <span style="color:rgba(255,255,255,.4);font-size:.82rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em;">&#x1F510; Admin Panel</span>
                <?php if ($isAuthed): ?>
                <form method="post" style="display:inline;">
                    <button type="submit" name="admin_logout" class="btn-logout">Logout</button>
                </form>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <main class="main-content" id="main-content">

<?php if (!$isAuthed): ?>
    <div class="admin-login-wrap">
        <div class="admin-login-card">
            <span class="admin-login-icon">&#x1F510;</span>
            <h1>Admin Panel</h1>
            <p class="sub">Test of Bubu &mdash; Question &amp; Quiz Editor</p>
            <?php if ($authError): ?>
                <div class="admin-error-msg">&#x26A0;&#xFE0F; <?= e($authError) ?></div>
            <?php endif; ?>
            <form method="post" autocomplete="off">
                <input type="password" name="admin_password" id="admin_password_field" class="admin-input" placeholder="Enter admin password..." required autofocus>
                <button type="submit" name="admin_login" class="admin-btn-login">&#x1F680; Enter Admin Panel</button>
            </form>
        </div>
    </div>

<?php else: ?>
    <div class="admin-panel">
        <div class="admin-topbar">
            <div>
                <h1>&#x1F6E0;&#xFE0F; Admin Panel</h1>
                <p>Manage quiz questions, options &amp; answers for Test of Bubu &#x1F497;</p>
            </div>
            <form method="post">
                <button type="submit" name="admin_logout" class="btn-logout">&#x1F6AA; Logout</button>
            </form>
        </div>

        <div class="admin-stats">
            <div class="admin-stat-chip">&#x1F4CB; <span>Total Quizzes:</span> <span class="val"><?= count($quizzes) ?></span></div>
            <?php
            $ac = count(array_filter($quizzes, fn($q) => $q['status'] === 'active'));
            $ec = count(array_filter($quizzes, fn($q) => $q['status'] === 'expired'));
            $dc = count(array_filter($quizzes, fn($q) => $q['status'] === 'disabled'));
            ?>
            <div class="admin-stat-chip">&#x2705; <span>Active:</span> <span class="val"><?= $ac ?></span></div>
            <div class="admin-stat-chip">&#x23F3; <span>Expired:</span> <span class="val"><?= $ec ?></span></div>
            <?php if ($dc > 0): ?>
            <div class="admin-stat-chip">&#x1F6AB; <span>Disabled:</span> <span class="val"><?= $dc ?></span></div>
            <?php endif; ?>
        </div>

        <p class="admin-section-title">&#x1F4DA; All Quizzes</p>

        <div class="admin-table-wrap">
            <?php if (empty($quizzes)): ?>
                <div class="admin-empty"><span class="big-emoji">&#x1F43B;</span><p>No quizzes found in the database.</p></div>
            <?php else: ?>
            <table class="admin-table" role="table">
                <thead>
                    <tr>
                        <th>#ID</th>
                        <th>Quiz Title</th>
                        <th>Creator</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Expires</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($quizzes as $qz): ?>
                    <tr>
                        <td style="color:var(--admin-muted);font-size:.8rem;">#<?= $qz['id'] ?></td>
                        <td>
                            <div class="quiz-title-cell"><?= e($qz['quiz_title'] ?: 'Untitled Quiz') ?></div>
                            <div class="quiz-code-cell">Code: <?= e($qz['public_code']) ?></div>
                        </td>
                        <td style="font-weight:600;"><?= e($qz['creator_nickname']) ?></td>
                        <td><span class="status-badge status-<?= e($qz['status']) ?>"><?= strtoupper(e($qz['status'])) ?></span></td>
                        <td style="color:var(--admin-muted);font-size:.82rem;"><?= date('M d, Y', strtotime($qz['created_at'])) ?></td>
                        <td style="color:var(--admin-muted);font-size:.82rem;"><?= date('M d, Y H:i', strtotime($qz['expires_at'])) ?></td>
                        <td>
                            <button type="button" class="btn-edit-quiz"
                                data-quiz-id="<?= $qz['id'] ?>"
                                data-quiz-title="<?= e($qz['quiz_title'] ?: 'Untitled Quiz') ?>"
                                data-creator="<?= e($qz['creator_nickname']) ?>"
                                onclick="openEditor(this)">
                                &#x270F;&#xFE0F; Edit Q&amp;A
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

        <!-- EDITOR PANEL -->
        <div id="editor-panel">
            <div class="editor-header">
                <div class="editor-quiz-meta">
                    <h2 id="editor-quiz-title">Quiz Editor</h2>
                    <p id="editor-quiz-meta"></p>
                </div>
                <div class="editor-actions">
                    <button type="button" class="btn-save-all" id="btn-save-all" onclick="saveAllQuestions()">&#x1F4BE; Save All Changes</button>
                    <button type="button" class="btn-close-editor" onclick="closeEditor()">&#x2715; Close</button>
                </div>
            </div>
            <div id="questions-container" class="questions-list">
                <div class="editor-loading"><div class="spinner"></div><p>Loading quiz questions...</p></div>
            </div>
            <div style="margin-top:1.5rem;text-align:right;">
                <button type="button" class="btn-save-all" id="btn-save-all-bottom" onclick="saveAllQuestions()">&#x1F4BE; Save All Changes</button>
            </div>
        </div>
    </div>
<?php endif; ?>

    </main>
    <footer class="main-footer" role="contentinfo">
        <div class="container footer-container">
            <p class="footer-title">Test of Bubu &#x1F497; &mdash; Admin</p>
            <p class="footer-tagline" style="color:rgba(255,255,255,.3);font-size:.8rem;">Access restricted. Do not share this page. &#x1F512;</p>
        </div>
    </footer>
</div>

<div id="admin-toast" class="admin-toast" role="alert" aria-live="polite"></div>

<?php if ($isAuthed): ?>
<script>
let currentQuizId = null;

function openEditor(btn) {
    currentQuizId = btn.dataset.quizId;
    document.getElementById('editor-quiz-title').textContent = '\u270f\ufe0f ' + btn.dataset.quizTitle;
    document.getElementById('editor-quiz-meta').textContent  = 'Creator: ' + btn.dataset.creator + ' \u00b7 Quiz ID: #' + currentQuizId;
    document.getElementById('questions-container').innerHTML = '<div class="editor-loading"><div class="spinner"></div><p>Loading questions &amp; options...</p></div>';
    const panel = document.getElementById('editor-panel');
    panel.classList.add('visible');
    setTimeout(() => panel.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
    loadQuizQuestions(currentQuizId);
}

function closeEditor() {
    document.getElementById('editor-panel').classList.remove('visible');
    currentQuizId = null;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function loadQuizQuestions(quizId) {
    try {
        const url = window.ADMIN_CONFIG.baseUrl + '/api/admin-get-quiz.php?quiz_id=' + quizId + '&admin_password=' + encodeURIComponent(window.ADMIN_CONFIG.adminPassword);
        const resp = await fetch(url);
        const data = await resp.json();
        if (!data.success) {
            document.getElementById('questions-container').innerHTML = '<div class="editor-loading"><p style="color:#f87171">\u274c ' + (data.error || 'Failed to load quiz.') + '</p></div>';
            return;
        }
        renderQuestions(data.quiz.questions);
    } catch (err) {
        document.getElementById('questions-container').innerHTML = '<div class="editor-loading"><p style="color:#f87171">\u274c Network error loading quiz questions.</p></div>';
    }
}

function renderQuestions(questions) {
    if (!questions || questions.length === 0) {
        document.getElementById('questions-container').innerHTML = '<div class="editor-loading"><p>No questions found for this quiz.</p></div>';
        return;
    }
    const container = document.getElementById('questions-container');
    container.innerHTML = '';
    questions.forEach((q, qi) => {
        const card = document.createElement('div');
        card.className = 'question-card';
        card.dataset.qid = q.id;
        card.innerHTML =
            '<div class="question-card-header">' +
            '<div class="q-number">' + (qi + 1) + '</div>' +
            '<label for="qtext_' + q.id + '">Question Text</label>' +
            '</div>' +
            '<input type="text" id="qtext_' + q.id + '" class="admin-field" value="' + escHtml(q.question_text) + '" placeholder="Question ' + (qi + 1) + ' text..." data-qid="' + q.id + '">' +
            '<div class="options-grid" id="opts_' + q.id + '"></div>';
        container.appendChild(card);
        const optsGrid = card.querySelector('#opts_' + q.id);
        (q.options || []).forEach((opt, oi) => optsGrid.appendChild(renderOption(opt, oi, q.id)));
    });
}

function renderOption(opt, oi, qId) {
    const letter = String.fromCharCode(65 + oi);
    const isCorrect = parseInt(opt.is_correct) === 1;
    const row = document.createElement('div');
    row.className = 'option-row' + (isCorrect ? ' is-correct-opt' : '');
    row.dataset.oid = opt.id;
    row.dataset.qid = qId;
    row.innerHTML =
        '<span class="correct-indicator">\u2713 Correct Answer</span>' +
        '<div class="option-row-top">' +
        '<span class="opt-letter">' + letter + '</span>' +
        '<input type="text" class="opt-emoji-input" value="' + escHtml(opt.option_emoji || '') + '" placeholder="\ud83d\ude0a" maxlength="8" title="Emoji">' +
        '<input type="text" class="opt-text-input" value="' + escHtml(opt.option_text) + '" placeholder="Option ' + letter + ' text...">' +
        '</div>' +
        '<button type="button" class="opt-correct-btn" onclick="setCorrect(this,\'' + qId + '\')">' +
        '<span class="dot"></span> Mark as correct answer</button>';
    return row;
}

function setCorrect(btn, qId) {
    btn.closest('.question-card').querySelectorAll('.option-row').forEach(r => r.classList.remove('is-correct-opt'));
    btn.closest('.option-row').classList.add('is-correct-opt');
}

async function saveAllQuestions() {
    if (!currentQuizId) return;
    const b1 = document.getElementById('btn-save-all');
    const b2 = document.getElementById('btn-save-all-bottom');
    [b1, b2].forEach(b => { if (b) { b.disabled = true; b.textContent = '\u23f3 Saving...'; } });

    const questionsData = [];
    let hasError = false;

    document.querySelectorAll('.question-card').forEach(card => {
        if (hasError) return;
        const qId   = card.dataset.qid;
        const qText = card.querySelector('#qtext_' + qId).value.trim();
        if (!qText) { showAdminToast('\u274c Question text cannot be empty!', 'error'); hasError = true; return; }

        const options = [];
        let correctCount = 0;
        card.querySelectorAll('.option-row').forEach(row => {
            if (hasError) return;
            const optText  = row.querySelector('.opt-text-input').value.trim();
            const optEmoji = row.querySelector('.opt-emoji-input').value.trim();
            const isCorrect = row.classList.contains('is-correct-opt') ? 1 : 0;
            if (!optText) { showAdminToast('\u274c Option text cannot be empty!', 'error'); hasError = true; return; }
            if (isCorrect) correctCount++;
            options.push({ id: parseInt(row.dataset.oid), option_text: optText, option_emoji: optEmoji, is_correct: isCorrect });
        });
        if (!hasError && correctCount !== 1) { showAdminToast('\u274c Each question must have exactly ONE correct answer!', 'error'); hasError = true; return; }
        questionsData.push({ id: parseInt(qId), question_text: qText, options });
    });

    if (hasError) {
        [b1, b2].forEach(b => { if (b) { b.disabled = false; b.textContent = '\ud83d\udcbe Save All Changes'; } });
        return;
    }

    try {
        const resp = await fetch(window.ADMIN_CONFIG.baseUrl + '/api/admin-update-questions.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ admin_password: window.ADMIN_CONFIG.adminPassword, quiz_id: parseInt(currentQuizId), questions: questionsData })
        });
        const data = await resp.json();
        showAdminToast(data.success ? '\u2705 ' + (data.message || 'Saved!') : '\u274c ' + (data.error || 'Failed to save.'), data.success ? 'success' : 'error');
    } catch (err) {
        showAdminToast('\u274c Network error saving questions.', 'error');
    } finally {
        [b1, b2].forEach(b => { if (b) { b.disabled = false; b.textContent = '\ud83d\udcbe Save All Changes'; } });
    }
}

let toastTimer = null;
function showAdminToast(msg, type) {
    const t = document.getElementById('admin-toast');
    t.textContent = msg;
    t.className = 'admin-toast show toast-' + (type || 'success');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 4000);
}

function escHtml(str) {
    if (!str) return '';
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}
</script>
<?php endif; ?>
</body>
</html>

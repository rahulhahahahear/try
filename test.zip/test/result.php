<?php
/**
 * Test of Bubu 💗 - Dedicated Standalone Result View
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

$attemptId = isset($_GET['attempt_id']) ? (int)$_GET['attempt_id'] : 0;

if ($attemptId <= 0) {
    header("Location: " . BASE_URL . "/");
    exit;
}

$db = getDb();
$stmt = $db->prepare("
    SELECT a.*, q.creator_nickname, q.quiz_title, q.public_code, q.reveal_detailed_answers
    FROM attempts a
    JOIN quizzes q ON q.id = a.quiz_id
    WHERE a.id = :id
    LIMIT 1
");
$stmt->execute(['id' => $attemptId]);
$attempt = $stmt->fetch();

if (!$attempt) {
    header("Location: " . BASE_URL . "/");
    exit;
}

$score = (int)$attempt['score'];
$total = (int)$attempt['total_questions'];
$reaction = getReactionData($score, $total);
$shareUrl = BASE_URL . '/play.php?code=' . e($attempt['public_code']);

$pageTitle = 'Quiz Result 💗 | ' . APP_NAME;
require_once __DIR__ . '/includes/header.php';
?>

<div class="container" style="max-width: 580px; padding-top: 2rem;">
    <div class="card reaction-card">
        <div class="reaction-character-wrap">
            <picture>
                <source srcset="<?= BASE_URL ?>/<?= e($reaction['image']) ?>" type="image/webp">
                <img src="<?= BASE_URL ?>/<?= e($reaction['image_fallback']) ?>" alt="Character reaction" class="reaction-character-img <?= e($reaction['animation']) ?>">
            </picture>
        </div>

        <div style="margin-bottom: 0.5rem;">
            <span class="badge" style="background: <?= e($reaction['badge_color']) ?>; color: #ffffff;">
                <?= e($reaction['badge_text']) ?>
            </span>
        </div>

        <h2 style="font-family: var(--font-heading); font-size: 1.75rem; color: var(--text-dark); margin-bottom: 0.35rem; line-height: 1.2;">
            <?= e($reaction['headline']) ?>
        </h2>
        <p style="color: var(--text-muted); font-size: 1rem; margin-bottom: 1.25rem;">
            <?= e($reaction['subheadline']) ?>
        </p>

        <!-- Score Badge Circle -->
        <div class="score-circle-wrap">
            <div class="score-display"><?= $score ?>/<?= $total ?></div>
            <div class="score-percentage"><?= round(($score / $total) * 100) ?>% Match with <?= e($attempt['creator_nickname']) ?></div>
        </div>

        <!-- Animated Conversation Dialog -->
        <div class="dialogue-box">
            <?php foreach ($reaction['conversation'] as $conv): ?>
                <div class="dialogue-item">
                    <div class="dialogue-avatar"><?= $conv['speaker'] === 'Bubu' ? '🐻' : '🐼' ?></div>
                    <div class="dialogue-bubble">
                        <strong><?= e($conv['speaker']) ?>:</strong> <?= e($conv['text']) ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Share Actions -->
        <h4 style="font-family: var(--font-heading); font-size: 1.15rem; color: var(--text-dark); margin: 1.5rem 0 0.5rem;">
            Share This Result 💕
        </h4>
        <div class="share-actions-grid">
            <a href="https://api.whatsapp.com/send?text=<?= urlencode("I scored {$score}/10 on {$attempt['creator_nickname']}'s Test of Bubu! 🐻💗 Take the quiz here: {$shareUrl}") ?>" target="_blank" rel="noopener noreferrer" class="btn btn-whatsapp">
                <span>💬</span> WhatsApp
            </a>
            <a href="https://t.me/share/url?url=<?= urlencode($shareUrl) ?>&text=<?= urlencode("I scored {$score}/10 on {$attempt['creator_nickname']}'s Test of Bubu! 🐻💗") ?>" target="_blank" rel="noopener noreferrer" class="btn btn-telegram">
                <span>✈️</span> Telegram
            </a>
            <button type="button" class="btn btn-outline" onclick="window.copyToClipboard('<?= $shareUrl ?>')">
                <span>📋</span> Copy Quiz Link
            </button>
            <button type="button" class="btn btn-secondary" onclick="window.generateShareCard({ creatorName: '<?= e($attempt['creator_nickname']) ?>', score: <?= $score ?>, total: <?= $total ?>, headline: '<?= e($reaction['headline']) ?>', url: '<?= $shareUrl ?>' })">
                <span>🎨</span> Story Card
            </button>
        </div>

        <div style="margin-top: 1.75rem; border-top: 1.5px solid var(--border-soft); padding-top: 1.25rem;">
            <p style="font-size: 0.95rem; color: var(--text-muted); margin-bottom: 0.85rem;">
                Think you can make a funnier quiz?
            </p>
            <a href="<?= BASE_URL ?>/create.php" class="btn btn-primary btn-block btn-lg">
                <span>🐻💗</span> Create Your Own Quiz
            </a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

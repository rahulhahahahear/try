<?php
/**
 * Test of Bubu 💗 - Quiz Participant Player
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

$code = trim($_GET['code'] ?? '');
if ($code === '') {
    header("Location: " . BASE_URL . "/");
    exit;
}

$quiz = findQuizWithQuestions($code, false); // Security: false = never include correct answers!

if (!$quiz) {
    $pageTitle = 'Quiz Not Found | ' . APP_NAME;
    require_once __DIR__ . '/includes/header.php';
    ?>
    <div class="container" style="max-width: 520px; padding-top: 3rem; text-align: center;">
        <div class="card">
            <div style="width: 140px; height: 140px; margin: 0 auto 1rem;">
                <picture>
                    <source srcset="<?= BASE_URL ?>/assets/images/bubu-thinking.webp" type="image/webp">
                    <img src="<?= BASE_URL ?>/assets/images/bubu-thinking.png" alt="Confused bear" style="width: 100%; height: 100%; object-fit: contain;">
                </picture>
            </div>
            <h2 style="font-family: var(--font-heading); color: var(--text-dark); margin-bottom: 0.5rem;">
                Quiz Not Found 🧐
            </h2>
            <p style="color: var(--text-muted); margin-bottom: 1.5rem;">
                Hmm... we couldn't find this Bubu test. Check the link and try again! 💗
            </p>
            <a href="<?= BASE_URL ?>/" class="btn btn-primary">
                <span>🏠</span> Return Home
            </a>
        </div>
    </div>
    <?php
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

// Check expiration
if ($quiz['status'] === 'expired' || strtotime($quiz['expires_at']) <= time()) {
    header("Location: " . BASE_URL . "/expired.php");
    exit;
}

if ($quiz['status'] !== 'active') {
    $pageTitle = 'Quiz Unavailable | ' . APP_NAME;
    require_once __DIR__ . '/includes/header.php';
    ?>
    <div class="container" style="max-width: 520px; padding-top: 3rem; text-align: center;">
        <div class="card">
            <h2 style="font-family: var(--font-heading); color: var(--text-dark); margin-bottom: 0.5rem;">
                Quiz Currently Disabled 🔒
            </h2>
            <p style="color: var(--text-muted); margin-bottom: 1.5rem;">
                This quiz has been paused or disabled by its creator.
            </p>
            <a href="<?= BASE_URL ?>/" class="btn btn-primary">
                <span>🏠</span> Return Home
            </a>
        </div>
    </div>
    <?php
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

$pageTitle = e($quiz['creator_nickname']) . "'s Quiz 💗 | " . APP_NAME;
$pageDesc  = 'Take ' . e($quiz['creator_nickname']) . "'s Bubu quiz and see how well you really know them!";
$extraScripts = ['assets/js/quiz-player.js'];
require_once __DIR__ . '/includes/header.php';
?>

<!-- Pass sanitized quiz data safely to JavaScript (without answer keys) -->
<script>
window.QUIZ_DATA = <?= json_encode([
    'public_code'      => $quiz['public_code'],
    'quiz_title'       => $quiz['quiz_title'],
    'creator_nickname' => $quiz['creator_nickname'],
    'relationship_type'=> $quiz['relationship_type'],
    'questions'        => $quiz['questions']
], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
</script>

<div class="container" style="max-width: 580px; padding-top: 2rem;">

    <!-- VIEW 1: Welcome Screen -->
    <div id="player-welcome-view" class="card" style="display: block; text-align: center;">
        <div style="width: 170px; height: 170px; margin: 0 auto 1.25rem;">
            <picture>
                <source srcset="<?= BASE_URL ?>/assets/images/bubu-shy.webp" type="image/webp">
                <img src="<?= BASE_URL ?>/assets/images/bubu-shy.png" alt="Adorable blushing bear" class="wiggle-gentle" style="width: 100%; height: 100%; object-fit: contain;">
            </picture>
        </div>

        <span class="badge badge-pink" style="margin-bottom: 0.5rem;">Couple Quiz Time 💕</span>
        
        <h2 style="font-family: var(--font-heading); font-size: 1.85rem; color: var(--text-dark); margin-bottom: 0.5rem;">
            <?= e($quiz['quiz_title']) ?>
        </h2>

        <p style="color: var(--text-muted); font-size: 1.05rem; margin-bottom: 1.5rem;">
            Let's see how well you really know <strong><?= e($quiz['creator_nickname']) ?></strong>! Answer 10 questions to unlock your score.
        </p>

        <div class="form-group" style="text-align: left; max-width: 360px; margin: 0 auto 1.5rem;">
            <label for="participant-nickname-input" class="form-label">What's your nickname? <span style="font-weight: 400; color: var(--text-muted);">(Optional)</span></label>
            <input type="text" id="participant-nickname-input" class="form-control" placeholder="e.g. Your Bubu, Honey, Cutie" maxlength="50" value="Your Bubu">
        </div>

        <button type="button" id="player-start-btn" class="btn btn-primary btn-lg btn-block">
            <span>💗</span> Let's Play!
        </button>

        <div style="margin-top: 0.85rem;">
            <a href="<?= BASE_URL ?>/scores.php?code=<?= e($quiz['public_code']) ?>" class="btn btn-outline btn-block" style="justify-content: center;">
                <span>📊</span> Check Scores
            </a>
        </div>
    </div>

    <!-- VIEW 2: Active Question Answering -->
    <div id="player-active-view" class="card" style="display: none;">
        <!-- Stepper -->
        <div class="quiz-stepper">
            <div class="stepper-header">
                <span id="player-q-num">Question 1 of 10</span>
                <span class="badge badge-lavender"><?= e($quiz['creator_nickname']) ?>'s Quiz</span>
            </div>
            <div class="progress-track">
                <div id="player-progress-fill" class="progress-fill" style="width: 10%;"></div>
            </div>
        </div>

        <!-- Question Title -->
        <h3 id="player-question-text" style="font-family: var(--font-heading); font-size: 1.35rem; color: var(--text-dark); margin-bottom: 1rem;">
            <!-- Question text injected dynamically -->
        </h3>

        <!-- Options Container -->
        <div id="player-options-list" class="options-list" role="radiogroup">
            <!-- 4 answer cards injected dynamically -->
        </div>

        <!-- Navigation Buttons -->
        <div style="display: flex; justify-content: space-between; gap: 0.75rem; margin-top: 1.5rem;">
            <button type="button" id="player-prev-btn" class="btn btn-secondary">
                <span>👈</span> Back
            </button>
            <button type="button" id="player-next-btn" class="btn btn-primary">
                Next Question 💗
            </button>
        </div>
    </div>

    <!-- VIEW 3: Review Answers Screen -->
    <div id="player-review-view" style="display: none;">
        <div class="card" style="text-align: center; margin-bottom: 1.25rem;">
            <span class="badge badge-pink">Final Check</span>
            <h2 style="font-family: var(--font-heading); font-size: 1.65rem; color: var(--text-dark); margin: 0.5rem 0;">
                Review Your Answers 🔍
            </h2>
            <p style="color: var(--text-muted); font-size: 0.95rem;">
                Make sure you are confident! You won't be able to change them once submitted.
            </p>
        </div>

        <div id="review-answers-list">
            <!-- Review rows injected dynamically -->
        </div>

        <div style="display: flex; gap: 0.75rem; margin-top: 1.5rem; justify-content: space-between;">
            <button type="button" id="review-back-btn" class="btn btn-secondary btn-lg">
                <span>👈</span> Edit
            </button>
            <button type="button" id="submit-quiz-final-btn" class="btn btn-primary btn-lg">
                <span>💕</span> Submit My Answers
            </button>
        </div>
    </div>

    <!-- VIEW 4: Result & Cartoon Reaction Screen -->
    <div id="player-result-view" class="card reaction-card" style="display: none;">
        <div class="reaction-character-wrap">
            <img id="result-reaction-img" src="<?= BASE_URL ?>/assets/images/bubu-happy.png" alt="Bubu character reaction" class="reaction-character-img">
        </div>

        <div style="margin-bottom: 0.5rem;">
            <span id="result-badge" class="badge">Soulmate Match</span>
        </div>

        <h2 id="result-headline" style="font-family: var(--font-heading); font-size: 1.75rem; color: var(--text-dark); margin-bottom: 0.35rem; line-height: 1.2;">
            OMG! YOU ACTUALLY KNOW YOUR BUBU! 💗
        </h2>
        <p id="result-subhead" style="color: var(--text-muted); font-size: 1rem; margin-bottom: 1.25rem;">
            Soulmate-level knowledge unlocked! ✨
        </p>

        <!-- Score Badge Circle -->
        <div class="score-circle-wrap">
            <div id="result-score-num" class="score-display">10/10</div>
            <div id="result-score-pct" class="score-percentage">100% Match</div>
        </div>

        <!-- Animated Conversation Dialog -->
        <div class="dialogue-box" id="result-dialogue-list">
            <!-- Populated dynamically -->
        </div>

        <!-- Share Actions -->
        <h4 style="font-family: var(--font-heading); font-size: 1.15rem; color: var(--text-dark); margin: 1.5rem 0 0.5rem;">
            Share Your Score 💕
        </h4>
        <div class="share-actions-grid">
            <a href="#" id="result-share-whatsapp" target="_blank" rel="noopener noreferrer" class="btn btn-whatsapp">
                <span>💬</span> WhatsApp
            </a>
            <a href="#" id="result-share-telegram" target="_blank" rel="noopener noreferrer" class="btn btn-telegram">
                <span>✈️</span> Telegram
            </a>
            <button type="button" id="result-copy-btn" class="btn btn-outline">
                <span>📋</span> Copy Result
            </button>
            <button type="button" id="result-download-card" class="btn btn-secondary">
                <span>🎨</span> Story Card
            </button>
        </div>

        <div style="margin-top: 1.75rem; border-top: 1.5px solid var(--border-soft); padding-top: 1.25rem;">
            <p style="font-size: 0.95rem; color: var(--text-muted); margin-bottom: 0.85rem;">
                Want to test <em>them</em> back? Turn the tables!
            </p>
            <a href="<?= BASE_URL ?>/create.php" class="btn btn-primary btn-block btn-lg">
                <span>🐻💗</span> Create Your Own Quiz
            </a>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

/**
 * Test of Bubu 💗 - Automatic 8-Option Quiz Builder Engine
 * 10 Master Questions -> Exactly 8 Automatic Preset Options each (1 option per line, with photo & name)
 * Player receives: 1 right answer + 3 random answers from the remaining 7!
 */

(function() {
    'use strict';

    // Master Question Pool: 10 Questions, exactly 8 preset non-editable options each with dedicated images
    const QUESTION_POOL = [
        {
            id: 1,
            text: "What is my favourite food? 🍕",
            options: [
                { id: 1, text: "Pizza", emoji: "🍕", image: "assets/images/options/q1_opt1.svg" },
                { id: 2, text: "Momos / Dumplings", emoji: "🥟", image: "assets/images/options/q1_opt2.svg" },
                { id: 3, text: "Biryani", emoji: "🍛", image: "assets/images/options/q1_opt3.svg" },
                { id: 4, text: "Burger & Fries", emoji: "🍔", image: "assets/images/options/q1_opt4.svg" },
                { id: 5, text: "Pasta / Lasagna", emoji: "🍝", image: "assets/images/options/q1_opt5.svg" },
                { id: 6, text: "Noodles / Ramen", emoji: "🍜", image: "assets/images/options/q1_opt6.svg" },
                { id: 7, text: "Ice Cream Sundae", emoji: "🍦", image: "assets/images/options/q1_opt7.svg" },
                { id: 8, text: "Chocolate & Brownie", emoji: "🍫", image: "assets/images/options/q1_opt8.svg" }
            ]
        },
        {
            id: 2,
            text: "Which app do I spend the most time on? 📱",
            options: [
                { id: 1, text: "Instagram (Reels)", emoji: "📸", image: "assets/images/options/q2_opt1.svg" },
                { id: 2, text: "WhatsApp (Chatting)", emoji: "💬", image: "assets/images/options/q2_opt2.svg" },
                { id: 3, text: "YouTube", emoji: "▶️", image: "assets/images/options/q2_opt3.svg" },
                { id: 4, text: "TikTok / Short Videos", emoji: "🎵", image: "assets/images/options/q2_opt4.svg" },
                { id: 5, text: "Pinterest", emoji: "📌", image: "assets/images/options/q2_opt5.svg" },
                { id: 6, text: "Spotify (Music)", emoji: "🎧", image: "assets/images/options/q2_opt6.svg" },
                { id: 7, text: "Netflix / Shows", emoji: "🍿", image: "assets/images/options/q2_opt7.svg" },
                { id: 8, text: "Snapchat", emoji: "👻", image: "assets/images/options/q2_opt8.svg" }
            ]
        },
        {
            id: 3,
            text: "What is my favourite colour? 🎨",
            options: [
                { id: 1, text: "Baby Pink", emoji: "🌸", image: "assets/images/options/q3_opt1.svg" },
                { id: 2, text: "Sky Blue", emoji: "🌊", image: "assets/images/options/q3_opt2.svg" },
                { id: 3, text: "Lavender Purple", emoji: "💜", image: "assets/images/options/q3_opt3.svg" },
                { id: 4, text: "Classic Black", emoji: "🖤", image: "assets/images/options/q3_opt4.svg" },
                { id: 5, text: "Mint / Pastel Green", emoji: "🍃", image: "assets/images/options/q3_opt5.svg" },
                { id: 6, text: "Sunshine Yellow", emoji: "🌻", image: "assets/images/options/q3_opt6.svg" },
                { id: 7, text: "Warm Peach / Coral", emoji: "🍑", image: "assets/images/options/q3_opt7.svg" },
                { id: 8, text: "Warm White / Cream", emoji: "🤍", image: "assets/images/options/q3_opt8.svg" }
            ]
        },
        {
            id: 4,
            text: "Where would I love to go on our dream date? ☕",
            options: [
                { id: 1, text: "Cozy café with sweet desserts", emoji: "🧁", image: "assets/images/options/q4_opt1.svg" },
                { id: 2, text: "Late night drive & street food", emoji: "🚗", image: "assets/images/options/q4_opt2.svg" },
                { id: 3, text: "Cuddling at home watching movies", emoji: "🛋️", image: "assets/images/options/q4_opt3.svg" },
                { id: 4, text: "Sunset beach walk holding hands", emoji: "🌅", image: "assets/images/options/q4_opt4.svg" },
                { id: 5, text: "Fancy candlelit dinner", emoji: "🕯️", image: "assets/images/options/q4_opt5.svg" },
                { id: 6, text: "Amusement park & rollercoasters", emoji: "🎡", image: "assets/images/options/q4_opt6.svg" },
                { id: 7, text: "Stargazing picnic in the park", emoji: "⛺", image: "assets/images/options/q4_opt7.svg" },
                { id: 8, text: "Arcade games & photo booths", emoji: "🕹️", image: "assets/images/options/q4_opt8.svg" }
            ]
        },
        {
            id: 5,
            text: "What makes me angry or moody easily? 😤",
            options: [
                { id: 1, text: "When I am hungry (Hangry)", emoji: "🍔", image: "assets/images/options/q5_opt1.svg" },
                { id: 2, text: "Slow replies or being ignored", emoji: "📵", image: "assets/images/options/q5_opt2.svg" },
                { id: 3, text: "Waking me up from sweet sleep", emoji: "😴", image: "assets/images/options/q5_opt3.svg" },
                { id: 4, text: "Cancelled plans at the last minute", emoji: "🗓️", image: "assets/images/options/q5_opt4.svg" },
                { id: 5, text: "Lies or hiding secrets", emoji: "🙅", image: "assets/images/options/q5_opt5.svg" },
                { id: 6, text: "Hot sweating weather", emoji: "🥵", image: "assets/images/options/q5_opt6.svg" },
                { id: 7, text: "Slow lagging Wi-Fi connection", emoji: "📶", image: "assets/images/options/q5_opt7.svg" },
                { id: 8, text: "When someone steals my food", emoji: "🍟", image: "assets/images/options/q5_opt8.svg" }
            ]
        },
        {
            id: 6,
            text: "What makes me happy instantly? 🧸",
            options: [
                { id: 1, text: "Tasty snacks & Boba tea", emoji: "🧋", image: "assets/images/options/q6_opt1.svg" },
                { id: 2, text: "Warm tight hugs from you", emoji: "🫂", image: "assets/images/options/q6_opt2.svg" },
                { id: 3, text: "Surprise cute gifts or flowers", emoji: "💐", image: "assets/images/options/q6_opt3.svg" },
                { id: 4, text: "Unplanned cuddles & nap time", emoji: "🛌", image: "assets/images/options/q6_opt4.svg" },
                { id: 5, text: "A sweet heartfelt compliment", emoji: "🥰", image: "assets/images/options/q6_opt5.svg" },
                { id: 6, text: "Spontaneous shopping trip", emoji: "🛍️", image: "assets/images/options/q6_opt6.svg" },
                { id: 7, text: "Listening to my comfort song", emoji: "🎶", image: "assets/images/options/q6_opt7.svg" },
                { id: 8, text: "Receiving a cute love text", emoji: "💌", image: "assets/images/options/q6_opt8.svg" }
            ]
        },
        {
            id: 7,
            text: "What is my ultimate dream vacation? 🏖️",
            options: [
                { id: 1, text: "Beach resort in Maldives", emoji: "🏝️", image: "assets/images/options/q7_opt1.svg" },
                { id: 2, text: "Tokyo, Japan (Anime & food)", emoji: "🗼", image: "assets/images/options/q7_opt2.svg" },
                { id: 3, text: "Romantic Paris streets", emoji: "🥐", image: "assets/images/options/q7_opt3.svg" },
                { id: 4, text: "Snowy cabin in Switzerland", emoji: "🏔️", image: "assets/images/options/q7_opt4.svg" },
                { id: 5, text: "Disney World & fairy castles", emoji: "🏰", image: "assets/images/options/q7_opt5.svg" },
                { id: 6, text: "Bali tropical island hopping", emoji: "🥥", image: "assets/images/options/q7_opt6.svg" },
                { id: 7, text: "New York City skyline lights", emoji: "🏙️", image: "assets/images/options/q7_opt7.svg" },
                { id: 8, text: "Cozy camper van road trip", emoji: "🚐", image: "assets/images/options/q7_opt8.svg" }
            ]
        },
        {
            id: 8,
            text: "What is my biggest comfort food / guilty pleasure? 🍜",
            options: [
                { id: 1, text: "Hot spicy ramen / Maggie", emoji: "🍜", image: "assets/images/options/q8_opt1.svg" },
                { id: 2, text: "Extra cheesy loaded pizza", emoji: "🍕", image: "assets/images/options/q8_opt2.svg" },
                { id: 3, text: "Chocolate ice cream tub", emoji: "🍨", image: "assets/images/options/q8_opt3.svg" },
                { id: 4, text: "Crunchy potato chips", emoji: "🥔", image: "assets/images/options/q8_opt4.svg" },
                { id: 5, text: "Sweet glazed donuts", emoji: "🍩", image: "assets/images/options/q8_opt5.svg" },
                { id: 6, text: "Crispy fried chicken", emoji: "🍗", image: "assets/images/options/q8_opt6.svg" },
                { id: 7, text: "Fluffy pancakes with syrup", emoji: "🥞", image: "assets/images/options/q8_opt7.svg" },
                { id: 8, text: "Warm chocolate chip cookies", emoji: "🍪", image: "assets/images/options/q8_opt8.svg" }
            ]
        },
        {
            id: 9,
            text: "What is my favourite way to spend time with you? 💕",
            options: [
                { id: 1, text: "Talking for hours about everything", emoji: "🗣️", image: "assets/images/options/q9_opt1.svg" },
                { id: 2, text: "Silent comfortable cuddles", emoji: "🛋️", image: "assets/images/options/q9_opt2.svg" },
                { id: 3, text: "Going out street-food hunting", emoji: "🌮", image: "assets/images/options/q9_opt3.svg" },
                { id: 4, text: "Playful teasing and laughing", emoji: "🤭", image: "assets/images/options/q9_opt4.svg" },
                { id: 5, text: "Long late-night car drives", emoji: "🚗", image: "assets/images/options/q9_opt5.svg" },
                { id: 6, text: "Watching shows under warm blankets", emoji: "🎬", image: "assets/images/options/q9_opt6.svg" },
                { id: 7, text: "Taking goofy cute selfies", emoji: "📸", image: "assets/images/options/q9_opt7.svg" },
                { id: 8, text: "Playing games together", emoji: "🎮", image: "assets/images/options/q9_opt8.svg" }
            ]
        },
        {
            id: 10,
            text: "What gift would make me the happiest? 🎁",
            options: [
                { id: 1, text: "A giant fluffy plush teddy bear", emoji: "🧸", image: "assets/images/options/q10_opt1.svg" },
                { id: 2, text: "A handwritten love letter", emoji: "💌", image: "assets/images/options/q10_opt2.svg" },
                { id: 3, text: "Pretty cute necklace or ring", emoji: "💍", image: "assets/images/options/q10_opt3.svg" },
                { id: 4, text: "My favourite fragrance / perfume", emoji: "🌸", image: "assets/images/options/q10_opt4.svg" },
                { id: 5, text: "Treating me to a luxury dinner", emoji: "🍽️", image: "assets/images/options/q10_opt5.svg" },
                { id: 6, text: "Cozy oversized hoodie", emoji: "🧥", image: "assets/images/options/q10_opt6.svg" },
                { id: 7, text: "Surprise trip or concert tickets", emoji: "🎟️", image: "assets/images/options/q10_opt7.svg" },
                { id: 8, text: "Handmade memory scrapbook", emoji: "📖", image: "assets/images/options/q10_opt8.svg" }
            ]
        }
    ];

    // State
    const state = {
        currentStep: 1,
        currentQuestionIndex: 0,
        creatorNickname: '',
        relationshipType: 'partner',
        quizTitle: '',
        expirationHours: 3,
        // Default to option 1 for all 10 questions
        selections: { 1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 1, 10: 1 },
        generatedFourOptions: {}
    };

    // DOM Elements
    let step1El, step2El, step3El, step4El;
    let qNumberEl, qProgressFill, qNavDotsEl;
    let qTitleEl;
    let poolListEl;
    let builderErrorsEl;

    function initBuilder() {
        step1El = document.getElementById('step-1-personalize');
        step2El = document.getElementById('step-2-questions');
        step3El = document.getElementById('step-3-preview');
        step4El = document.getElementById('step-4-success');

        qNumberEl = document.getElementById('q-current-num');
        qProgressFill = document.getElementById('q-progress-fill');
        qNavDotsEl = document.getElementById('q-nav-dots');
        qTitleEl = document.getElementById('builder-question-heading');
        poolListEl = document.getElementById('builder-pool-list');
        builderErrorsEl = document.getElementById('builder-error-box');

        const savedNickname = localStorage.getItem('bubu_last_creator_nickname');
        if (savedNickname) {
            const nickInput = document.getElementById('creator-nickname');
            if (nickInput) nickInput.value = savedNickname;
        }

        bindEvents();
        generateRandomFourOptionsForAll();
        renderNavDots();
    }

    // Pick 1 right answer + 3 random from the remaining 7 options
    function generateFourForQuestion(qIndex) {
        const q = QUESTION_POOL[qIndex];
        const selectedId = state.selections[q.id] || q.options[0].id;
        const rightOpt = q.options.find(o => o.id === selectedId) || q.options[0];
        const otherOpts = q.options.filter(o => o.id !== selectedId);

        // Shuffle remaining 7 options and pick 3
        const shuffledOthers = [...otherOpts].sort(() => 0.5 - Math.random());
        const threeDistractors = shuffledOthers.slice(0, 3);

        // Combine 1 right + 3 distractors
        const four = [
            { text: rightOpt.text, emoji: rightOpt.emoji, image_path: rightOpt.image, is_correct: true, opt_id: rightOpt.id },
            ...threeDistractors.map(d => ({ text: d.text, emoji: d.emoji, image_path: d.image, is_correct: false, opt_id: d.id }))
        ];

        // Shuffle the 4 options
        four.sort(() => 0.5 - Math.random());
        return four;
    }

    function generateRandomFourOptionsForAll() {
        QUESTION_POOL.forEach((q, idx) => {
            state.generatedFourOptions[q.id] = generateFourForQuestion(idx);
        });
    }

    function bindEvents() {
        // Step 1: Next
        const step1NextBtn = document.getElementById('step-1-next-btn');
        if (step1NextBtn) {
            step1NextBtn.addEventListener('click', () => {
                const nickInput = document.getElementById('creator-nickname');
                const relInput = document.getElementById('relationship-type');
                const titleInput = document.getElementById('quiz-title');
                const expiryInput = document.getElementById('expiration-hours');

                const nickname = nickInput.value.trim();
                if (!nickname) {
                    showError('Please enter your nickname! 💗');
                    nickInput.focus();
                    return;
                }

                state.creatorNickname = nickname;
                state.relationshipType = relInput ? relInput.value : 'partner';
                state.quizTitle = titleInput ? titleInput.value.trim() : '';
                state.expirationHours = expiryInput ? parseInt(expiryInput.value, 10) : 3;

                localStorage.setItem('bubu_last_creator_nickname', nickname);
                clearError();
                goToStep(2);
                loadQuestion(0);
            });
        }

        // Previous
        const prevQBtn = document.getElementById('prev-question-btn');
        if (prevQBtn) {
            prevQBtn.addEventListener('click', () => {
                if (state.currentQuestionIndex > 0) {
                    loadQuestion(state.currentQuestionIndex - 1);
                } else {
                    goToStep(1);
                }
            });
        }

        // Next
        const nextQBtn = document.getElementById('next-question-btn');
        if (nextQBtn) {
            nextQBtn.addEventListener('click', () => {
                if (state.currentQuestionIndex < 9) {
                    loadQuestion(state.currentQuestionIndex + 1);
                } else {
                    renderPreview();
                    goToStep(3);
                }
            });
        }

        // Preview Shortcut
        const previewBtn = document.getElementById('preview-quiz-btn');
        if (previewBtn) {
            previewBtn.addEventListener('click', () => {
                renderPreview();
                goToStep(3);
            });
        }

        // Back from Preview
        const backToEditBtn = document.getElementById('back-to-edit-btn');
        if (backToEditBtn) {
            backToEditBtn.addEventListener('click', () => {
                goToStep(2);
                loadQuestion(state.currentQuestionIndex);
            });
        }

        // Publish
        const publishBtn = document.getElementById('publish-quiz-btn');
        if (publishBtn) {
            publishBtn.addEventListener('click', publishQuiz);
        }
    }

    function goToStep(stepNumber) {
        state.currentStep = stepNumber;
        step1El.style.display = stepNumber === 1 ? 'block' : 'none';
        step2El.style.display = stepNumber === 2 ? 'block' : 'none';
        step3El.style.display = stepNumber === 3 ? 'block' : 'none';
        step4El.style.display = stepNumber === 4 ? 'block' : 'none';
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function renderNavDots() {
        if (!qNavDotsEl) return;
        qNavDotsEl.innerHTML = '';
        QUESTION_POOL.forEach((q, i) => {
            const isAnswered = Boolean(state.selections[q.id]);
            const dot = document.createElement('div');
            dot.className = `q-dot ${i === state.currentQuestionIndex ? 'active' : ''} ${isAnswered ? 'completed' : ''}`;
            dot.textContent = isAnswered ? '✓' : (i + 1);
            dot.title = `Question ${i + 1}`;
            dot.addEventListener('click', () => {
                loadQuestion(i);
            });
            qNavDotsEl.appendChild(dot);
        });
    }

    function loadQuestion(index) {
        state.currentQuestionIndex = index;
        const q = QUESTION_POOL[index];

        if (qNumberEl) qNumberEl.textContent = `Question ${index + 1} of 10`;
        if (qProgressFill) qProgressFill.style.width = `${((index + 1) / 10) * 100}%`;
        if (qTitleEl) qTitleEl.textContent = q.text;

        const nextBtn = document.getElementById('next-question-btn');
        if (nextBtn) {
            nextBtn.innerHTML = index === 9 ? '<span>Review Quiz 🔍</span>' : '<span>Next Question</span> <span>👉</span>';
        }

        renderEightOptionCards(q);
        renderNavDots();
        clearError();
    }

    // Renders the 8 automatic non-editable cards: 1 option per line, with image & name
    function renderEightOptionCards(question) {
        if (!poolListEl) return;
        poolListEl.innerHTML = '';

        const currentSelectedId = state.selections[question.id];

        question.options.forEach((opt, idx) => {
            const isSelected = (currentSelectedId === opt.id);
            const letter = String.fromCharCode(65 + idx);

            const card = document.createElement('div');
            card.className = `pool-option-line-card ${isSelected ? 'selected' : ''}`;
            card.setAttribute('role', 'radio');
            card.setAttribute('aria-checked', isSelected ? 'true' : 'false');
            card.setAttribute('tabindex', '0');

            card.innerHTML = `
                ${isSelected ? '<span class="pool-option-badge">My Answer 💕</span>' : ''}
                <div class="pool-option-line-thumb">
                    <img src="${window.APP_CONFIG.baseUrl}/${opt.image}" alt="${escapeHtml(opt.text)}" onerror="this.src='${window.APP_CONFIG.baseUrl}/assets/images/stickers/food.svg'">
                </div>
                <div class="pool-option-line-info">
                    <span class="pool-option-line-title">${escapeHtml(opt.text)}</span>
                </div>
                <div class="pool-option-check-circle">${isSelected ? '✓' : ''}</div>
            `;

            const onSelect = () => {
                state.selections[question.id] = opt.id;
                state.generatedFourOptions[question.id] = generateFourForQuestion(state.currentQuestionIndex);

                renderEightOptionCards(question);
                renderNavDots();
                window.showToast(`Selected: "${opt.text}" 💕`);

                // Smooth advance to next question after 400ms
                setTimeout(() => {
                    if (state.currentQuestionIndex < 9) {
                        loadQuestion(state.currentQuestionIndex + 1);
                    }
                }, 400);
            };

            card.addEventListener('click', onSelect);
            card.addEventListener('keydown', (e) => {
                if (e.key === ' ' || e.key === 'Enter') {
                    e.preventDefault();
                    onSelect();
                }
            });

            poolListEl.appendChild(card);
        });
    }

    // Renders Preview of the 10 questions with 4 options each (1 right + 3 random from 7)
    function renderPreview() {
        const previewListEl = document.getElementById('preview-questions-list');
        if (!previewListEl) return;

        previewListEl.innerHTML = '';

        QUESTION_POOL.forEach((q, idx) => {
            const fourOpts = state.generatedFourOptions[q.id] || generateFourForQuestion(idx);

            const card = document.createElement('div');
            card.className = 'card';
            card.style.marginBottom = '1.25rem';
            card.style.padding = '1.25rem';

            let optsHtml = '';
            fourOpts.forEach((opt, optIdx) => {
                const letter = String.fromCharCode(65 + optIdx);
                const isRight = opt.is_correct;
                optsHtml += `
                    <div style="padding: 0.65rem 0.95rem; margin-top: 0.5rem; border-radius: 14px; border: 2px solid ${isRight ? '#FF82AC' : '#F0E2E7'}; background: ${isRight ? '#FFF5F8' : '#ffffff'}; display: flex; align-items: center; justify-content: space-between;">
                        <div style="display: flex; align-items: center; gap: 0.75rem;">
                            <span style="font-weight: 700; color: ${isRight ? '#F45187' : '#7E6C77'}; min-width: 20px;">${letter}.</span>
                            <div style="width: 36px; height: 36px; min-width: 36px; border-radius: 10px; overflow: hidden; background: #FFF0F5; display: flex; align-items: center; justify-content: center; border: 1px solid #FFE0EB;">
                                <img src="${window.APP_CONFIG.baseUrl}/${opt.image_path}" style="width: 100%; height: 100%; object-fit: cover;" alt="${escapeHtml(opt.text)}">
                            </div>
                            <strong style="color: var(--text-dark);">${escapeHtml(opt.text)}</strong>
                        </div>
                        ${isRight ? '<span class="badge badge-pink">Your Choice 💕</span>' : '<span style="font-size: 0.8rem; color: #9E8C96;">Random distractor</span>'}
                    </div>
                `;
            });

            card.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem; flex-wrap: wrap; gap: 0.5rem;">
                    <span class="badge badge-lavender">Question ${idx + 1} of 10</span>
                    <div style="display: flex; gap: 0.5rem;">
                        <button type="button" class="btn btn-outline btn-sm shuffle-distractors-btn" data-q-index="${idx}">
                            🎲 Re-roll 3 Choices
                        </button>
                        <button type="button" class="btn btn-secondary btn-sm change-answer-btn" data-q-index="${idx}">
                            ✏️ Change Pick
                        </button>
                    </div>
                </div>
                <h4 style="font-family: var(--font-heading); font-size: 1.15rem; color: var(--text-dark); margin-bottom: 0.5rem;">
                    ${escapeHtml(q.text)}
                </h4>
                <div>${optsHtml}</div>
            `;

            const changeBtn = card.querySelector('.change-answer-btn');
            changeBtn.addEventListener('click', () => {
                goToStep(2);
                loadQuestion(idx);
            });

            const shuffleBtn = card.querySelector('.shuffle-distractors-btn');
            shuffleBtn.addEventListener('click', () => {
                state.generatedFourOptions[q.id] = generateFourForQuestion(idx);
                renderPreview();
                window.showToast('Re-rolled 3 random choices! 🎲');
            });

            previewListEl.appendChild(card);
        });
    }

    async function publishQuiz() {
        const publishBtn = document.getElementById('publish-quiz-btn');
        if (publishBtn) {
            publishBtn.disabled = true;
            publishBtn.innerHTML = '<span>⏳</span> Publishing your quiz...';
        }

        const formattedQuestions = QUESTION_POOL.map((q, idx) => {
            const four = state.generatedFourOptions[q.id] || generateFourForQuestion(idx);
            return {
                text: q.text,
                options: four.map(o => ({
                    text: o.text,
                    emoji: o.emoji,
                    image_path: o.image_path,
                    is_correct: o.is_correct
                }))
            };
        });

        const payload = {
            creator_nickname: state.creatorNickname,
            relationship_type: state.relationshipType,
            quiz_title: state.quizTitle,
            expiration_hours: state.expirationHours,
            questions: formattedQuestions
        };

        try {
            const resp = await fetch(window.APP_CONFIG.baseUrl + '/api/create-quiz.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': window.APP_CONFIG.csrfToken
                },
                body: JSON.stringify(payload)
            });

            const data = await resp.json();

            if (!data.success) {
                showError(data.error || 'Failed to create quiz. Please try again.');
                if (publishBtn) {
                    publishBtn.disabled = false;
                    publishBtn.innerHTML = '<span>💕</span> Publish & Generate Link';
                }
                return;
            }

            renderSuccessScreen(data);
            goToStep(4);
            window.triggerConfetti();
        } catch (err) {
            console.error('Quiz publish error:', err);
            showError('Network error connecting to the server. Please tap Publish again.');
            if (publishBtn) {
                publishBtn.disabled = false;
                publishBtn.innerHTML = '<span>💕</span> Publish & Generate Link';
            }
        }
    }

    function renderSuccessScreen(data) {
        const linkInput = document.getElementById('shareable-link-input');
        const dashBtn = document.getElementById('creator-dashboard-btn');
        const copyBtn = document.getElementById('copy-link-btn');
        const whatsappBtn = document.getElementById('whatsapp-share-btn');
        const telegramBtn = document.getElementById('telegram-share-btn');
        const nativeShareBtn = document.getElementById('native-share-btn');
        const downloadCardBtn = document.getElementById('download-card-btn');
        const expiryNoticeEl = document.getElementById('expiry-notice-badge');

        if (linkInput) linkInput.value = data.play_url;
        if (dashBtn) dashBtn.href = data.dashboard_url;
        if (expiryNoticeEl) {
            expiryNoticeEl.textContent = `Expires in ${state.expirationHours} hours (${new Date(data.expires_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})})`;
        }

        const inviteMsg = `Heyyy! 💗 I made a tiny quiz to test how well you know me. Take the Test of Bubu here: ${data.play_url} 🐻💕`;

        if (whatsappBtn) {
            whatsappBtn.href = `https://api.whatsapp.com/send?text=${encodeURIComponent(inviteMsg)}`;
        }

        if (telegramBtn) {
            telegramBtn.href = `https://t.me/share/url?url=${encodeURIComponent(data.play_url)}&text=${encodeURIComponent(inviteMsg)}`;
        }

        if (copyBtn) {
            copyBtn.onclick = () => {
                window.copyToClipboard(data.play_url, 'Link copied! Send it to your Bubu now! 💗');
            };
        }

        if (nativeShareBtn) {
            nativeShareBtn.onclick = () => {
                window.shareQuiz('Test of Bubu 💗', inviteMsg, data.play_url);
            };
        }

        if (downloadCardBtn) {
            downloadCardBtn.onclick = () => {
                window.generateShareCard({
                    creatorName: state.creatorNickname,
                    url: data.play_url
                });
            };
        }
    }

    function showError(msg) {
        if (!builderErrorsEl) return;
        builderErrorsEl.textContent = msg;
        builderErrorsEl.style.display = 'block';
        builderErrorsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function clearError() {
        if (!builderErrorsEl) return;
        builderErrorsEl.textContent = '';
        builderErrorsEl.style.display = 'none';
    }

    function escapeHtml(text) {
        if (!text) return '';
        const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
        return String(text).replace(/[&<>"']/g, m => map[m]);
    }

    document.addEventListener('DOMContentLoaded', initBuilder);

})();

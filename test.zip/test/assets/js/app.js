/**
 * Test of Bubu 💗 - Global Application JavaScript
 */

(function() {
    'use strict';

    // Toast Notification System
    window.showToast = function(message, duration = 3500) {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const toast = document.createElement('div');
        toast.className = 'toast';
        toast.innerHTML = `<span>💗</span> <span>${message}</span>`;
        container.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(15px)';
            toast.style.transition = 'all 0.3s ease';
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.parentNode.removeChild(toast);
                }
            }, 300);
        }, duration);
    };

    // Clipboard Copy Helper
    window.copyToClipboard = async function(text, successMsg = 'Link copied! Now go test your Bubu! 💗') {
        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(text);
                window.showToast(successMsg);
                return true;
            } else {
                // Fallback for non-https or older browser
                const textArea = document.createElement('textarea');
                textArea.value = text;
                textArea.style.position = 'fixed';
                textArea.style.left = '-999999px';
                textArea.style.top = '-999999px';
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                const successful = document.execCommand('copy');
                document.body.removeChild(textArea);
                if (successful) {
                    window.showToast(successMsg);
                    return true;
                }
            }
        } catch (err) {
            console.error('Failed to copy text: ', err);
        }
        window.showToast('Please copy the link manually: ' + text);
        return false;
    };

    // Native Web Share API
    window.shareQuiz = async function(title, text, url) {
        if (navigator.share) {
            try {
                await navigator.share({
                    title: title,
                    text: text,
                    url: url
                });
                return true;
            } catch (err) {
                if (err.name !== 'AbortError') {
                    console.warn('Web Share failed, copying to clipboard', err);
                    window.copyToClipboard(url);
                }
            }
        } else {
            window.copyToClipboard(url);
        }
        return false;
    };

    // Confetti Burst Generator (Pure JS + CSS)
    window.triggerConfetti = function() {
        const container = document.createElement('div');
        container.className = 'confetti-container';
        document.body.appendChild(container);

        const colors = ['#FF82AC', '#F45187', '#FFE0D2', '#D9F5E5', '#E9DFFF', '#FFE082'];
        const count = 50;

        for (let i = 0; i < count; i++) {
            const piece = document.createElement('div');
            piece.className = 'confetti-piece';
            piece.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
            piece.style.left = Math.random() * 100 + 'vw';
            piece.style.animationDelay = Math.random() * 1.5 + 's';
            piece.style.width = (Math.random() * 8 + 6) + 'px';
            piece.style.height = (Math.random() * 12 + 8) + 'px';
            piece.style.borderRadius = Math.random() > 0.5 ? '50%' : '3px';
            container.appendChild(piece);
        }

        setTimeout(() => {
            if (container.parentNode) {
                container.parentNode.removeChild(container);
            }
        }, 5000);
    };

    // Rotating Cute Banner Messages
    const cuteMessages = [
        "Think carefully, Bubu is watching 👀",
        "One quiz, unlimited cute drama 💗",
        "Let's find out who pays attention! 🐻",
        "Warning: unexpected cuteness ahead ✨",
        "10 questions to prove true love 🌸",
        "Don't worry, snacks can fix any score 🍫"
    ];

    function initCuteBanner() {
        const bannerText = document.getElementById('cute-banner-text');
        if (!bannerText) return;

        let currentIndex = 0;
        setInterval(() => {
            currentIndex = (currentIndex + 1) % cuteMessages.length;
            bannerText.style.opacity = '0';
            setTimeout(() => {
                bannerText.textContent = cuteMessages[currentIndex];
                bannerText.style.opacity = '1';
            }, 300);
        }, 4500);
    }

    // Privacy Modal Controls
    function initModals() {
        const openBtn = document.getElementById('open-privacy-btn');
        const modal = document.getElementById('privacy-modal');
        const closeBtn = document.getElementById('close-privacy-btn');
        const ackBtn = document.getElementById('ack-privacy-btn');

        if (!modal) return;

        const openModal = (e) => {
            if (e) e.preventDefault();
            modal.classList.add('active');
            modal.setAttribute('aria-hidden', 'false');
        };

        const closeModal = () => {
            modal.classList.remove('active');
            modal.setAttribute('aria-hidden', 'true');
        };

        if (openBtn) openBtn.addEventListener('click', openModal);
        if (closeBtn) closeBtn.addEventListener('click', closeModal);
        if (ackBtn) ackBtn.addEventListener('click', closeModal);

        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && modal.classList.contains('active')) {
                closeModal();
            }
        });
    }

    // Downloadable Cute Share Card Generator (HTML5 Canvas)
    window.generateShareCard = function(options) {
        const {
            creatorName = 'Bubu',
            score = null,
            total = 10,
            headline = 'How well do you know me?',
            url = window.location.href,
            characterImgSrc = null
        } = options;

        const canvas = document.createElement('canvas');
        canvas.width = 800;
        canvas.height = 800;
        const ctx = canvas.getContext('2d');

        // Draw background gradient
        const grad = ctx.createLinearGradient(0, 0, 800, 800);
        grad.addColorStop(0, '#FFF5F8');
        grad.addColorStop(0.5, '#FFEAF1');
        grad.addColorStop(1, '#F3E5F5');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 800, 800);

        // Cute rounded border card
        ctx.fillStyle = '#FFFFFF';
        ctx.strokeStyle = '#FFD0E0';
        ctx.lineWidth = 8;
        roundRect(ctx, 40, 40, 720, 720, 36);
        ctx.fill();
        ctx.stroke();

        // Header Title
        ctx.fillStyle = '#F45187';
        ctx.font = 'bold 38px "Fredoka", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('Test of Bubu 💗', 400, 110);

        // Subtitle
        ctx.fillStyle = '#392D35';
        ctx.font = 'bold 28px "Nunito", sans-serif';
        if (score !== null) {
            ctx.fillText(`${creatorName}'s Quiz Result`, 400, 160);

            // Score Circle
            ctx.fillStyle = '#FFF0F5';
            ctx.beginPath();
            ctx.arc(400, 290, 95, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#FF82AC';
            ctx.lineWidth = 6;
            ctx.stroke();

            ctx.fillStyle = '#F45187';
            ctx.font = 'bold 74px "Fredoka", sans-serif';
            ctx.fillText(`${score}/${total}`, 400, 315);

            ctx.fillStyle = '#7E6C77';
            ctx.font = 'bold 22px "Nunito", sans-serif';
            ctx.fillText(`${headline}`, 400, 440);
        } else {
            ctx.fillText(`How well does your Bubu know you?`, 400, 170);

            // Character placeholder / invite text
            ctx.fillStyle = '#7E6C77';
            ctx.font = 'bold 24px "Nunito", sans-serif';
            ctx.fillText(`10 cute questions created by ${creatorName} 💕`, 400, 240);
        }

        // URL Box
        ctx.fillStyle = '#FAF5F8';
        roundRect(ctx, 100, 560, 600, 75, 20);
        ctx.fill();
        ctx.fillStyle = '#392D35';
        ctx.font = 'bold 22px "Nunito", sans-serif';
        ctx.fillText(url, 400, 608);

        // Footer Brand
        ctx.fillStyle = '#F45187';
        ctx.font = 'bold 22px "Nunito", sans-serif';
        ctx.fillText('🐻 Play now at Test of Bubu 🐻', 400, 710);

        // Download as PNG
        const link = document.createElement('a');
        link.download = `bubu-card-${creatorName.toLowerCase().replace(/\s+/g, '-')}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
        window.showToast('Story card downloaded! 💖');
    };

    function roundRect(ctx, x, y, width, height, radius) {
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + width - radius, y);
        ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
        ctx.lineTo(x + width, y + height - radius);
        ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
        ctx.lineTo(x + radius, y + height);
        ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
    }

    // Initialize on DOM load
    document.addEventListener('DOMContentLoaded', () => {
        initCuteBanner();
        initModals();
    });

})();

/**
 * Test of Bubu 💗 - Participant Quiz Player Engine
 * Secure Answering, Client Idempotency, Server Scoring, Cartoon Reactions
 */

(function() {
    'use strict';

    // Player State
    const playerState = {
        quizCode: window.QUIZ_DATA ? window.QUIZ_DATA.public_code : '',
        quizTitle: window.QUIZ_DATA ? window.QUIZ_DATA.quiz_title : '',
        creatorNickname: window.QUIZ_DATA ? window.QUIZ_DATA.creator_nickname : 'Your Bubu',
        questions: window.QUIZ_DATA ? window.QUIZ_DATA.questions : [],
        participantNickname: '',
        currentQuestionIndex: 0,
        selectedAnswers: {}, // { questionId: selectedOptionId }
        attemptToken: generatePlayerToken(),
        isSubmitting: false,
        resultData: null
    };

    function generatePlayerToken() {
        return 'att_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15) + Date.now();
    }

    // DOM Elements
    let welcomeView, playerView, reviewView, resultView;
    let pQuestionNumEl, pProgressFillEl, pQuestionTextEl, pOptionsListEl;
    let prevBtn, nextBtn, finishReviewBtn;

    function initPlayer() {
        welcomeView = document.getElementById('player-welcome-view');
        playerView = document.getElementById('player-active-view');
        reviewView = document.getElementById('player-review-view');
        resultView = document.getElementById('player-result-view');

        pQuestionNumEl = document.getElementById('player-q-num');
        pProgressFillEl = document.getElementById('player-progress-fill');
        pQuestionTextEl = document.getElementById('player-question-text');
        pOptionsListEl = document.getElementById('player-options-list');

        prevBtn = document.getElementById('player-prev-btn');
        nextBtn = document.getElementById('player-next-btn');
        finishReviewBtn = document.getElementById('player-finish-review-btn');

        bindEvents();
    }

    function bindEvents() {
        // Welcome Screen: Start Quiz
        const startBtn = document.getElementById('player-start-btn');
        if (startBtn) {
            startBtn.addEventListener('click', () => {
                const nickInput = document.getElementById('participant-nickname-input');
                playerState.participantNickname = nickInput && nickInput.value.trim() ? nickInput.value.trim() : 'Your Bubu';
                showView('player');
                loadQuestion(0);
            });
        }

        // Previous Question
        if (prevBtn) {
            prevBtn.addEventListener('click', () => {
                if (playerState.currentQuestionIndex > 0) {
                    loadQuestion(playerState.currentQuestionIndex - 1);
                }
            });
        }

        // Next Question
        if (nextBtn) {
            nextBtn.addEventListener('click', () => {
                const curQ = playerState.questions[playerState.currentQuestionIndex];
                if (!playerState.selectedAnswers[curQ.id]) {
                    window.showToast('Please pick an answer before moving forward! 🐻💗');
                    return;
                }

                if (playerState.currentQuestionIndex < playerState.questions.length - 1) {
                    loadQuestion(playerState.currentQuestionIndex + 1);
                } else {
                    renderReview();
                    showView('review');
                }
            });
        }

        // Back to Quiz from Review
        const backToQuizBtn = document.getElementById('review-back-btn');
        if (backToQuizBtn) {
            backToQuizBtn.addEventListener('click', () => {
                showView('player');
                loadQuestion(playerState.questions.length - 1);
            });
        }

        // Final Submit from Review
        const submitQuizBtn = document.getElementById('submit-quiz-final-btn');
        if (submitQuizBtn) {
            submitQuizBtn.addEventListener('click', submitAnswersToServer);
        }
    }

    function showView(viewName) {
        if (welcomeView) welcomeView.style.display = viewName === 'welcome' ? 'block' : 'none';
        if (playerView) playerView.style.display = viewName === 'player' ? 'block' : 'none';
        if (reviewView) reviewView.style.display = viewName === 'review' ? 'block' : 'none';
        if (resultView) resultView.style.display = viewName === 'result' ? 'block' : 'none';

        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function loadQuestion(index) {
        playerState.currentQuestionIndex = index;
        const q = playerState.questions[index];
        const total = playerState.questions.length;

        if (pQuestionNumEl) pQuestionNumEl.textContent = `Question ${index + 1} of ${total}`;
        if (pProgressFillEl) pProgressFillEl.style.width = `${((index + 1) / total) * 100}%`;
        if (pQuestionTextEl) pQuestionTextEl.textContent = q.question_text;

        // Button states
        if (prevBtn) prevBtn.style.visibility = index === 0 ? 'hidden' : 'visible';
        if (nextBtn) {
            nextBtn.innerHTML = index === total - 1 ? 'Review Answers 🔍' : 'Next Question 💗';
        }

        renderOptions(q);
    }

    function renderOptions(question) {
        if (!pOptionsListEl) return;
        pOptionsListEl.innerHTML = '';

        const selectedOptId = playerState.selectedAnswers[question.id] || null;

        question.options.forEach((opt, idx) => {
            const letter = String.fromCharCode(65 + idx);
            const isSelected = selectedOptId === parseInt(opt.id, 10);

            const card = document.createElement('div');
            card.className = `option-card-label ${isSelected ? 'selected' : ''}`;
            card.setAttribute('role', 'radio');
            card.setAttribute('aria-checked', isSelected ? 'true' : 'false');
            card.setAttribute('tabindex', '0');

            let mediaHtml = '';
            if (opt.option_image_path) {
                mediaHtml += `<div class="pool-option-line-thumb" style="width: 46px; height: 46px; min-width: 46px; margin-right: 0.75rem;">
                    <img src="${window.APP_CONFIG.baseUrl}/${escapeHtml(opt.option_image_path)}" alt="${escapeHtml(opt.option_text)}" onerror="this.src='${window.APP_CONFIG.baseUrl}/assets/images/stickers/food.svg'">
                </div>`;
            } else if (opt.option_emoji) {
                mediaHtml += `<div class="pool-option-line-thumb" style="width: 46px; height: 46px; min-width: 46px; margin-right: 0.75rem; font-size: 1.5rem;">
                    <span>${escapeHtml(opt.option_emoji)}</span>
                </div>`;
            }

            card.innerHTML = `
                <div class="option-indicator">${letter}</div>
                <div class="option-content" style="display: flex; align-items: center; width: 100%;">
                    ${mediaHtml}
                    <span style="font-weight: 700; font-size: 1.05rem; color: var(--text-dark);">${escapeHtml(opt.option_text)}</span>
                </div>
            `;

            // Select handler
            const selectOption = () => {
                playerState.selectedAnswers[question.id] = parseInt(opt.id, 10);
                // Re-render options to show selection
                renderOptions(question);

                // Auto-advance after small pleasant delay (350ms) if not last question
                setTimeout(() => {
                    if (playerState.currentQuestionIndex < playerState.questions.length - 1) {
                        loadQuestion(playerState.currentQuestionIndex + 1);
                    } else {
                        renderReview();
                        showView('review');
                    }
                }, 350);
            };

            card.addEventListener('click', selectOption);
            card.addEventListener('keydown', (e) => {
                if (e.key === ' ' || e.key === 'Enter') {
                    e.preventDefault();
                    selectOption();
                }
            });

            pOptionsListEl.appendChild(card);
        });
    }

    function renderReview() {
        const reviewListEl = document.getElementById('review-answers-list');
        if (!reviewListEl) return;

        reviewListEl.innerHTML = '';
        playerState.questions.forEach((q, idx) => {
            const selectedOptId = playerState.selectedAnswers[q.id];
            const selectedOpt = q.options.find(o => parseInt(o.id, 10) === selectedOptId);

            const item = document.createElement('div');
            item.className = 'card';
            item.style.marginBottom = '0.85rem';
            item.style.padding = '1rem 1.25rem';

            item.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.35rem;">
                    <span class="badge badge-lavender">Question ${idx + 1}</span>
                    <button type="button" class="btn btn-outline btn-sm change-ans-btn" data-q-index="${idx}">Change</button>
                </div>
                <div style="font-weight: 700; color: var(--text-dark); margin-bottom: 0.35rem;">${escapeHtml(q.question_text)}</div>
                <div style="color: ${selectedOpt ? 'var(--deep-pink)' : '#D32F2F'}; font-weight: 600;">
                    Your Answer: ${selectedOpt ? (selectedOpt.option_emoji ? selectedOpt.option_emoji + ' ' : '') + escapeHtml(selectedOpt.option_text) : '<em>Not answered yet!</em>'}
                </div>
            `;

            const changeBtn = item.querySelector('.change-ans-btn');
            changeBtn.addEventListener('click', () => {
                showView('player');
                loadQuestion(idx);
            });

            reviewListEl.appendChild(item);
        });
    }

    async function submitAnswersToServer() {
        if (playerState.isSubmitting) return;

        // Check if all 10 are answered
        const answeredCount = Object.keys(playerState.selectedAnswers).length;
        if (answeredCount < playerState.questions.length) {
            window.showToast(`Please answer all ${playerState.questions.length} questions before submitting! 🐻`);
            return;
        }

        const submitBtn = document.getElementById('submit-quiz-final-btn');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span>⏳</span> Calculating your score...';
        }
        playerState.isSubmitting = true;

        const payload = {
            public_code: playerState.quizCode,
            participant_nickname: playerState.participantNickname,
            attempt_token: playerState.attemptToken,
            answers: playerState.selectedAnswers
        };

        try {
            const resp = await fetch(window.APP_CONFIG.baseUrl + '/api/submit-quiz.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': window.APP_CONFIG.csrfToken
                },
                body: JSON.stringify(payload)
            });

            const data = await resp.json();

            if (!data.success) {
                if (data.is_expired) {
                    window.location.href = window.APP_CONFIG.baseUrl + '/expired.php';
                    return;
                }
                window.showToast(data.error || 'Failed to submit quiz.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<span>💕</span> Submit My Answers';
                }
                playerState.isSubmitting = false;
                return;
            }

            playerState.resultData = data;
            renderResultScreen(data);
            showView('result');

            if (data.score >= 7) {
                window.triggerConfetti();
            }
        } catch (err) {
            console.error('Submission error:', err);
            window.showToast('Oops! Network error. Your answers are safe, please tap Submit again.');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<span>💕</span> Submit My Answers';
            }
            playerState.isSubmitting = false;
        }
    }

    function renderResultScreen(result) {
        const scoreNumEl = document.getElementById('result-score-num');
        const scorePctEl = document.getElementById('result-score-pct');
        const reactionImgEl = document.getElementById('result-reaction-img');
        const reactionHeadlineEl = document.getElementById('result-headline');
        const reactionSubheadEl = document.getElementById('result-subhead');
        const dialogueListEl = document.getElementById('result-dialogue-list');
        const badgeEl = document.getElementById('result-badge');

        const reaction = result.reaction;

        if (scoreNumEl) scoreNumEl.textContent = `${result.score}/${result.total}`;
        if (scorePctEl) scorePctEl.textContent = `${result.percentage}% Match`;

        if (badgeEl) {
            badgeEl.textContent = reaction.badge_text;
            badgeEl.style.background = reaction.badge_color;
            badgeEl.style.color = '#ffffff';
        }

        if (reactionHeadlineEl) reactionHeadlineEl.textContent = reaction.headline;
        if (reactionSubheadEl) reactionSubheadEl.textContent = reaction.subheadline;

        if (reactionImgEl) {
            reactionImgEl.src = `${window.APP_CONFIG.baseUrl}/${reaction.image}`;
            reactionImgEl.className = `reaction-character-img ${reaction.animation}`;
            reactionImgEl.onerror = () => {
                reactionImgEl.src = `${window.APP_CONFIG.baseUrl}/${reaction.image_fallback}`;
            };
        }

        // Render dialogue bubbles
        if (dialogueListEl) {
            dialogueListEl.innerHTML = '';
            reaction.conversation.forEach(conv => {
                const item = document.createElement('div');
                item.className = 'dialogue-item';
                item.innerHTML = `
                    <div class="dialogue-avatar">${conv.speaker === 'Bubu' ? '🐻' : '🐼'}</div>
                    <div class="dialogue-bubble">
                        <strong>${conv.speaker}:</strong> ${escapeHtml(conv.text)}
                    </div>
                `;
                dialogueListEl.appendChild(item);
            });
        }

        // Social sharing buttons for Result
        const whatsappBtn = document.getElementById('result-share-whatsapp');
        const telegramBtn = document.getElementById('result-share-telegram');
        const copyBtn = document.getElementById('result-copy-btn');
        const nativeShareBtn = document.getElementById('result-share-native');
        const downloadCardBtn = document.getElementById('result-download-card');

        const shareUrl = window.location.href;
        const resultShareText = `I scored ${result.score}/10 on ${playerState.creatorNickname}'s Test of Bubu! 🐻💗 How well do you know them? Take the quiz: ${shareUrl}`;

        if (whatsappBtn) {
            whatsappBtn.href = `https://api.whatsapp.com/send?text=${encodeURIComponent(resultShareText)}`;
        }

        if (telegramBtn) {
            telegramBtn.href = `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(resultShareText)}`;
        }

        if (copyBtn) {
            copyBtn.onclick = () => {
                window.copyToClipboard(shareUrl, 'Result link copied! 💗');
            };
        }

        if (nativeShareBtn) {
            nativeShareBtn.onclick = () => {
                window.shareQuiz('Test of Bubu Score!', resultShareText, shareUrl);
            };
        }

        if (downloadCardBtn) {
            downloadCardBtn.onclick = () => {
                window.generateShareCard({
                    creatorName: playerState.creatorNickname,
                    score: result.score,
                    total: result.total,
                    headline: reaction.headline,
                    url: shareUrl
                });
            };
        }
    }

    function escapeHtml(text) {
        if (!text) return '';
        const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
        return String(text).replace(/[&<>"']/g, m => map[m]);
    }

    document.addEventListener('DOMContentLoaded', initPlayer);

})();

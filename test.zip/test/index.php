<?php
/**
 * Test of Bubu 💗 - Homepage
 */

$pageTitle = 'Test of Bubu 💗 | How well does your Bubu know you?';
$pageDesc  = 'A cute cartoon couple quiz platform. Create a personalized 10-question quiz about yourself, share your link, and see how well your partner or bestie knows you!';
require_once __DIR__ . '/includes/header.php';
?>

<!-- Hero Section -->
<section class="hero-section" aria-labelledby="hero-heading">
    <div class="container">
        <div class="hero-badge-wrap">
            <span class="badge badge-pink">Made for your favourite person 💕</span>
        </div>

        <h1 id="hero-heading" class="hero-title">
            Does your Bubu <span class="highlight">REALLY</span> know you? 🐻💗
        </h1>

        <p class="hero-subtitle">
            10 cute questions. One special person. Let's see how well they remember your little secrets, favourite foods, and sweet quirks!
        </p>

        <!-- Cute Hero Illustration -->
        <div class="hero-image-wrap">
            <picture>
                <source srcset="<?= BASE_URL ?>/assets/images/bubu-hero.webp" type="image/webp">
                <img src="<?= BASE_URL ?>/assets/images/bubu-hero.png" alt="Two adorable plush cartoon bears hugging a glowing heart" class="hero-image" width="340" height="340" fetchpriority="high">
            </picture>
        </div>

        <!-- Rotating Cute Pill -->
        <div class="cute-banner" role="status">
            <span class="cute-banner-icon">✨</span>
            <span id="cute-banner-text">Think carefully, Bubu is watching 👀</span>
        </div>

        <!-- Hero Actions -->
        <div class="hero-actions">
            <a href="<?= BASE_URL ?>/create.php" class="btn btn-primary btn-lg btn-block">
                <span>💕</span> Create My Quiz
            </a>
            <a href="#enter-code-modal" class="hero-secondary-link" id="open-enter-code-btn">
                🔗 I have a quiz link
            </a>
        </div>
    </div>
</section>

<!-- How It Works Section -->
<section class="how-section" id="how-it-works" aria-labelledby="how-heading">
    <div class="container">
        <div class="section-header">
            <h2 id="how-heading" class="section-title">How It Works 🌸</h2>
            <p class="section-subtitle">Super easy, delightfully cute, and ready in just 2 minutes!</p>
        </div>

        <div class="steps-grid">
            <div class="step-card">
                <div class="step-icon-wrap" aria-hidden="true">✍️</div>
                <span class="badge badge-pink" style="margin-bottom: 0.6rem;">Step 1</span>
                <h3>Create</h3>
                <p>Pick your nickname and create 10 personalized questions about your habits, foods, and dreams.</p>
            </div>

            <div class="step-card">
                <div class="step-icon-wrap" aria-hidden="true">💌</div>
                <span class="badge badge-lavender" style="margin-bottom: 0.6rem;">Step 2</span>
                <h3>Share</h3>
                <p>Send your unique private link to your partner or bestie on WhatsApp, Telegram, or Instagram.</p>
            </div>

            <div class="step-card">
                <div class="step-icon-wrap" aria-hidden="true">🎉</div>
                <span class="badge badge-mint" style="margin-bottom: 0.6rem;">Step 3</span>
                <h3>Reveal</h3>
                <p>Watch their score, unlock adorable cartoon reactions, and find out if they are a certified soulmate!</p>
            </div>
        </div>
    </div>
</section>

<!-- Sample Question Preview Section -->
<section class="sample-section" aria-labelledby="sample-heading">
    <div class="container">
        <div class="section-header">
            <h2 id="sample-heading" class="section-title">Cute Sample Question 🍕</h2>
            <p class="section-subtitle">Here is a sneak peek of what your Bubu will see:</p>
        </div>

        <div class="card sample-quiz-card">
            <span class="badge badge-pink sample-badge">Sample Demo</span>
            <span class="badge badge-lavender" style="display: inline-block;">Question 1 of 10</span>
            
            <h3 class="sample-question-title">What is my favourite food?</h3>

            <div class="sample-options-grid">
                <div class="sample-option-item">
                    <span>🍕</span> Pizza
                </div>
                <div class="sample-option-item">
                    <span>🥟</span> Momos
                </div>
                <div class="sample-option-item">
                    <span>🍛</span> Biryani
                </div>
                <div class="sample-option-item">
                    <span>🍦</span> Ice cream
                </div>
            </div>

            <p style="font-size: 0.85rem; color: var(--text-muted); text-align: center; margin-top: 1.25rem;">
                <em>✨ You can fully customize every question, answer, and emoji in your quiz!</em>
            </p>
        </div>
    </div>
</section>

<!-- Bottom CTA Section -->
<section style="padding: 2.5rem 0 3.5rem; text-align: center;">
    <div class="container">
        <div class="card" style="background: linear-gradient(135deg, #FFF0F5, #F9EEFF); border-color: #FFD4E5; max-width: 620px; margin: 0 auto;">
            <div style="font-size: 2.5rem; margin-bottom: 0.5rem;" aria-hidden="true">🐻💖🐻</div>
            <h2 style="font-family: var(--font-heading); font-size: 1.85rem; color: var(--text-dark); margin-bottom: 0.5rem;">
                Ready to test your special person?
            </h2>
            <p style="color: var(--text-muted); margin-bottom: 1.5rem;">
                Takes under 2 minutes. No app download or sign-up needed!
            </p>
            <a href="<?= BASE_URL ?>/create.php" class="btn btn-primary btn-lg">
                <span>💕</span> Create My Bubu Quiz
            </a>
        </div>
    </div>
</section>

<!-- Enter Code Modal -->
<div id="enter-code-modal" class="modal-backdrop" aria-hidden="true">
    <div class="modal-dialog" role="dialog" aria-modal="true" aria-labelledby="enter-code-title">
        <div class="modal-header">
            <h3 id="enter-code-title">🔗 Enter Quiz Code or Link</h3>
            <button type="button" class="modal-close-btn" id="close-code-modal-btn" aria-label="Close dialog">&times;</button>
        </div>
        <div class="modal-body">
            <p style="margin-bottom: 1rem; color: var(--text-muted);">
                Paste the full quiz link or the 10-character code sent by your person:
            </p>
            <div class="form-group">
                <input type="text" id="direct-code-input" class="form-control" placeholder="e.g. 7k3mXp9qW2 or full URL">
            </div>
            <div id="code-modal-error" style="color: #D32F2F; font-size: 0.875rem; display: none; margin-top: 0.5rem;"></div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-primary btn-block" id="jump-to-quiz-btn">
                <span>🚀</span> Take Quiz
            </button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const codeModal = document.getElementById('enter-code-modal');
    const openBtn = document.getElementById('open-enter-code-btn');
    const closeBtn = document.getElementById('close-code-modal-btn');
    const jumpBtn = document.getElementById('jump-to-quiz-btn');
    const input = document.getElementById('direct-code-input');
    const errorEl = document.getElementById('code-modal-error');

    if (openBtn && codeModal) {
        openBtn.addEventListener('click', (e) => {
            e.preventDefault();
            codeModal.classList.add('active');
            input.focus();
        });
    }

    if (closeBtn && codeModal) {
        closeBtn.addEventListener('click', () => {
            codeModal.classList.remove('active');
        });
    }

    if (jumpBtn) {
        jumpBtn.addEventListener('click', () => {
            const raw = input.value.trim();
            if (!raw) {
                errorEl.textContent = 'Please enter a code or link.';
                errorEl.style.display = 'block';
                return;
            }

            let code = raw;
            if (raw.includes('code=')) {
                const match = raw.match(/code=([a-zA-Z0-9]+)/);
                if (match) code = match[1];
            } else if (raw.includes('/')) {
                const parts = raw.split('/');
                code = parts[parts.length - 1];
            }

            code = code.replace(/[^a-zA-Z0-9]/g, '');
            if (!code) {
                errorEl.textContent = 'Invalid quiz link or code.';
                errorEl.style.display = 'block';
                return;
            }

            window.location.href = window.APP_CONFIG.baseUrl + '/play.php?code=' + encodeURIComponent(code);
        });
    }
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

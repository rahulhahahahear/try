<?php
// Cute vector SVG sticker generator for quiz categories
$stickersDir = __DIR__ . '/../assets/images/stickers';
if (!is_dir($stickersDir)) {
    mkdir($stickersDir, 0755, true);
}

$stickers = [
    'food' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
        <circle cx="32" cy="32" r="30" fill="#FFE0D2"/>
        <path d="M18 42c0-7.7 6.3-14 14-14s14 6.3 14 14H18z" fill="#FF82AC"/>
        <path d="M32 20c-3 0-6 3-6 7h12c0-4-3-7-6-7z" fill="#F45187"/>
        <circle cx="26" cy="38" r="2.5" fill="#FFF"/>
        <circle cx="38" cy="38" r="2.5" fill="#FFF"/>
        <circle cx="32" cy="17" r="3" fill="#F45187"/>
    </svg>',
    
    'travel' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
        <circle cx="32" cy="32" r="30" fill="#D9F5E5"/>
        <path d="M16 36l20-14 12 4-10 10 12 2-4 4-12-1-8 6-4-1 4-6-8-4z" fill="#F45187"/>
        <circle cx="44" cy="22" r="2" fill="#FFF"/>
        <path d="M22 46c4-2 16-2 20 0" stroke="#FF82AC" stroke-width="3" stroke-linecap="round" fill="none"/>
    </svg>',
    
    'gifts' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
        <circle cx="32" cy="32" r="30" fill="#E9DFFF"/>
        <rect x="18" y="28" width="28" height="22" rx="4" fill="#FF82AC"/>
        <rect x="15" y="22" width="34" height="8" rx="3" fill="#F45187"/>
        <rect x="29" y="22" width="6" height="28" fill="#FFF"/>
        <path d="M25 18c-3-4-8-2-7 2s8 3 11 3c-3 0-8-1-7-3 1-4 6-2 7 2" fill="#F45187"/>
        <path d="M39 18c3-4 8-2 7 2s-8 3-11 3c3 0 8-1 7-3-1-4-6-2-7 2" fill="#F45187"/>
    </svg>',
    
    'movies' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
        <circle cx="32" cy="32" r="30" fill="#FFE0D2"/>
        <rect x="16" y="20" width="32" height="26" rx="4" fill="#392D35"/>
        <rect x="18" y="22" width="28" height="6" fill="#F45187"/>
        <polygon points="28,32 38,37 28,42" fill="#FFF"/>
        <circle cx="21" cy="25" r="1.5" fill="#FFF"/>
        <circle cx="27" cy="25" r="1.5" fill="#FFF"/>
        <circle cx="33" cy="25" r="1.5" fill="#FFF"/>
        <circle cx="39" cy="25" r="1.5" fill="#FFF"/>
        <circle cx="45" cy="25" r="1.5" fill="#FFF"/>
    </svg>',
    
    'music' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
        <circle cx="32" cy="32" r="30" fill="#E9DFFF"/>
        <circle cx="24" cy="42" r="6" fill="#F45187"/>
        <circle cx="42" cy="36" r="6" fill="#F45187"/>
        <path d="M28 42V20l18-6v22" stroke="#F45187" stroke-width="4" stroke-linecap="round" fill="none"/>
        <path d="M28 26l18-6" stroke="#FF82AC" stroke-width="4"/>
        <circle cx="22" cy="40" r="2" fill="#FFF"/>
        <circle cx="40" cy="34" r="2" fill="#FFF"/>
    </svg>',
    
    'sleep' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
        <circle cx="32" cy="32" r="30" fill="#E9DFFF"/>
        <path d="M22 24c8 0 16 6 16 16 0 3-1 6-2 8 8-2 14-9 14-18 0-11-9-20-20-20-4 0-8 1-11 3 2 7 7 11 13 11z" fill="#F45187"/>
        <text x="36" y="22" font-family="sans-serif" font-weight="bold" font-size="12" fill="#FF82AC">Z</text>
        <text x="44" y="16" font-family="sans-serif" font-weight="bold" font-size="9" fill="#FF82AC">z</text>
    </svg>',
    
    'shopping' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
        <circle cx="32" cy="32" r="30" fill="#FFE0D2"/>
        <path d="M20 26h24l-3 20H23L20 26z" fill="#FF82AC"/>
        <path d="M26 26V20c0-3.3 2.7-6 6-6s6 2.7 6 6v6" stroke="#F45187" stroke-width="3.5" fill="none" stroke-linecap="round"/>
        <circle cx="32" cy="35" r="4" fill="#FFF"/>
    </svg>',
    
    'gaming' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
        <circle cx="32" cy="32" r="30" fill="#D9F5E5"/>
        <rect x="14" y="24" width="36" height="22" rx="10" fill="#392D35"/>
        <path d="M22 30v10M17 35h10" stroke="#FFF" stroke-width="2.5" stroke-linecap="round"/>
        <circle cx="41" cy="32" r="2.5" fill="#FF82AC"/>
        <circle cx="46" cy="37" r="2.5" fill="#F45187"/>
    </svg>',
    
    'flowers' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
        <circle cx="32" cy="32" r="30" fill="#FFE0D2"/>
        <circle cx="32" cy="22" r="7" fill="#FF82AC"/>
        <circle cx="40" cy="28" r="7" fill="#FF82AC"/>
        <circle cx="37" cy="38" r="7" fill="#FF82AC"/>
        <circle cx="27" cy="38" r="7" fill="#FF82AC"/>
        <circle cx="24" cy="28" r="7" fill="#FF82AC"/>
        <circle cx="32" cy="30" r="5" fill="#FFE082"/>
        <path d="M32 40v14" stroke="#7CB342" stroke-width="3" stroke-linecap="round"/>
        <path d="M32 46c4-4 10-2 10 2s-6 2-10-2z" fill="#7CB342"/>
    </svg>',
    
    'dates' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
        <circle cx="32" cy="32" r="30" fill="#FFF0F5"/>
        <path d="M32 48s-14-9-14-18c0-5 4-9 9-9 3 0 5 1.5 5 3 0-1.5 2-3 5-3 5 0 9 4 9 9 0 9-14 18-14 18z" fill="#F45187"/>
        <circle cx="26" cy="26" r="2" fill="#FFF"/>
    </svg>'
];

foreach ($stickers as $name => $svg) {
    file_put_contents($stickersDir . '/' . $name . '.svg', trim($svg));
}
echo "Created all 10 stickers!\n";

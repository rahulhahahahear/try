<?php
/**
 * Test of Bubu 💗 - Expired Quiz Cleanup Script
 * Can be run via CLI or protected HTTP cron endpoint with secret token.
 * 
 * CLI Usage:
 *   php scripts/cleanup-expired.php
 * 
 * HTTP Cron Usage:
 *   GET /scripts/cleanup-expired.php?key=YOUR_CRON_SECRET_KEY
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/db.php';

$isCli = (php_sapi_name() === 'cli');

if (!$isCli) {
    header('Content-Type: application/json; charset=utf-8');
    $providedKey = $_GET['key'] ?? '';
    if (!hash_equals(CRON_SECRET_KEY, $providedKey)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Forbidden: Invalid cron secret key.']);
        exit;
    }
}

try {
    $db = getDb();
    
    // Retention period: Delete quizzes expired for more than 24 hours
    // First, find option images belonging to quizzes to be deleted so we can remove uploaded files
    $stmtFindFiles = $db->prepare("
        SELECT o.option_image_path 
        FROM options o
        JOIN questions q ON q.id = o.question_id
        JOIN quizzes z ON z.id = q.quiz_id
        WHERE z.expires_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)
          AND o.option_image_path IS NOT NULL
    ");
    $stmtFindFiles->execute();
    $files = $stmtFindFiles->fetchAll(PDO::FETCH_COLUMN);

    $deletedFilesCount = 0;
    foreach ($files as $relPath) {
        $fullPath = dirname(__DIR__) . '/' . $relPath;
        if (file_exists($fullPath) && is_file($fullPath)) {
            @unlink($fullPath);
            $deletedFilesCount++;
        }
    }

    // Delete expired quizzes (Cascading constraints delete questions, options, attempts, attempt_answers)
    $stmtDelete = $db->prepare("
        DELETE FROM quizzes 
        WHERE expires_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)
    ");
    $stmtDelete->execute();
    $deletedQuizzesCount = $stmtDelete->rowCount();

    $output = [
        'success'         => true,
        'purged_quizzes'  => $deletedQuizzesCount,
        'purged_files'    => $deletedFilesCount,
        'timestamp'       => date('Y-m-d H:i:s')
    ];

    if ($isCli) {
        echo "=== Bubu Maintenance Cleanup ===\n";
        echo "Timestamp: " . $output['timestamp'] . "\n";
        echo "Purged Quizzes: " . $output['purged_quizzes'] . "\n";
        echo "Purged Upload Files: " . $output['purged_files'] . "\n";
        echo "Cleanup complete!\n";
    } else {
        echo json_encode($output);
    }
} catch (Exception $e) {
    error_log("Cleanup error: " . $e->getMessage());
    if ($isCli) {
        echo "Cleanup failed: " . $e->getMessage() . "\n";
        exit(1);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Cleanup execution failed.']);
    }
}

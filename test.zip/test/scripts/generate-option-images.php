<?php
/**
 * Generate cute SVG images for each of the 8 options across all 10 questions
 */
$optionsDir = __DIR__ . '/../assets/images/options';
if (!is_dir($optionsDir)) {
    mkdir($optionsDir, 0755, true);
}

function makeSvgIcon(string $emoji, string $bg1, string $bg2): string {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 72 72" width="72" height="72">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="' . $bg1 . '" />
      <stop offset="100%" stop-color="' . $bg2 . '" />
    </linearGradient>
  </defs>
  <rect width="72" height="72" rx="20" fill="url(#grad)" />
  <circle cx="36" cy="36" r="26" fill="#ffffff" opacity="0.6" />
  <text x="36" y="47" font-size="34" text-anchor="middle" font-family="Apple Color Emoji, Segoe UI Emoji, Noto Color Emoji, sans-serif">' . $emoji . '</text>
</svg>';
}

$optionIcons = [
    // Q1: Food
    'q1_opt1' => ['🍕', '#FFE8EE', '#FFD2DF'],
    'q1_opt2' => ['🥟', '#FFF0E5', '#FFE0CC'],
    'q1_opt3' => ['🍛', '#FFF8E1', '#FFECB3'],
    'q1_opt4' => ['🍔', '#FFEBE5', '#FFCCBC'],
    'q1_opt5' => ['🍝', '#FFF3E0', '#FFE0B2'],
    'q1_opt6' => ['🍜', '#E8F5E9', '#C8E6C9'],
    'q1_opt7' => ['🍦', '#F3E5F5', '#E1BEE7'],
    'q1_opt8' => ['🍫', '#EFEBE9', '#D7CCC8'],

    // Q2: Apps
    'q2_opt1' => ['📸', '#FCE4EC', '#F8BBD0'],
    'q2_opt2' => ['💬', '#E8F5E9', '#C8E6C9'],
    'q2_opt3' => ['▶️', '#FFEBEE', '#FFCDD2'],
    'q2_opt4' => ['🎵', '#EDE7F6', '#D1C4E9'],
    'q2_opt5' => ['📌', '#FFEBEE', '#FFCDD2'],
    'q2_opt6' => ['🎧', '#E8F8F5', '#A3E4D7'],
    'q2_opt7' => ['🍿', '#FFF9C4', '#FFF59D'],
    'q2_opt8' => ['👻', '#FFFDE7', '#FFF9C4'],

    // Q3: Colors
    'q3_opt1' => ['🌸', '#FCE4EC', '#F8BBD0'],
    'q3_opt2' => ['🌊', '#E1F5FE', '#B3E5FC'],
    'q3_opt3' => ['💜', '#EDE7F6', '#D1C4E9'],
    'q3_opt4' => ['🖤', '#ECEFF1', '#CFD8DC'],
    'q3_opt5' => ['🍃', '#E8F5E9', '#C8E6C9'],
    'q3_opt6' => ['🌻', '#FFFDE7', '#FFF59D'],
    'q3_opt7' => ['🍑', '#FBE9E7', '#FFCCBC'],
    'q3_opt8' => ['🤍', '#FAFAFA', '#EEEEEE'],

    // Q4: Dates
    'q4_opt1' => ['☕', '#EFEBE9', '#D7CCC8'],
    'q4_opt2' => ['🚗', '#E0F2F1', '#B2DFDB'],
    'q4_opt3' => ['🛋️', '#F3E5F5', '#E1BEE7'],
    'q4_opt4' => ['🌅', '#FFF3E0', '#FFE0B2'],
    'q4_opt5' => ['🕯️', '#FCE4EC', '#F8BBD0'],
    'q4_opt6' => ['🎡', '#E1F5FE', '#B3E5FC'],
    'q4_opt7' => ['⛺', '#E8F5E9', '#C8E6C9'],
    'q4_opt8' => ['🕹️', '#EDE7F6', '#D1C4E9'],

    // Q5: Angry/Moody
    'q5_opt1' => ['🍔', '#FFEBE5', '#FFCCBC'],
    'q5_opt2' => ['📵', '#FFEBEE', '#FFCDD2'],
    'q5_opt3' => ['😴', '#E8EAF6', '#C5CAE9'],
    'q5_opt4' => ['🗓️', '#FFF3E0', '#FFE0B2'],
    'q5_opt5' => ['🙅', '#FCE4EC', '#F8BBD0'],
    'q5_opt6' => ['🥵', '#FFF8E1', '#FFECB3'],
    'q5_opt7' => ['📶', '#ECEFF1', '#CFD8DC'],
    'q5_opt8' => ['🍟', '#FFF9C4', '#FFF59D'],

    // Q6: Happy
    'q6_opt1' => ['🧋', '#FFF3E0', '#FFE0B2'],
    'q6_opt2' => ['🫂', '#FCE4EC', '#F8BBD0'],
    'q6_opt3' => ['💐', '#E8F5E9', '#C8E6C9'],
    'q6_opt4' => ['🛌', '#EDE7F6', '#D1C4E9'],
    'q6_opt5' => ['🥰', '#FCE4EC', '#FFCDD2'],
    'q6_opt6' => ['🛍️', '#FFF0F5', '#FFE4E1'],
    'q6_opt7' => ['🎶', '#E1F5FE', '#B3E5FC'],
    'q6_opt8' => ['💌', '#FCE4EC', '#F8BBD0'],

    // Q7: Vacation
    'q7_opt1' => ['🏝️', '#E0F7FA', '#B2EBF2'],
    'q7_opt2' => ['🗼', '#FFEBEE', '#FFCDD2'],
    'q7_opt3' => ['🥐', '#FFF3E0', '#FFE0B2'],
    'q7_opt4' => ['🏔️', '#E1F5FE', '#B3E5FC'],
    'q7_opt5' => ['🏰', '#EDE7F6', '#D1C4E9'],
    'q7_opt6' => ['🥥', '#E8F5E9', '#C8E6C9'],
    'q7_opt7' => ['🏙️', '#ECEFF1', '#CFD8DC'],
    'q7_opt8' => ['🚐', '#FFF8E1', '#FFECB3'],

    // Q8: Comfort Food
    'q8_opt1' => ['🍜', '#FFEBEE', '#FFCDD2'],
    'q8_opt2' => ['🍕', '#FFE8EE', '#FFD2DF'],
    'q8_opt3' => ['🍨', '#F3E5F5', '#E1BEE7'],
    'q8_opt4' => ['🥔', '#FFF9C4', '#FFF59D'],
    'q8_opt5' => ['🍩', '#FCE4EC', '#F8BBD0'],
    'q8_opt6' => ['🍗', '#FFEBE5', '#FFCCBC'],
    'q8_opt7' => ['🥞', '#FFF3E0', '#FFE0B2'],
    'q8_opt8' => ['🍪', '#EFEBE9', '#D7CCC8'],

    // Q9: Spend Time
    'q9_opt1' => ['🗣️', '#FCE4EC', '#F8BBD0'],
    'q9_opt2' => ['🛋️', '#EDE7F6', '#D1C4E9'],
    'q9_opt3' => ['🌮', '#FFF3E0', '#FFE0B2'],
    'q9_opt4' => ['🤭', '#FCE4EC', '#FFCDD2'],
    'q9_opt5' => ['🚗', '#E0F2F1', '#B2DFDB'],
    'q9_opt6' => ['🎬', '#E8EAF6', '#C5CAE9'],
    'q9_opt7' => ['📸', '#FFF8E1', '#FFECB3'],
    'q9_opt8' => ['🎮', '#EDE7F6', '#D1C4E9'],

    // Q10: Gift
    'q10_opt1' => ['🧸', '#FCE4EC', '#F8BBD0'],
    'q10_opt2' => ['💌', '#FFF0F5', '#FFE4E1'],
    'q10_opt3' => ['💍', '#E1F5FE', '#B3E5FC'],
    'q10_opt4' => ['🌸', '#FCE4EC', '#F8BBD0'],
    'q10_opt5' => ['🍽️', '#FFF3E0', '#FFE0B2'],
    'q10_opt6' => ['🧥', '#ECEFF1', '#CFD8DC'],
    'q10_opt7' => ['🎟️', '#EDE7F6', '#D1C4E9'],
    'q10_opt8' => ['📖', '#EFEBE9', '#D7CCC8']
];

foreach ($optionIcons as $filename => [$emoji, $bg1, $bg2]) {
    $svg = makeSvgIcon($emoji, $bg1, $bg2);
    file_put_contents($optionsDir . '/' . $filename . '.svg', trim($svg));
}

echo "Successfully generated all " . count($optionIcons) . " cute option images in assets/images/options/!\n";

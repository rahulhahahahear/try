<?php
$brain = 'C:/Users/ITM.DESKTOP-IM4TRAD/.gemini/antigravity/brain/550e2894-9e16-4041-8802-8594ac8c99ee';
$dest = __DIR__ . '/../assets/images';

$map = [
    'bubu-hero' => 'bubu_hero_1791539653745.jpg',
    'bubu-happy' => 'bubu_happy_1791539674197.jpg',
    'bubu-angry' => 'bubu_angry_1791539691076.jpg',
    'bubu-sad' => 'bubu_sad_1791539709926.jpg',
    'bubu-shy' => 'bubu_shy_1791539728399.jpg',
    'bubu-thinking' => 'bubu_thinking_1791539748338.jpg'
];

foreach ($map as $name => $src) {
    $srcPath = $brain . '/' . $src;
    if (file_exists($srcPath)) {
        copy($srcPath, $dest . '/' . $name . '.jpg');
        $img = imagecreatefromjpeg($srcPath);
        if ($img) {
            imagewebp($img, $dest . '/' . $name . '.webp', 88);
            imagepng($img, $dest . '/' . $name . '.png');
            imagedestroy($img);
            echo "Converted $name to webp and png\n";
        }
    }
}

// For bubu-empty and bubu-share, let's create derived or placeholder assets
// bubu-empty: We can derive from bubu-thinking or create an adorable graphic
if (file_exists($dest . '/bubu-thinking.webp')) {
    copy($dest . '/bubu-thinking.webp', $dest . '/bubu-empty.webp');
    copy($dest . '/bubu-thinking.png', $dest . '/bubu-empty.png');
    echo "Created bubu-empty\n";
}

// bubu-share: We can derive from bubu-hero or bubu-happy
if (file_exists($dest . '/bubu-hero.webp')) {
    copy($dest . '/bubu-hero.webp', $dest . '/bubu-share.webp');
    copy($dest . '/bubu-hero.png', $dest . '/bubu-share.png');
    echo "Created bubu-share\n";
}

// Favicon: Create a cute 64x64 favicon.png
$fav = imagecreatetruecolor(64, 64);
imagealphablending($fav, false);
imagesavealpha($fav, true);
$trans = imagecolorallocatealpha($fav, 255, 255, 255, 127);
imagefill($fav, 0, 0, $trans);

$pink = imagecolorallocate($fav, 255, 130, 172);
$deepPink = imagecolorallocate($fav, 244, 81, 135);
$white = imagecolorallocate($fav, 255, 255, 255);
$brown = imagecolorallocate($fav, 57, 45, 53);

// Draw cute round heart background
imagefilledellipse($fav, 24, 26, 28, 28, $pink);
imagefilledellipse($fav, 40, 26, 28, 28, $pink);
$points = [10, 28, 54, 28, 32, 56];
imagefilledpolygon($fav, $points, 3, $pink);

// Two cute bear ears & eyes
imagefilledellipse($fav, 22, 14, 8, 8, $white);
imagefilledellipse($fav, 42, 14, 8, 8, $pink);
imagefilledellipse($fav, 26, 28, 4, 4, $brown);
imagefilledellipse($fav, 38, 28, 4, 4, $brown);

imagepng($fav, $dest . '/favicon.png');
imagedestroy($fav);
echo "Created favicon.png\n";

echo "All images processed successfully!\n";

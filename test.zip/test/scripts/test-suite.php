<?php
/**
 * Test of Bubu 💗 - Comprehensive Automated Test Suite
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/security.php';

echo "========================================================\n";
echo "🧪 Running Test of Bubu Automated Test Suite\n";
echo "========================================================\n\n";

$testsPassed = 0;
$testsFailed = 0;

function assertTest(string $description, bool $condition): void {
    global $testsPassed, $testsFailed;
    if ($condition) {
        echo "✅ PASS: $description\n";
        $testsPassed++;
    } else {
        echo "❌ FAIL: $description\n";
        $testsFailed++;
    }
}

// 1. Prepare sample 10-question payload
$sampleQuestions = [];
for ($i = 1; $i <= 10; $i++) {
    $sampleQuestions[] = [
        'text' => "Question {$i}: What is my favourite thing #{$i}?",
        'options' => [
            ['text' => "Option A for Q{$i}", 'emoji' => '🍕', 'is_correct' => true],
            ['text' => "Option B for Q{$i}", 'emoji' => '🍦', 'is_correct' => false],
            ['text' => "Option C for Q{$i}", 'emoji' => '🍜', 'is_correct' => false],
            ['text' => "Option D for Q{$i}", 'emoji' => '🍰', 'is_correct' => false]
        ]
    ];
}

$createPayload = [
    'creator_nickname' => 'SweetBubu',
    'relationship_type' => 'partner',
    'quiz_title' => 'How well do you know SweetBubu?',
    'expiration_hours' => 3,
    'questions' => $sampleQuestions
];

// Test 1: Quiz Creation
$createResult = createQuiz($createPayload);
assertTest("Quiz creation succeeded", $createResult['success'] === true);
assertTest("Public code generated (length >= 8)", !empty($createResult['public_code']) && strlen($createResult['public_code']) >= 8);
assertTest("Creator token generated", !empty($createResult['creator_token']));

$publicCode = $createResult['public_code'];
$creatorToken = $createResult['creator_token'];

// Test 2: Database Persistence
$db = getDb();
$stmtQz = $db->prepare("SELECT * FROM quizzes WHERE public_code = :code");
$stmtQz->execute(['code' => $publicCode]);
$dbQuiz = $stmtQz->fetch();
assertTest("Quiz persisted in MySQL", $dbQuiz !== false && $dbQuiz['creator_nickname'] === 'SweetBubu');

$stmtCntQ = $db->prepare("SELECT COUNT(*) FROM questions WHERE quiz_id = :id");
$stmtCntQ->execute(['id' => $dbQuiz['id']]);
$qCount = (int)$stmtCntQ->fetchColumn();
assertTest("Exactly 10 questions saved", $qCount === 10);

$stmtCntOpt = $db->prepare("SELECT COUNT(*) FROM options o JOIN questions q ON q.id = o.question_id WHERE q.quiz_id = :id");
$stmtCntOpt->execute(['id' => $dbQuiz['id']]);
$optCount = (int)$stmtCntOpt->fetchColumn();
assertTest("Exactly 40 options saved (4 per question)", $optCount === 40);

// Test 3: Security - Participant View MUST NOT leak 'is_correct'
$participantQuiz = findQuizWithQuestions($publicCode, false);
$leakedCorrect = false;
foreach ($participantQuiz['questions'] as $q) {
    foreach ($q['options'] as $opt) {
        if (isset($opt['is_correct'])) {
            $leakedCorrect = true;
            break 2;
        }
    }
}
assertTest("Security: Participant questions DO NOT expose 'is_correct'", !$leakedCorrect);

// Fetch full questions with correct answers for testing submissions
$fullQuiz = findQuizWithQuestions($publicCode, true);
$correctOptionMap = [];
$wrongOptionMap = [];
foreach ($fullQuiz['questions'] as $q) {
    foreach ($q['options'] as $opt) {
        if (!empty($opt['is_correct'])) {
            $correctOptionMap[$q['id']] = $opt['id'];
        } else {
            $wrongOptionMap[$q['id']][] = $opt['id'];
        }
    }
}

// Test 4: Submit 10/10 Score (Soulmate Band)
$answers10 = [];
foreach ($correctOptionMap as $qId => $optId) {
    $answers10[$qId] = $optId;
}
$token10 = 'att_token_10_' . bin2hex(random_bytes(6));
$res10 = submitQuizAttempt($publicCode, 'SoulmatePartner', $answers10, $token10);
assertTest("Submission 10/10 succeeds", $res10['success'] === true);
assertTest("Score is 10/10", $res10['score'] === 10 && $res10['percentage'] === 100);
assertTest("Reaction band is 'soulmate' with bubu-happy", $res10['reaction']['band'] === 'soulmate' && $res10['reaction']['character'] === 'bubu-happy');

// Test 5: Submit 8/10 Score (Pretty Good Band)
$answers8 = $answers10;
$qIds = array_keys($answers8);
// Make 2 wrong
$answers8[$qIds[0]] = $wrongOptionMap[$qIds[0]][0];
$answers8[$qIds[1]] = $wrongOptionMap[$qIds[1]][0];
$token8 = 'att_token_8_' . bin2hex(random_bytes(6));
$res8 = submitQuizAttempt($publicCode, 'PrettyGoodBubu', $answers8, $token8);
assertTest("Score is 8/10", $res8['score'] === 8 && $res8['percentage'] === 80);
assertTest("Reaction band is 'pretty_good' with bubu-shy", $res8['reaction']['band'] === 'pretty_good' && $res8['reaction']['character'] === 'bubu-shy');

// Test 6: Submit 5/10 Score (Needs Time Band)
$answers5 = $answers10;
for ($k = 0; $k < 5; $k++) {
    $answers5[$qIds[$k]] = $wrongOptionMap[$qIds[$k]][0];
}
$token5 = 'att_token_5_' . bin2hex(random_bytes(6));
$res5 = submitQuizAttempt($publicCode, 'SnackBubu', $answers5, $token5);
assertTest("Score is 5/10", $res5['score'] === 5 && $res5['percentage'] === 50);
assertTest("Reaction band is 'needs_time' with bubu-thinking", $res5['reaction']['band'] === 'needs_time' && $res5['reaction']['character'] === 'bubu-thinking');

// Test 7: Submit 2/10 Score (Funny Angry Band)
$answers2 = $answers10;
for ($k = 0; $k < 8; $k++) {
    $answers2[$qIds[$k]] = $wrongOptionMap[$qIds[$k]][0];
}
$token2 = 'att_token_2_' . bin2hex(random_bytes(6));
$res2 = submitQuizAttempt($publicCode, 'ForgetfulBubu', $answers2, $token2);
assertTest("Score is 2/10", $res2['score'] === 2 && $res2['percentage'] === 20);
assertTest("Reaction band is 'funny_angry' with bubu-angry", $res2['reaction']['band'] === 'funny_angry' && $res2['reaction']['character'] === 'bubu-angry');

// Test 8: Idempotency (Submitting same attempt token returns same result without extra DB row)
$countBefore = (int)$db->query("SELECT COUNT(*) FROM attempts WHERE quiz_id = {$dbQuiz['id']}")->fetchColumn();
$resIdempotent = submitQuizAttempt($publicCode, 'SoulmatePartner', $answers10, $token10);
$countAfter = (int)$db->query("SELECT COUNT(*) FROM attempts WHERE quiz_id = {$dbQuiz['id']}")->fetchColumn();
assertTest("Idempotent submission returns cached result", !empty($resIdempotent['idempotent']));
assertTest("Idempotent submission does not create duplicate row", $countBefore === $countAfter);

// Test 9: Incomplete submission rejected
$incompleteAnswers = $answers10;
unset($incompleteAnswers[$qIds[0]]); // only 9 answers
$resIncomplete = submitQuizAttempt($publicCode, 'IncompleteBubu', $incompleteAnswers, 'token_inc');
assertTest("Incomplete submission (9 of 10) rejected", $resIncomplete['success'] === false);

// Test 10: Creator Auth & Dashboard
$creatorQuiz = findQuizForCreator($publicCode, $creatorToken);
assertTest("Creator can authenticate with valid token", $creatorQuiz !== null);
$invalidCreatorQuiz = findQuizForCreator($publicCode, 'WRONG_TOKEN_XYZ');
assertTest("Creator authentication rejects wrong token", $invalidCreatorQuiz === null);

$creatorAttempts = getQuizAttempts((int)$dbQuiz['id']);
assertTest("Creator dashboard lists submitted attempts (found " . count($creatorAttempts) . ")", count($creatorAttempts) >= 4);

// Test 11: Expiration Handling
$db->exec("UPDATE quizzes SET expires_at = DATE_SUB(NOW(), INTERVAL 10 SECOND) WHERE id = {$dbQuiz['id']}");
$expiredAttempt = submitQuizAttempt($publicCode, 'LateBubu', $answers10, 'token_late');
assertTest("Submissions rejected on expired quiz", $expiredAttempt['success'] === false && !empty($expiredAttempt['is_expired']));

$expiredQuizCheck = findQuizByCode($publicCode);
assertTest("Quiz status automatically transitions to 'expired'", $expiredQuizCheck['status'] === 'expired');

// Test 12: Automatic 8-Option Pool Selection Flow (1 right + 3 random from 7)
$pool = getMasterQuestionPool();
assertTest("Question pool has exactly 10 questions", count($pool) === 10);
assertTest("Question 1 has exactly 8 preset options", count($pool[0]['options']) === 8);

$autoSelections = [];
for ($m = 1; $m <= 10; $m++) {
    // Select option 3 for each question as the right answer
    $autoSelections[] = [
        'question_id' => $m,
        'selected_option_id' => 3
    ];
}

$autoQuizResult = createQuiz([
    'creator_nickname' => 'AutoPoolBubu',
    'relationship_type' => 'partner',
    'quiz_title' => 'Auto Pool Test Quiz',
    'expiration_hours' => 3,
    'selections' => $autoSelections
]);

assertTest("Auto-pool quiz creation succeeded", $autoQuizResult['success'] === true);
$autoQuiz = findQuizWithQuestions($autoQuizResult['public_code'], true);
assertTest("Auto-pool quiz has 10 questions", count($autoQuiz['questions']) === 10);

$allQuestionsHaveFourOptions = true;
$allQuestionsHaveOneCorrect = true;
$correctAnswerMatchesSelection = true;

foreach ($autoQuiz['questions'] as $idx => $aq) {
    if (count($aq['options']) !== 4) {
        $allQuestionsHaveFourOptions = false;
    }
    $correctCount = 0;
    $foundRightText = '';
    foreach ($aq['options'] as $aOpt) {
        if (!empty($aOpt['is_correct'])) {
            $correctCount++;
            $foundRightText = $aOpt['option_text'];
        }
    }
    if ($correctCount !== 1) {
        $allQuestionsHaveOneCorrect = false;
    }
    // Verify chosen option was option 3 ("Biryani" for Q1)
    $expectedOptText = $pool[$idx]['options'][2]['text']; // index 2 = id 3
    if ($foundRightText !== $expectedOptText) {
        $correctAnswerMatchesSelection = false;
    }
}

assertTest("Every question in auto-pool quiz has exactly 4 options (1 right + 3 random from 9)", $allQuestionsHaveFourOptions);
assertTest("Every question has exactly 1 correct answer", $allQuestionsHaveOneCorrect);
assertTest("Correct answer accurately matches creator selection from 10 options", $correctAnswerMatchesSelection);


// Summary
echo "\n========================================================\n";
echo "📊 Results: {$testsPassed} Passed, {$testsFailed} Failed\n";
echo "========================================================\n";

if ($testsFailed > 0) {
    exit(1);
}

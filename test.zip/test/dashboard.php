<?php
/**
 * Test of Bubu 💗 - Protected Creator Results Dashboard
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

$code  = trim($_GET['code'] ?? '');
$token = trim($_GET['token'] ?? '');

if ($code === '' || $token === '') {
    $pageTitle = 'Creator Access Required | ' . APP_NAME;
    require_once __DIR__ . '/includes/header.php';
    ?>
    <div class="container" style="max-width: 520px; padding-top: 3.5rem; text-align: center;">
        <div class="card">
            <div style="font-size: 3rem; margin-bottom: 0.5rem;" aria-hidden="true">🔒</div>
            <h2 style="font-family: var(--font-heading); color: var(--text-dark); margin-bottom: 0.5rem;">
                Creator Access Key Required
            </h2>
            <p style="color: var(--text-muted); margin-bottom: 1.5rem;">
                This dashboard requires the secret creator token link generated when your quiz was published.
            </p>
            <a href="<?= BASE_URL ?>/" class="btn btn-primary">
                <span>🏠</span> Return Home
            </a>
        </div>
    </div>
    <?php
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

$quiz = findQuizForCreator($code, $token);

if (!$quiz) {
    $pageTitle = 'Invalid Creator Key | ' . APP_NAME;
    require_once __DIR__ . '/includes/header.php';
    ?>
    <div class="container" style="max-width: 520px; padding-top: 3.5rem; text-align: center;">
        <div class="card">
            <div style="font-size: 3rem; margin-bottom: 0.5rem;" aria-hidden="true">🚫</div>
            <h2 style="font-family: var(--font-heading); color: var(--text-dark); margin-bottom: 0.5rem;">
                Unauthorized Access
            </h2>
            <p style="color: var(--text-muted); margin-bottom: 1.5rem;">
                The creator token provided does not match this quiz.
            </p>
            <a href="<?= BASE_URL ?>/" class="btn btn-primary">
                <span>🏠</span> Return Home
            </a>
        </div>
    </div>
    <?php
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

$attempts = getQuizAttempts((int)$quiz['id']);
$totalAttempts = count($attempts);
$avgScore = 0;
$highestScore = 0;

if ($totalAttempts > 0) {
    $sum = array_sum(array_column($attempts, 'score'));
    $avgScore = round($sum / $totalAttempts, 1);
    $highestScore = max(array_column($attempts, 'score'));
}

$playUrl = BASE_URL . '/play.php?code=' . e($quiz['public_code']);
$pageTitle = 'Creator Dashboard: ' . e($quiz['creator_nickname']) . ' 📊 | ' . APP_NAME;
require_once __DIR__ . '/includes/header.php';
?>

<div class="container" style="max-width: 780px; padding-top: 2rem;">
    <!-- Dashboard Header Card -->
    <div class="card" style="margin-bottom: 1.5rem;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 1rem;">
            <div>
                <span class="badge <?= $quiz['status'] === 'active' ? 'badge-mint' : 'badge-pink' ?>">
                    Status: <?= strtoupper(e($quiz['status'])) ?>
                </span>
                <h1 style="font-family: var(--font-heading); font-size: 1.85rem; color: var(--text-dark); margin-top: 0.35rem;">
                    <?= e($quiz['quiz_title']) ?>
                </h1>
                <p style="color: var(--text-muted); font-size: 0.95rem;">
                    Created by <strong><?= e($quiz['creator_nickname']) ?></strong> &bull; Expires: <?= date('M d, Y h:i A', strtotime($quiz['expires_at'])) ?>
                </p>
            </div>
            <div>
                <a href="<?= $playUrl ?>" target="_blank" class="btn btn-outline btn-sm">
                    <span>👁️</span> View Quiz
                </a>
            </div>
        </div>

        <!-- Shareable Link Banner -->
        <div style="background: #FFF5F8; border: 1.5px solid var(--border-soft); border-radius: var(--radius-md); padding: 0.85rem 1rem; margin-top: 1.25rem; display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; flex-wrap: wrap;">
            <div style="font-size: 0.9rem; font-weight: 600; color: var(--text-dark); overflow: hidden; text-overflow: ellipsis;">
                🔗 Public Quiz Link: <span style="color: var(--deep-pink);"><?= $playUrl ?></span>
            </div>
            <button type="button" class="btn btn-primary btn-sm" onclick="window.copyToClipboard('<?= $playUrl ?>')">
                📋 Copy Link
            </button>
        </div>
    </div>

    <!-- Stats Grid -->
    <div class="stats-grid">
        <div class="stat-box">
            <div class="stat-num"><?= $totalAttempts ?></div>
            <div class="stat-label">Total Attempts</div>
        </div>
        <div class="stat-box">
            <div class="stat-num"><?= $avgScore ?>/10</div>
            <div class="stat-label">Average Score</div>
        </div>
        <div class="stat-box">
            <div class="stat-num"><?= $highestScore ?>/10</div>
            <div class="stat-label">Best Score</div>
        </div>
    </div>

    <!-- Attempts History Table -->
    <div class="card" style="margin-bottom: 1.5rem;">
        <h3 style="font-family: var(--font-heading); font-size: 1.35rem; color: var(--text-dark); margin-bottom: 0.5rem;">
            Quiz Responses & Scores 🐻💗
        </h3>
        <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
            Here are the people who have completed your quiz:
        </p>

        <?php if ($totalAttempts === 0): ?>
            <div style="text-align: center; padding: 2.5rem 1rem;">
                <div style="width: 140px; height: 140px; margin: 0 auto 1rem;">
                    <picture>
                        <source srcset="<?= BASE_URL ?>/assets/images/bubu-empty.webp" type="image/webp">
                        <img src="<?= BASE_URL ?>/assets/images/bubu-empty.png" alt="Empty box with bear" style="width: 100%; height: 100%; object-fit: contain;">
                    </picture>
                </div>
                <h4 style="font-family: var(--font-heading); color: var(--text-dark); margin-bottom: 0.35rem;">No responses yet!</h4>
                <p style="color: var(--text-muted); font-size: 0.95rem; margin-bottom: 1.25rem;">Send your quiz link to your Bubu so they can play!</p>
                <button type="button" class="btn btn-primary btn-sm" onclick="window.copyToClipboard('<?= $playUrl ?>')">
                    📋 Copy & Send Link
                </button>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="bubu-table">
                    <thead>
                        <tr>
                            <th>Participant</th>
                            <th>Score</th>
                            <th>Date & Time</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($attempts as $att): ?>
                            <tr>
                                <td>
                                    <strong><?= e($att['participant_nickname']) ?></strong>
                                </td>
                                <td>
                                    <span class="badge <?= $att['score'] >= 7 ? 'badge-mint' : ($att['score'] >= 4 ? 'badge-lavender' : 'badge-pink') ?>">
                                        <?= $att['score'] ?> / <?= $att['total_questions'] ?>
                                    </span>
                                </td>
                                <td style="font-size: 0.85rem; color: var(--text-muted);">
                                    <?= date('M d, g:i A', strtotime($att['submitted_at'])) ?>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-outline btn-sm view-details-btn" data-attempt-id="<?= $att['id'] ?>">
                                        🔍 View Answers
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <!-- Quiz Settings Card -->
    <div class="card" style="margin-bottom: 2rem;">
        <h3 style="font-family: var(--font-heading); font-size: 1.35rem; color: var(--text-dark); margin-bottom: 0.75rem;">
            Quiz Settings ⚙️
        </h3>

        <form id="settings-form" onsubmit="return false;">
            <div style="display: flex; flex-direction: column; gap: 0.85rem;">
                <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer; font-weight: 600;">
                    <input type="checkbox" id="setting-repeat" <?= $quiz['allow_repeat_attempts'] ? 'checked' : '' ?>>
                    <span>Allow repeat attempts by the same person</span>
                </label>

                <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer; font-weight: 600;">
                    <input type="checkbox" id="setting-reveal" <?= $quiz['reveal_detailed_answers'] ? 'checked' : '' ?>>
                    <span>Reveal correct answers to participant after finishing</span>
                </label>

                <div style="display: flex; gap: 1rem; align-items: center; margin-top: 0.5rem;">
                    <span style="font-weight: 600;">Quiz Availability:</span>
                    <select id="setting-status" class="form-control" style="width: auto;">
                        <option value="active" <?= $quiz['status'] === 'active' ? 'selected' : '' ?>>Active (Accepting Submissions)</option>
                        <option value="disabled" <?= $quiz['status'] === 'disabled' ? 'selected' : '' ?>>Paused / Disabled</option>
                        <option value="expired" <?= $quiz['status'] === 'expired' ? 'selected' : '' ?>>Expired</option>
                    </select>
                </div>
            </div>

            <div style="margin-top: 1.25rem;">
                <button type="button" id="save-settings-btn" class="btn btn-primary btn-sm">
                    💾 Save Settings
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Detailed Attempt Breakdown Modal -->
<div id="details-modal" class="modal-backdrop" aria-hidden="true">
    <div class="modal-dialog" style="max-width: 600px;">
        <div class="modal-header">
            <h3>📝 Answer Breakdown</h3>
            <button type="button" class="modal-close-btn" id="close-details-btn">&times;</button>
        </div>
        <div class="modal-body" id="details-modal-content">
            <p>Loading answers...</p>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary btn-sm" id="close-details-footer-btn">Close</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const code = "<?= e($quiz['public_code']) ?>";
    const token = "<?= e($token) ?>";

    // Save Settings
    const saveBtn = document.getElementById('save-settings-btn');
    if (saveBtn) {
        saveBtn.addEventListener('click', async () => {
            saveBtn.disabled = true;
            saveBtn.textContent = 'Saving...';

            const payload = {
                public_code: code,
                creator_token: token,
                allow_repeat_attempts: document.getElementById('setting-repeat').checked,
                reveal_detailed_answers: document.getElementById('setting-reveal').checked,
                status: document.getElementById('setting-status').value
            };

            try {
                const resp = await fetch(window.APP_CONFIG.baseUrl + '/api/update-quiz.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const res = await resp.json();
                if (res.success) {
                    window.showToast('Settings saved successfully! 💗');
                } else {
                    window.showToast(res.error || 'Failed to save settings.');
                }
            } catch (err) {
                window.showToast('Network error saving settings.');
            } finally {
                saveBtn.disabled = false;
                saveBtn.textContent = '💾 Save Settings';
            }
        });
    }

    // Modal Details
    const detailsModal = document.getElementById('details-modal');
    const detailsContent = document.getElementById('details-modal-content');
    const closeBtns = [document.getElementById('close-details-btn'), document.getElementById('close-details-footer-btn')];

    closeBtns.forEach(b => {
        if (b) b.addEventListener('click', () => {
            detailsModal.classList.remove('active');
        });
    });

    document.querySelectorAll('.view-details-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
            const attemptId = btn.getAttribute('data-attempt-id');
            detailsModal.classList.add('active');
            detailsContent.innerHTML = '<p>Loading answers...</p>';

            try {
                const resp = await fetch(`${window.APP_CONFIG.baseUrl}/api/get-results.php?code=${code}&token=${token}&attempt_id=${attemptId}`);
                const data = await resp.json();

                if (!data.success || !data.detailed_answers) {
                    detailsContent.innerHTML = '<p>Unable to load answers.</p>';
                    return;
                }

                let html = '<div style="display: flex; flex-direction: column; gap: 0.75rem;">';
                data.detailed_answers.forEach((ans, idx) => {
                    const isCorrect = ans.is_correct == 1;
                    html += `
                        <div style="border: 1.5px solid ${isCorrect ? '#C8E6C9' : '#FFCDD2'}; background: ${isCorrect ? '#F1F8E9' : '#FFEBEE'}; border-radius: 12px; padding: 0.75rem 1rem;">
                            <div style="font-weight: 700; font-size: 0.95rem; margin-bottom: 0.25rem;">
                                Question ${idx + 1}: ${ans.question_text}
                            </div>
                            <div style="font-size: 0.9rem;">
                                <strong>Selected:</strong> ${ans.selected_emoji ? ans.selected_emoji + ' ' : ''}${ans.selected_text} 
                                ${isCorrect ? '<span style="color: #2E7D32; font-weight: 700;">✓ Correct</span>' : '<span style="color: #C62828; font-weight: 700;">✗ Wrong</span>'}
                            </div>
                            ${!isCorrect ? `
                                <div style="font-size: 0.85rem; color: #555; margin-top: 0.2rem;">
                                    <strong>Real Answer:</strong> ${ans.correct_emoji ? ans.correct_emoji + ' ' : ''}${ans.correct_text}
                                </div>
                            ` : ''}
                        </div>
                    `;
                });
                html += '</div>';
                detailsContent.innerHTML = html;
            } catch (err) {
                detailsContent.innerHTML = '<p>Network error loading details.</p>';
            }
        });
    });
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

<?php
/**
 * Test of Bubu 💗 - Public Scores Leaderboard
 * Shows all attempts/scores for a given quiz (public, no auth needed)
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

$code = trim($_GET['code'] ?? '');
if ($code === '') {
    header("Location: " . BASE_URL . "/");
    exit;
}

$quiz = findQuizByCode($code);

if (!$quiz) {
    $pageTitle = 'Quiz Not Found | ' . APP_NAME;
    require_once __DIR__ . '/includes/header.php';
    ?>
    <div class="container" style="max-width:520px;padding-top:3rem;text-align:center;">
        <div class="card">
            <div style="font-size:3rem;margin-bottom:.5rem;">🔍</div>
            <h2 style="font-family:var(--font-heading);color:var(--text-dark);margin-bottom:.5rem;">Quiz Not Found</h2>
            <p style="color:var(--text-muted);margin-bottom:1.5rem;">This quiz link doesn't exist or has been removed.</p>
            <a href="<?= BASE_URL ?>/" class="btn btn-primary"><span>🏠</span> Return Home</a>
        </div>
    </div>
    <?php
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

// Fetch all attempts
$db    = getDb();
$stmt  = $db->prepare("
    SELECT participant_nickname, score, total_questions, submitted_at
    FROM attempts
    WHERE quiz_id = :qid
    ORDER BY score DESC, submitted_at ASC
");
$stmt->execute(['qid' => $quiz['id']]);
$attempts = $stmt->fetchAll();

$totalAttempts = count($attempts);
$playUrl       = BASE_URL . '/play.php?code=' . e($quiz['public_code']);

$pageTitle = 'Scores: ' . e($quiz['creator_nickname']) . "'s Quiz 📊 | " . APP_NAME;
$pageDesc  = 'See how everyone scored on ' . e($quiz['creator_nickname']) . "'s Test of Bubu quiz!";
require_once __DIR__ . '/includes/header.php';
?>

<div class="container" style="max-width:600px;padding-top:2rem;padding-bottom:3rem;">

    <!-- Header Card -->
    <div class="card" style="text-align:center;margin-bottom:1.5rem;">
        <span class="badge badge-pink" style="margin-bottom:.65rem;">📊 Score Board</span>
        <h1 style="font-family:var(--font-heading);font-size:1.85rem;color:var(--text-dark);margin-bottom:.35rem;">
            <?= e($quiz['quiz_title']) ?>
        </h1>
        <p style="color:var(--text-muted);font-size:.95rem;margin-bottom:1.25rem;">
            Created by <strong><?= e($quiz['creator_nickname']) ?></strong>
            &bull; <?= $totalAttempts ?> attempt<?= $totalAttempts !== 1 ? 's' : '' ?> so far
        </p>
        <a href="<?= $playUrl ?>" class="btn btn-primary btn-sm">
            <span>💗</span> Play Quiz
        </a>
    </div>

    <?php if ($totalAttempts === 0): ?>
    <!-- Empty State -->
    <div class="card" style="text-align:center;padding:3rem 1.5rem;">
        <div style="font-size:4rem;margin-bottom:1rem;line-height:1;">🐻</div>
        <h3 style="font-family:var(--font-heading);color:var(--text-dark);margin-bottom:.4rem;">No Attempts Yet!</h3>
        <p style="color:var(--text-muted);font-size:.97rem;margin-bottom:1.5rem;">
            No one has taken this quiz yet. Be the first to play!
        </p>
        <a href="<?= $playUrl ?>" class="btn btn-primary">
            <span>💕</span> Be First to Play!
        </a>
    </div>

    <?php else: ?>

    <!-- Summary Stats -->
    <div class="stats-grid" style="margin-bottom:1.5rem;">
        <?php
        $scores  = array_column($attempts, 'score');
        $totals  = array_column($attempts, 'total_questions');
        $avg     = round(array_sum($scores) / $totalAttempts, 1);
        $highest = max($scores);
        $lowest  = min($scores);
        ?>
        <div class="stat-box">
            <div class="stat-num"><?= $totalAttempts ?></div>
            <div class="stat-label">Total Players</div>
        </div>
        <div class="stat-box">
            <div class="stat-num"><?= $highest ?>/10</div>
            <div class="stat-label">Best Score 🏆</div>
        </div>
        <div class="stat-box">
            <div class="stat-num"><?= $avg ?>/10</div>
            <div class="stat-label">Avg Score</div>
        </div>
    </div>

    <!-- Scores List -->
    <div class="card" style="padding:0;overflow:hidden;">
        <div style="padding:1.1rem 1.35rem;border-bottom:1.5px solid var(--border-soft);display:flex;align-items:center;gap:.5rem;">
            <span style="font-size:1.15rem;">🏅</span>
            <h3 style="font-family:var(--font-heading);font-size:1.2rem;color:var(--text-dark);margin:0;">All Scores</h3>
        </div>

        <?php foreach ($attempts as $rank => $att):
            $s   = (int)$att['score'];
            $tot = (int)$att['total_questions'];
            $pct = round(($s / $tot) * 100);
            $medal = match(true) {
                $rank === 0 => '🥇',
                $rank === 1 => '🥈',
                $rank === 2 => '🥉',
                default     => '#' . ($rank + 1)
            };
            if ($s >= 9)      { $barColor = '#34d399'; $badgeClass = 'badge-mint'; }
            elseif ($s >= 7)  { $barColor = '#FF82AC'; $badgeClass = 'badge-pink'; }
            elseif ($s >= 4)  { $barColor = '#a78bfa'; $badgeClass = 'badge-lavender'; }
            else              { $barColor = '#f87171'; $badgeClass = 'badge-pink'; }
        ?>
        <div style="padding:1rem 1.35rem;border-bottom:1px solid var(--border-soft);display:flex;align-items:center;gap:1rem;transition:background .15s;"
             onmouseover="this.style.background='var(--bg-card-hover,#fff9fb)'"
             onmouseout="this.style.background=''">

            <!-- Rank Medal -->
            <div style="font-size:<?= is_numeric($medal) ? '.8rem' : '1.35rem' ?>;font-weight:800;color:var(--text-muted);min-width:32px;text-align:center;font-family:var(--font-heading);">
                <?= $medal ?>
            </div>

            <!-- Name + Bar -->
            <div style="flex:1;min-width:0;">
                <div style="font-weight:700;font-size:.97rem;color:var(--text-dark);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:.3rem;">
                    <?= e($att['participant_nickname']) ?>
                </div>
                <!-- Score bar -->
                <div style="height:6px;background:var(--border-soft);border-radius:99px;overflow:hidden;">
                    <div style="height:100%;width:<?= $pct ?>%;background:<?= $barColor ?>;border-radius:99px;transition:width .6s ease;"></div>
                </div>
            </div>

            <!-- Score Badge + Time -->
            <div style="text-align:right;flex-shrink:0;">
                <span class="badge <?= $badgeClass ?>" style="display:block;margin-bottom:.25rem;font-size:.85rem;">
                    <?= $s ?> / <?= $tot ?>
                </span>
                <span style="font-size:.75rem;color:var(--text-muted);">
                    <?= date('M d, g:i A', strtotime($att['submitted_at'])) ?>
                </span>
            </div>
        </div>
        <?php endforeach; ?>

        <div style="padding:.85rem 1.35rem;text-align:center;">
            <a href="<?= $playUrl ?>" class="btn btn-primary btn-sm">
                <span>💗</span> Play &amp; Beat These Scores!
            </a>
        </div>
    </div>
    <?php endif; ?>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

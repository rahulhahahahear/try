# Test of Bubu 💗

> **How well does your Bubu know you?**  
> An adorable, romantic, cartoon-style couple quiz platform for boyfriends, girlfriends, partners, crushes, and best friends.

![Test of Bubu Hero](assets/images/bubu-hero.png)

---

## 🌟 Key Highlights & Features

- **Cute Cartoon Aesthetic**: Original plush bear cartoon character artwork (`bubu-hero`, `bubu-happy`, `bubu-angry`, `bubu-sad`, `bubu-shy`, `bubu-thinking`), floating pastel sparkles, and bouncy micro-interactions.
- **Mobile-First & Ultra Responsive**: Designed from the ground up for phones, tablets, laptops, and desktops (tested across 320px–1440px).
- **Zero Heavy Frameworks**: Pure HTML5, CSS3, Vanilla JavaScript, and PHP 8.2+ with PDO prepared statements.
- **Automatic 10-Option Preset Pool (Zero Typing Required!)**: For each question, creators see 10 preset, non-editable cute option cards with names and photos/stickers. Creators simply tap their 1 true answer!
- **Dynamic 4-Option Matching**: When the quiz is taken by the partner, each question presents exactly 4 options: **1 right answer** (the creator's choice) + **3 randomly picked from the other 9 answers**!
- **Strict Server-Side Scoring & Security**: Correct answers are **never** sent to the client during quiz taking. Scoring, duplicate prevention, and attempts are validated strictly on the PHP backend.
- **Cute Character Score Reactions**:
  - 🏆 **9–10 Correct (Soulmate)**: Cheerful celebration, bouncing hearts, confetti burst, sweet dialogue.
  - 💖 **7–8 Correct (Pretty Good)**: Shy blushing bear, playful conversation, warm praise.
  - 🍿 **4–6 Correct (Needs More Dates)**: Thinking bear, comical question marks, snack-date demands.
  - 🚨 **0–3 Correct (Funny Angry Mode)**: Puffed cheeks, comic steam puffs, playful tease banter.
- **Automatic Expiration & Privacy**: Quizzes expire automatically after a set duration (default: 3 hours) and "melt away" cleanly.
- **Creator Management Dashboard**: Secure secret creator token provides access to stats, total attempts, average score, participant answers, and quiz availability toggles.
- **Frictionless Social Sharing**: One-click sharing to WhatsApp (prefilled cute message), Telegram, native Web Share API, clipboard copying with toast notifications, and a downloadable Canvas Story Card.
- **Automated Retention Cleanup**: Scheduled cron or authenticated maintenance script purges expired quizzes and uploads.

---

## 📁 Project Directory Structure

```
test-of-bubu/
├── index.php                  # Homepage with hero, how-it-works, sample quiz & code modal
├── create.php                 # Step-by-step quiz builder (Personalize, 10 Questions, Preview, Publish)
├── play.php                   # Participant flow (Welcome, 10-Question Player, Review, Result)
├── result.php                 # Standalone shareable result view
├── dashboard.php              # Secret creator results dashboard & stats
├── expired.php                # Friendly melted-away expired quiz notice
├── config/
│   ├── config.php             # Active application configuration (DB, base URL, expiration policies)
│   └── config.example.php     # Safe configuration template for version control
├── includes/
│   ├── db.php                 # Singleton PDO connection with UTC sync
│   ├── functions.php          # Core business logic, queries, scoring & reaction mappings
│   ├── security.php           # CSRF protection, hashing, rate limiting, upload validators
│   ├── header.php             # Reusable header with meta tags, fonts & navigation
│   └── footer.php             # Reusable footer with privacy modal & toast container
├── api/
│   ├── create-quiz.php        # POST: Validates & saves 10 questions to DB
│   ├── get-quiz.php           # GET: Fetches public quiz without correct answers
│   ├── submit-quiz.php        # POST: Scores attempt securely on server
│   ├── get-results.php        # GET: Creator endpoint for attempt history & breakdown
│   └── update-quiz.php        # POST: Creator endpoint to toggle quiz settings
├── assets/
│   ├── css/
│   │   └── style.css          # Mobile-first cartoon stylesheet, animations & variables
│   ├── js/
│   │   ├── app.js             # Toast system, clipboard, canvas card generator & modals
│   │   ├── quiz-builder.js    # Step-by-step builder, validation, dynamic dots & preview
│   │   └── quiz-player.js     # Touch-friendly answering, option selection & server scoring
│   ├── images/
│   │   ├── bubu-hero.webp / .png
│   │   ├── bubu-happy.webp / .png
│   │   ├── bubu-angry.webp / .png
│   │   ├── bubu-sad.webp / .png
│   │   ├── bubu-shy.webp / .png
│   │   ├── bubu-thinking.webp / .png
│   │   ├── bubu-empty.webp / .png
│   │   ├── bubu-share.webp / .png
│   │   ├── favicon.png
│   │   └── stickers/          # 10 cute SVG category stickers (food, travel, gifts, etc.)
│   └── uploads/               # User uploaded option images (secured against execution)
├── database/
│   └── schema.sql             # Relational MySQL schema with foreign key cascades & utf8mb4
├── scripts/
│   ├── cleanup-expired.php    # Maintenance cron / CLI purge script
│   ├── test-suite.php         # Automated 24-step verification test suite
│   ├── process-images.php     # Asset format converter
│   └── generate-stickers.php  # Vector SVG sticker generator
├── .htaccess                  # Apache security directives, headers & file protection
├── .gitignore                 # Source control ignore rules
└── README.md                  # This documentation file
```

---

## 🛠️ System Requirements

- **PHP**: 8.0+ (PHP 8.2+ recommended)
- **Database**: MySQL 5.7+ or MariaDB 10.3+
- **Required PHP Extensions**:
  - `pdo` and `pdo_mysql` (database operations)
  - `json` (API payloads)
  - `mbstring` (multibyte UTF-8 string handling)
  - `fileinfo` (MIME-type validation for uploads)
  - `gd` (optional, for image processing / WebP conversion)
  - `session` (CSRF tokens & rate limiting)

---

## 🚀 Installation & Local Setup

### 1. Database Setup
Create the MySQL database and import `database/schema.sql`:

```bash
# Using MySQL CLI
mysql -u root -p -e "CREATE DATABASE test_of_bubu CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -u root -p test_of_bubu < database/schema.sql
```

### 2. Configure Credentials
Copy `config/config.example.php` to `config/config.php` and update your settings:

```php
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'test_of_bubu');
define('DB_USER', 'root');
define('DB_PASS', '');

// Optional: Set BASE_URL manually if not running in standard root:
// define('BASE_URL', 'http://localhost/test');
```

### 3. Ensure Directory Permissions
Make sure the `assets/uploads/` directory is writable by your web server:

```bash
chmod 755 assets/uploads
```

### 4. Running Locally

#### Option A: Running with XAMPP / Apache
1. Place the project in `c:\xampp\htdocs\test\` (or your htdocs folder).
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:  
   👉 `http://localhost/test/`

#### Option B: Running with PHP's Built-In Web Server
```bash
cd test-of-bubu
php -S localhost:8000
```
Then visit `http://localhost:8000/`.

---

## 🧪 Running Automated Tests

A comprehensive verification test suite is included in `scripts/test-suite.php`. It validates 24 automated checks including:
- Quiz creation and persistence across MySQL tables
- Verification that answer keys are **never** exposed to participants
- All 4 cartoon score reaction bands (Soulmate, Pretty Good, Needs Time, Funny Angry)
- Idempotency and anti-duplicate submission protection
- Automatic expiration status transitions
- Creator authentication and dashboard retrieval

To execute the test suite:

```bash
php scripts/test-suite.php
```

Output:
```
========================================================
🧪 Running Test of Bubu Automated Test Suite
========================================================
✅ PASS: Quiz creation succeeded
✅ PASS: Public code generated (length >= 8)
✅ PASS: Creator token generated
✅ PASS: Quiz persisted in MySQL
✅ PASS: Exactly 10 questions saved
✅ PASS: Exactly 40 options saved (4 per question)
✅ PASS: Security: Participant questions DO NOT expose 'is_correct'
✅ PASS: Submission 10/10 succeeds
✅ PASS: Score is 10/10
✅ PASS: Reaction band is 'soulmate' with bubu-happy
...
========================================================
📊 Results: 24 Passed, 0 Failed
========================================================
```

---

## ⏱️ Expiration & Maintenance Cron Setup

Every quiz has a configured expiration time (default **3 hours**, with options for 12 hours, 24 hours, or 7 days).

### Scheduled Cron Job
To automatically delete quizzes that have been expired for more than 24 hours, schedule a cron job using either CLI or protected HTTP:

#### Option 1: CLI Cron (Recommended for Linux/cPanel)
Run every hour:
```bash
0 * * * * /usr/bin/php /path/to/test-of-bubu/scripts/cleanup-expired.php > /dev/null 2>&1
```

#### Option 2: Web Cron (e.g., cron-job.org or cPanel URL trigger)
Trigger the protected maintenance URL with your secret key configured in `config/config.php`:
```
GET https://yourdomain.com/scripts/cleanup-expired.php?key=YOUR_CRON_SECRET_KEY
```
*(Requests without the valid secret key return `403 Forbidden`)*

---

## 🔒 Security Measures Implemented

1. **Prepared Statements**: All database interactions use PDO with bound parameters. Emulated prepares are disabled.
2. **Hidden Answer Keys**: Correct answer flags (`is_correct`) are stored in MySQL and evaluated purely on the PHP server. Participant responses and API endpoints never receive answer flags before submission.
3. **Creator Tokens**: Creators receive a 48-character cryptographically secure token. The database stores only a SHA-256 hash. Even if someone knows the public quiz code, they cannot access the creator dashboard without the raw token.
4. **Output Escaping**: All user-supplied inputs (nicknames, question text, answers) are escaped with `htmlspecialchars(..., ENT_QUOTES, 'UTF-8')`.
5. **CSRF & Rate Limiting**: Built-in CSRF token verification and sliding-window rate limiting on quiz creation and submissions.
6. **Upload Sandbox**: Uploaded image files are checked for MIME type, verified using `getimagesize()`, renamed to randomized hashes, and the `assets/uploads/` directory contains an `.htaccess` rule forbidding execution of any script files.
7. **HTTP Security Headers**: Sends `X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `X-XSS-Protection: 1; mode=block`, and `Referrer-Policy: strict-origin-when-cross-origin`.

---

## 🐻 Cartoon Reaction Score Bands

| Score | Reaction Band | Character Asset | Mood & Banter |
|---|---|---|---|
| **9–10 / 10** | `soulmate` | `bubu-happy.webp` | *"OMG! YOU ACTUALLY KNOW YOUR BUBU! 💗"* — Confetti burst & soulmate badge. |
| **7–8 / 10** | `pretty_good` | `bubu-shy.webp` | *"Someone is paying attention! 🥰"* — Gentle character wiggle & sweet praise. |
| **4–6 / 10** | `needs_time` | `bubu-thinking.webp` | *"Hmm... we need more cute dates! 😤💗"* — Curious head tilt & snack demands. |
| **0–3 / 10** | `funny_angry` | `bubu-angry.webp` | *"EXCUSE ME?! WHO ARE YOU? 😭"* — Comic steam tremble & playful drama. |

---

## 💖 Made with Love
Test of Bubu is designed to bring smiles, laughter, and cozy couple drama. Have fun testing your Bubu! 🐻💕

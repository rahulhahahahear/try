<?php
/**
 * Test of Bubu 💗 - Quiz Creator Interface
 */

$pageTitle = 'Create Your Bubu Quiz 💗';
$pageDesc  = 'Personalize your 10-question quiz, pick your favourite things, and test your special person!';
$extraScripts = ['assets/js/quiz-builder.js'];
require_once __DIR__ . '/includes/header.php';
?>

<div class="container" style="max-width: 680px; padding-top: 2rem;">
    <!-- Builder Error Notice Box -->
    <div id="builder-error-box" class="card" style="display: none; background: #FFF0F0; border-color: #FFB3B3; color: #D32F2F; margin-bottom: 1.5rem; font-weight: 600; padding: 1rem 1.25rem;" role="alert"></div>

    <!-- STEP 1: Personalize -->
    <div id="step-1-personalize" class="card" style="display: block;">
        <div style="text-align: center; margin-bottom: 1.5rem;">
            <div style="width: 110px; height: 110px; margin: 0 auto 0.75rem;">
                <picture>
                    <source srcset="<?= BASE_URL ?>/assets/images/bubu-happy.webp" type="image/webp">
                    <img src="<?= BASE_URL ?>/assets/images/bubu-happy.png" alt="Cute celebrating bear" style="width: 100%; height: 100%; object-fit: contain;">
                </picture>
            </div>
            <span class="badge badge-pink">Step 1 of 3</span>
            <h2 style="font-family: var(--font-heading); font-size: 1.75rem; color: var(--text-dark); margin: 0.5rem 0;">
                Let's Make Your Bubu Quiz! 🐻💗
            </h2>
            <p style="color: var(--text-muted); font-size: 0.95rem;">
                Tell us a little bit about you and who this cute quiz is for.
            </p>
        </div>

        <form id="step-1-form" onsubmit="return false;">
            <div class="form-group">
                <label for="creator-nickname" class="form-label">What should we call you? 💕</label>
                <input type="text" id="creator-nickname" class="form-control" placeholder="e.g. Bubu, Cutie, Angel, Max" maxlength="50" required autofocus>
                <span class="form-hint">Your person will see this name on the welcome screen.</span>
            </div>

            <div class="form-group">
                <label for="relationship-type" class="form-label">Who will take this quiz? 🌸</label>
                <select id="relationship-type" class="form-control">
                    <option value="boyfriend">My Boyfriend 🐻</option>
                    <option value="girlfriend">My Girlfriend 🌸</option>
                    <option value="partner" selected>My Partner / S.O. 💖</option>
                    <option value="crush">My Secret Crush 🤫</option>
                    <option value="best_friend">My Best Friend 👯</option>
                </select>
            </div>

            <div class="form-group">
                <label for="quiz-title" class="form-label">Quiz Title <span style="font-weight: 400; color: var(--text-muted);">(Optional)</span></label>
                <input type="text" id="quiz-title" class="form-control" placeholder="e.g. How well do you really know me?" maxlength="100">
            </div>

            <div class="form-group">
                <label for="expiration-hours" class="form-label">Quiz Link Expiration ⏱️</label>
                <select id="expiration-hours" class="form-control">
                    <option value="3" selected>3 Hours (Default — Fresh & Cozy)</option>
                    <option value="12">12 Hours</option>
                    <option value="24">24 Hours (Full Day)</option>
                    <option value="168">7 Days (1 Week)</option>
                </select>
                <span class="form-hint">After this time, the quiz automatically melts away for your privacy!</span>
            </div>

            <button type="button" id="step-1-next-btn" class="btn btn-primary btn-block btn-lg" style="margin-top: 1.5rem;">
                <span>✨</span> Pick Your 10 Answers (1 Tap Each!)
            </button>
        </form>
    </div>

    <!-- STEP 2: 10 Questions Selector -->
    <div id="step-2-questions" class="card" style="display: none;">
        <!-- Stepper Progress Header -->
        <div class="quiz-stepper">
            <div class="stepper-header">
                <span id="q-current-num">Question 1 of 10</span>
                <span class="badge badge-pink">Pick Your Answer 💕</span>
            </div>
            <div class="progress-track" role="progressbar" aria-valuemin="1" aria-valuemax="10">
                <div id="q-progress-fill" class="progress-fill" style="width: 10%;"></div>
            </div>
            <!-- Quick Question Dots -->
            <div class="question-nav-dots" id="q-nav-dots"></div>
        </div>

        <!-- Question Title Header -->
        <div style="text-align: center; margin-bottom: 1.25rem;">
            <h3 id="builder-question-heading" style="font-family: var(--font-heading); font-size: 1.45rem; color: var(--text-dark); margin-bottom: 0.35rem;">
                <!-- Question heading injected dynamically -->
            </h3>
            <p style="color: var(--text-muted); font-size: 0.95rem;">
                👇 Tap the <strong>ONE</strong> answer that describes you! (1 option per line &bull; with cute icon/photo). We'll mix it with 3 random choices from the other 7 for your Bubu to guess! 🐻💗
            </p>
        </div>

        <!-- 8 Preset Automatic Option Cards List (1 Option Per Line) -->
        <div id="builder-pool-list" class="pool-options-list">
            <!-- 8 automatic cards injected dynamically by quiz-builder.js -->
        </div>

        <!-- Builder Navigation Buttons -->
        <div style="display: flex; gap: 0.75rem; margin-top: 1.75rem; justify-content: space-between;">
            <button type="button" id="prev-question-btn" class="btn btn-secondary">
                <span>👈</span> Previous
            </button>
            <button type="button" id="preview-quiz-btn" class="btn btn-outline">
                <span>🔍</span> Preview (4 Choices)
            </button>
            <button type="button" id="next-question-btn" class="btn btn-primary">
                <span>Next Question</span> <span>👉</span>
            </button>
        </div>
    </div>

    <!-- STEP 3: Preview Before Publishing -->
    <div id="step-3-preview" style="display: none;">
        <div class="card" style="text-align: center; margin-bottom: 1.5rem;">
            <span class="badge badge-pink">Step 3 of 3</span>
            <h2 style="font-family: var(--font-heading); font-size: 1.75rem; color: var(--text-dark); margin: 0.5rem 0;">
                Review Your 10 Questions 🔍💗
            </h2>
            <p style="color: var(--text-muted); font-size: 0.95rem;">
                Check all 10 questions and your correct choices. You can tap "Edit" on any question to make quick adjustments.
            </p>
        </div>

        <div id="preview-questions-list">
            <!-- Questions rendered here -->
        </div>

        <div style="display: flex; gap: 0.75rem; margin-top: 1.5rem; justify-content: space-between;">
            <button type="button" id="back-to-edit-btn" class="btn btn-secondary btn-lg">
                <span>👈</span> Back to Editing
            </button>
            <button type="button" id="publish-quiz-btn" class="btn btn-primary btn-lg">
                <span>💕</span> Publish & Generate Link
            </button>
        </div>
    </div>

    <!-- STEP 4: Success Screen -->
    <div id="step-4-success" class="card" style="display: none; text-align: center;">
        <div style="width: 180px; height: 180px; margin: 0 auto 1rem;">
            <picture>
                <source srcset="<?= BASE_URL ?>/assets/images/bubu-happy.webp" type="image/webp">
                <img src="<?= BASE_URL ?>/assets/images/bubu-happy.png" alt="Joyful bear celebrating" style="width: 100%; height: 100%; object-fit: contain;">
            </picture>
        </div>

        <span class="badge badge-mint" style="margin-bottom: 0.5rem;">🎉 Quiz Published!</span>
        <h2 style="font-family: var(--font-heading); font-size: 2rem; color: var(--text-dark); margin-bottom: 0.5rem;">
            Your Bubu test is ready! 💗
        </h2>
        <p style="color: var(--text-muted); font-size: 1rem; margin-bottom: 1.5rem;">
            Now send it to your favourite person and see if they really know you!
        </p>

        <!-- Shareable Link Box -->
        <div class="form-group" style="text-align: left;">
            <label class="form-label" for="shareable-link-input">Your Unique Quiz Link:</label>
            <div style="display: flex; gap: 0.5rem;">
                <input type="text" id="shareable-link-input" class="form-control" readonly style="background: #FFF7FA; font-weight: 600;">
                <button type="button" id="copy-link-btn" class="btn btn-outline" style="white-space: nowrap;">
                    📋 Copy
                </button>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 0.5rem;">
                <span class="badge badge-lavender" id="expiry-notice-badge">Expires in 3 hours</span>
                <span style="font-size: 0.8rem; color: var(--text-muted);">Protected by Bubu privacy ✨</span>
            </div>
        </div>

        <!-- Social Share Buttons -->
        <div class="share-actions-grid">
            <a href="#" id="whatsapp-share-btn" target="_blank" rel="noopener noreferrer" class="btn btn-whatsapp">
                <span>💬</span> Share on WhatsApp
            </a>
            <a href="#" id="telegram-share-btn" target="_blank" rel="noopener noreferrer" class="btn btn-telegram">
                <span>✈️</span> Share on Telegram
            </a>
            <button type="button" id="native-share-btn" class="btn btn-outline">
                <span>📱</span> Share with More Apps
            </button>
            <button type="button" id="download-card-btn" class="btn btn-secondary">
                <span>🎨</span> Download Story Card
            </button>
        </div>

        <!-- Private Creator Management Dashboard Link -->
        <div style="background: #FFF9FA; border: 2px dashed #FFD4E5; border-radius: var(--radius-md); padding: 1.25rem; margin-top: 1.75rem; text-align: left;">
            <h4 style="font-family: var(--font-heading); color: var(--deep-pink); font-size: 1.05rem; margin-bottom: 0.35rem;">
                🔒 Your Secret Creator Dashboard:
            </h4>
            <p style="font-size: 0.875rem; color: var(--text-dark); margin-bottom: 0.75rem;">
                Bookmark or save this link to see how your person answers, review their scores, and view attempt history!
            </p>
            <a href="#" id="creator-dashboard-btn" class="btn btn-outline btn-sm">
                <span>📊</span> Go to My Creator Dashboard
            </a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

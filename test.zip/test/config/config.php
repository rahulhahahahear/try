<?php
/**
 * Test of Bubu 💗 - Application Configuration
 */

// Database credentials
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'test_of_bubu');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Application Settings
define('APP_NAME', 'Test of Bubu 💗');
define('APP_TAGLINE', 'How well does your Bubu know you?');

// Detect Base URL dynamically for local dev or production
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptDir = dirname($_SERVER['SCRIPT_NAME'] ?? '/test/');
$baseDir = str_replace('\\', '/', $scriptDir);
// If executing inside /api or /scripts, point to root app
if (preg_match('#/(api|scripts)#', $baseDir)) {
    $baseDir = preg_replace('#/(api|scripts).*$#', '', $baseDir);
}
$baseDir = rtrim($baseDir, '/');
define('BASE_URL', $protocol . $host . ($baseDir ? $baseDir : ''));

// Expiration Policies (Hours)
define('DEFAULT_EXPIRATION_HOURS', 3);
define('ALLOWED_EXPIRATION_HOURS', [3, 12, 24, 168]);

// Security & Maintenance
define('CRON_SECRET_KEY', 'bubu_secret_cron_token_change_in_prod_99');
define('ADMIN_PASSWORD', 'bubu_admin_2024');   // ← Change this to a strong password!
define('MAX_UPLOAD_SIZE', 2 * 1024 * 1024); // 2 MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/webp']);
define('ALLOWED_IMAGE_EXTS', ['jpg', 'jpeg', 'png', 'webp']);

// Uploads Directory
define('UPLOAD_DIR', dirname(__DIR__) . '/assets/uploads');
define('UPLOAD_URL', BASE_URL . '/assets/uploads');

// Default Timezone
date_default_timezone_set('UTC');

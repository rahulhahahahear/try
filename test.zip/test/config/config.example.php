<?php
/**
 * Test of Bubu 💗 - Configuration Template
 * Copy this file to config.php and update credentials as needed.
 */

define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'test_of_bubu');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

define('APP_NAME', 'Test of Bubu 💗');
define('APP_TAGLINE', 'How well does your Bubu know you?');

// Set manually if not auto-detected: e.g. 'https://yourdomain.com'
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptDir = dirname($_SERVER['SCRIPT_NAME'] ?? '');
$baseDir = str_replace('\\', '/', $scriptDir);
if (preg_match('#/(api|scripts)#', $baseDir)) {
    $baseDir = preg_replace('#/(api|scripts).*$#', '', $baseDir);
}
$baseDir = rtrim($baseDir, '/');
define('BASE_URL', $protocol . $host . ($baseDir ? $baseDir : ''));

define('DEFAULT_EXPIRATION_HOURS', 3);
define('ALLOWED_EXPIRATION_HOURS', [3, 12, 24, 168]);
define('CRON_SECRET_KEY', 'CHANGE_THIS_RANDOM_SECRET_KEY');
define('MAX_UPLOAD_SIZE', 2 * 1024 * 1024);
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/webp']);
define('ALLOWED_IMAGE_EXTS', ['jpg', 'jpeg', 'png', 'webp']);
define('UPLOAD_DIR', dirname(__DIR__) . '/assets/uploads');
define('UPLOAD_URL', BASE_URL . '/assets/uploads');

date_default_timezone_set('UTC');

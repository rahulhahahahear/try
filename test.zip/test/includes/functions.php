<?php
/**
 * Test of Bubu 💗 - Core Business Logic Functions
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/question-pool.php';

/**
 * Fetch a quiz by its public code.
 * Automatically checks and updates expiration status if expired.
 */
function findQuizByCode(string $code): ?array {
    $db = getDb();
    $stmt = $db->prepare("
        SELECT * FROM quizzes 
        WHERE public_code = :code 
          AND deleted_at IS NULL 
        LIMIT 1
    ");
    $stmt->execute(['code' => $code]);
    $quiz = $stmt->fetch();

    if (!$quiz) {
        return null;
    }

    // Check expiry
    $expiresAt = strtotime($quiz['expires_at']);
    if (time() >= $expiresAt && $quiz['status'] === 'active') {
        $updateStmt = $db->prepare("UPDATE quizzes SET status = 'expired' WHERE id = :id");
        $updateStmt->execute(['id' => $quiz['id']]);
        $quiz['status'] = 'expired';
    }

    return $quiz;
}

/**
 * Retrieve quiz with its 10 questions and 4 options per question.
 * $includeCorrect: set to true ONLY for creator dashboard or server scoring, NEVER for participant taking the quiz!
 */
function findQuizWithQuestions(string $code, bool $includeCorrect = false): ?array {
    $quiz = findQuizByCode($code);
    if (!$quiz) {
        return null;
    }

    $db = getDb();
    // Fetch questions
    $stmtQ = $db->prepare("
        SELECT id, question_text, question_order 
        FROM questions 
        WHERE quiz_id = :quiz_id 
        ORDER BY question_order ASC
    ");
    $stmtQ->execute(['quiz_id' => $quiz['id']]);
    $questions = $stmtQ->fetchAll();

    $questionIds = array_column($questions, 'id');
    $optionsByQuestion = [];

    if (!empty($questionIds)) {
        $inQuery = implode(',', array_fill(0, count($questionIds), '?'));
        
        $selectCols = "id, question_id, option_text, option_emoji, option_image_path, option_order";
        if ($includeCorrect) {
            $selectCols .= ", is_correct";
        }

        $stmtOpt = $db->prepare("
            SELECT {$selectCols} 
            FROM options 
            WHERE question_id IN ({$inQuery}) 
            ORDER BY option_order ASC
        ");
        $stmtOpt->execute($questionIds);
        $options = $stmtOpt->fetchAll();

        foreach ($options as $opt) {
            $optionsByQuestion[$opt['question_id']][] = $opt;
        }
    }

    foreach ($questions as &$q) {
        $q['options'] = $optionsByQuestion[$q['id']] ?? [];
    }
    unset($q);

    $quiz['questions'] = $questions;
    return $quiz;
}

/**
 * Verify creator credentials and return quiz
 */
function findQuizForCreator(string $code, string $token): ?array {
    $quiz = findQuizByCode($code);
    if (!$quiz) {
        return null;
    }

    if (!verifyCreatorToken($token, $quiz['creator_token_hash'])) {
        return null;
    }

    return $quiz;
}

/**
 * Create a new quiz with 10 questions and 4 options each (1 correct + 3 random from 9)
 */
function createQuiz(array $payload): array {
    $db = getDb();

    $creatorNickname = trim($payload['creator_nickname'] ?? '');
    $quizTitle       = trim($payload['quiz_title'] ?? '');
    $relationship    = trim($payload['relationship_type'] ?? 'partner');
    $expiryHours     = (int)($payload['expiration_hours'] ?? DEFAULT_EXPIRATION_HOURS);
    $questions       = $payload['questions'] ?? [];

    // Support automatic 10-option pool selections: 1 correct + 3 random from 9
    if (isset($payload['selections']) && is_array($payload['selections']) && empty($questions)) {
        $pool = getMasterQuestionPool();
        $poolById = [];
        foreach ($pool as $pQ) {
            $poolById[$pQ['id']] = $pQ;
        }

        $questions = [];
        foreach ($payload['selections'] as $idx => $sel) {
            $qId = (int)($sel['question_id'] ?? ($idx + 1));
            $selectedOptId = (int)($sel['selected_option_id'] ?? 0);

            if (!isset($poolById[$qId])) {
                return ['success' => false, 'error' => "Invalid question ID {$qId}."];
            }

            $pQ = $poolById[$qId];
            $allOpts = $pQ['options'];
            $correctOpt = null;
            $otherOpts = [];

            foreach ($allOpts as $opt) {
                if ((int)$opt['id'] === $selectedOptId) {
                    $correctOpt = $opt;
                } else {
                    $otherOpts[] = $opt;
                }
            }

            if (!$correctOpt) {
                return ['success' => false, 'error' => "Please choose your answer for Question " . ($idx + 1) . "."];
            }

            // Pick 3 random distractors from remaining 9 options
            shuffle($otherOpts);
            $distractors = array_slice($otherOpts, 0, 3);

            // Combine 1 right and 3 random options
            $finalFour = [
                [
                    'text'       => $correctOpt['text'],
                    'emoji'      => $correctOpt['emoji'],
                    'image_path' => $correctOpt['image'],
                    'is_correct' => true
                ]
            ];

            foreach ($distractors as $d) {
                $finalFour[] = [
                    'text'       => $d['text'],
                    'emoji'      => $d['emoji'],
                    'image_path' => $d['image'],
                    'is_correct' => false
                ];
            }

            // Shuffle the 4 choices so the correct answer is randomized
            shuffle($finalFour);

            $questions[] = [
                'text'    => $pQ['question_text'],
                'options' => $finalFour
            ];
        }
    }

    if ($creatorNickname === '') {
        return ['success' => false, 'error' => 'Please enter your nickname.'];
    }

    if (mb_strlen($creatorNickname) > 50) {
        return ['success' => false, 'error' => 'Nickname is too long (max 50 characters).'];
    }

    if (!in_array($expiryHours, ALLOWED_EXPIRATION_HOURS, true)) {
        $expiryHours = DEFAULT_EXPIRATION_HOURS;
    }

    if (count($questions) !== 10) {
        return ['success' => false, 'error' => 'Quiz must have exactly 10 questions. Found ' . count($questions) . '.'];
    }

    // Validate each question and options
    foreach ($questions as $idx => $q) {
        $qNum = $idx + 1;
        $qText = trim($q['text'] ?? '');
        if ($qText === '') {
            return ['success' => false, 'error' => "Question {$qNum} text cannot be empty."];
        }

        $opts = $q['options'] ?? [];
        if (count($opts) !== 4) {
            return ['success' => false, 'error' => "Question {$qNum} must have exactly 4 answer options."];
        }

        $correctCount = 0;
        $textsSeen = [];

        foreach ($opts as $optIdx => $opt) {
            $optText = trim($opt['text'] ?? '');
            if ($optText === '') {
                return ['success' => false, 'error' => "Option " . chr(65 + $optIdx) . " in Question {$qNum} cannot be blank."];
            }
            if (in_array(mb_strtolower($optText), $textsSeen, true)) {
                return ['success' => false, 'error' => "Question {$qNum} has duplicate answer options."];
            }
            $textsSeen[] = mb_strtolower($optText);

            if (!empty($opt['is_correct'])) {
                $correctCount++;
            }
        }

        if ($correctCount !== 1) {
            return ['success' => false, 'error' => "Question {$qNum} must have exactly one correct answer selected."];
        }
    }

    // Generate tokens and expiration
    $publicCode = generatePublicCode(10);
    $creatorToken = generateToken(24);
    $creatorTokenHash = hashCreatorToken($creatorToken);

    $now = time();
    $expiresAt = date('Y-m-d H:i:s', $now + ($expiryHours * 3600));

    $db->beginTransaction();
    try {
        $stmtQuiz = $db->prepare("
            INSERT INTO quizzes (
                public_code, creator_token_hash, creator_nickname, quiz_title, 
                relationship_type, status, created_at, expires_at, 
                allow_repeat_attempts, reveal_detailed_answers
            ) VALUES (
                :code, :token_hash, :nickname, :title, 
                :rel, 'active', NOW(), :expires_at, 
                1, 1
            )
        ");
        $stmtQuiz->execute([
            'code'        => $publicCode,
            'token_hash'  => $creatorTokenHash,
            'nickname'    => $creatorNickname,
            'title'       => $quizTitle !== '' ? $quizTitle : "How well do you know {$creatorNickname}?",
            'rel'         => $relationship,
            'expires_at'  => $expiresAt
        ]);
        $quizId = (int)$db->lastInsertId();

        $stmtQ = $db->prepare("
            INSERT INTO questions (quiz_id, question_text, question_order) 
            VALUES (:quiz_id, :text, :order)
        ");

        $stmtOpt = $db->prepare("
            INSERT INTO options (
                question_id, option_text, option_emoji, option_image_path, is_correct, option_order
            ) VALUES (
                :question_id, :text, :emoji, :image_path, :is_correct, :order
            )
        ");

        foreach ($questions as $qIdx => $q) {
            $stmtQ->execute([
                'quiz_id' => $quizId,
                'text'    => trim($q['text']),
                'order'   => $qIdx + 1
            ]);
            $questionId = (int)$db->lastInsertId();

            foreach ($q['options'] as $optIdx => $opt) {
                $stmtOpt->execute([
                    'question_id' => $questionId,
                    'text'        => trim($opt['text']),
                    'emoji'       => !empty($opt['emoji']) ? trim($opt['emoji']) : null,
                    'image_path'  => !empty($opt['image_path']) ? trim($opt['image_path']) : null,
                    'is_correct'  => !empty($opt['is_correct']) ? 1 : 0,
                    'order'       => $optIdx + 1
                ]);
            }
        }

        $db->commit();

        return [
            'success'       => true,
            'public_code'   => $publicCode,
            'creator_token' => $creatorToken,
            'expires_at'    => $expiresAt,
            'play_url'      => BASE_URL . '/play.php?code=' . $publicCode,
            'dashboard_url' => BASE_URL . '/dashboard.php?code=' . $publicCode . '&token=' . $creatorToken
        ];
    } catch (Exception $e) {
        $db->rollBack();
        error_log("Failed to create quiz: " . $e->getMessage());
        return ['success' => false, 'error' => 'Database error while saving quiz: ' . $e->getMessage()];
    }
}

/**
 * Submit quiz answers by a participant and calculate score on server
 */
function submitQuizAttempt(string $publicCode, string $participantNickname, array $submittedAnswers, string $attemptToken): array {
    $db = getDb();
    $quiz = findQuizByCode($publicCode);

    if (!$quiz) {
        return ['success' => false, 'error' => "Hmm... we couldn't find this Bubu test. Check the link and try again! 💗"];
    }

    if ($quiz['status'] === 'expired' || strtotime($quiz['expires_at']) <= time()) {
        return [
            'success' => false, 
            'error'   => 'This quiz link has expired. Ask your person to make a fresh one! 🫠💗',
            'is_expired' => true
        ];
    }

    if ($quiz['status'] !== 'active') {
        return ['success' => false, 'error' => 'This quiz is currently disabled or unavailable.'];
    }

    // Check repeat attempts setting
    $attemptTokenHash = hash('sha256', trim($attemptToken));

    // Check idempotency: if this exact attemptTokenHash was already submitted, return the existing result!
    $stmtCheck = $db->prepare("
        SELECT id, score, total_questions 
        FROM attempts 
        WHERE quiz_id = :quiz_id AND attempt_token_hash = :hash 
        LIMIT 1
    ");
    $stmtCheck->execute([
        'quiz_id' => $quiz['id'],
        'hash'    => $attemptTokenHash
    ]);
    $existing = $stmtCheck->fetch();

    if ($existing) {
        $reaction = getReactionData((int)$existing['score'], (int)$existing['total_questions']);
        return [
            'success'         => true,
            'attempt_id'      => (int)$existing['id'],
            'score'           => (int)$existing['score'],
            'total'           => (int)$existing['total_questions'],
            'percentage'      => (int)round(((int)$existing['score'] / (int)$existing['total_questions']) * 100),
            'reaction'        => $reaction,
            'idempotent'      => true
        ];
    }

    // If repeat attempts are not allowed, check if IP or session already attempted
    if (!$quiz['allow_repeat_attempts'] && !empty($_SESSION['attempted_quizzes'][$quiz['id']])) {
        return ['success' => false, 'error' => 'Repeat attempts are not allowed for this quiz.'];
    }

    // Fetch all questions and their correct options
    $fullQuiz = findQuizWithQuestions($publicCode, true);
    $questions = $fullQuiz['questions'] ?? [];

    if (count($questions) !== 10) {
        return ['success' => false, 'error' => 'Quiz is incomplete.'];
    }

    // Build map of correct option ID per question
    $correctMap = [];
    $validOptionIds = [];
    foreach ($questions as $q) {
        foreach ($q['options'] as $opt) {
            $validOptionIds[$q['id']][] = (int)$opt['id'];
            if (!empty($opt['is_correct'])) {
                $correctMap[$q['id']] = (int)$opt['id'];
            }
        }
    }

    // Validate submitted answers count
    if (count($submittedAnswers) !== 10) {
        return ['success' => false, 'error' => 'Please answer all 10 questions before submitting.'];
    }

    $score = 0;
    $recordAnswers = [];

    foreach ($questions as $q) {
        $qId = (int)$q['id'];
        if (!isset($submittedAnswers[$qId])) {
            return ['success' => false, 'error' => 'Answer missing for question: "' . mb_substr($q['question_text'], 0, 30) . '..."'];
        }

        $selectedOptId = (int)$submittedAnswers[$qId];
        if (!in_array($selectedOptId, $validOptionIds[$qId] ?? [], true)) {
            return ['success' => false, 'error' => 'Invalid answer choice submitted.'];
        }

        $isCorrect = ($selectedOptId === ($correctMap[$qId] ?? -1));
        if ($isCorrect) {
            $score++;
        }

        $recordAnswers[] = [
            'question_id'        => $qId,
            'selected_option_id' => $selectedOptId,
            'is_correct'         => $isCorrect ? 1 : 0
        ];
    }

    $pNickname = trim($participantNickname) !== '' ? trim($participantNickname) : 'Your Bubu';
    if (mb_strlen($pNickname) > 50) {
        $pNickname = mb_substr($pNickname, 0, 50);
    }

    $db->beginTransaction();
    try {
        $stmtAttempt = $db->prepare("
            INSERT INTO attempts (
                quiz_id, attempt_token_hash, participant_nickname, score, total_questions, submitted_at, completion_status
            ) VALUES (
                :quiz_id, :token_hash, :nickname, :score, 10, NOW(), 'completed'
            )
        ");
        $stmtAttempt->execute([
            'quiz_id'    => $quiz['id'],
            'token_hash' => $attemptTokenHash,
            'nickname'   => $pNickname,
            'score'      => $score
        ]);
        $attemptId = (int)$db->lastInsertId();

        $stmtAns = $db->prepare("
            INSERT INTO attempt_answers (attempt_id, question_id, selected_option_id, is_correct) 
            VALUES (:attempt_id, :q_id, :opt_id, :is_correct)
        ");

        foreach ($recordAnswers as $ans) {
            $stmtAns->execute([
                'attempt_id' => $attemptId,
                'q_id'       => $ans['question_id'],
                'opt_id'     => $ans['selected_option_id'],
                'is_correct' => $ans['is_correct']
            ]);
        }

        $db->commit();

        $_SESSION['attempted_quizzes'][$quiz['id']] = $attemptId;

        $reaction = getReactionData($score, 10);
        return [
            'success'      => true,
            'attempt_id'   => $attemptId,
            'score'        => $score,
            'total'        => 10,
            'percentage'   => (int)round(($score / 10) * 100),
            'reaction'     => $reaction,
            'reveal_answers' => (bool)$quiz['reveal_detailed_answers']
        ];
    } catch (Exception $e) {
        $db->rollBack();
        error_log("Failed to save attempt: " . $e->getMessage());
        return ['success' => false, 'error' => 'Oops! Something went wrong saving your results. Please try again.'];
    }
}

/**
 * Scoring and character reaction details based on score bands
 */
function getReactionData(int $score, int $total = 10): array {
    $percentage = round(($score / $total) * 100);

    if ($score >= 9) {
        return [
            'band'         => 'soulmate',
            'headline'     => 'OMG! YOU ACTUALLY KNOW YOUR BUBU! 💗',
            'subheadline'  => 'Soulmate-level knowledge unlocked! ✨',
            'character'    => 'bubu-happy',
            'image'        => 'assets/images/bubu-happy.webp',
            'image_fallback' => 'assets/images/bubu-happy.png',
            'conversation' => [
                ['speaker' => 'Bubu', 'text' => 'Awww! You remember EVERYTHING about me? 🥹💕'],
                ['speaker' => 'Bear', 'text' => 'Okay, this is suspiciously cute! Kiss incoming! 😘']
            ],
            'animation'    => 'bounce-hearts',
            'badge_color'  => '#F45187',
            'badge_text'   => 'Certified Soulmate 🏆'
        ];
    }

    if ($score >= 7) {
        return [
            'band'         => 'pretty_good',
            'headline'     => 'Someone is paying attention! 🥰',
            'subheadline'  => 'Pretty impressive! You know your person well.',
            'character'    => 'bubu-shy',
            'image'        => 'assets/images/bubu-shy.webp',
            'image_fallback' => 'assets/images/bubu-shy.png',
            'conversation' => [
                ['speaker' => 'Bubu', 'text' => 'Hehe, you know me better than I expected! 🐻🌸'],
                ['speaker' => 'Bear', 'text' => 'A little more cuddles and you’ll get 10/10!']
            ],
            'animation'    => 'wiggle-gentle',
            'badge_color'  => '#FF82AC',
            'badge_text'   => 'Super Sweet Heart 💖'
        ];
    }

    if ($score >= 4) {
        return [
            'band'         => 'needs_time',
            'headline'     => 'Hmm... we need more cute dates! 😤💗',
            'subheadline'  => 'Room for improvement, but plenty of love!',
            'character'    => 'bubu-thinking',
            'image'        => 'assets/images/bubu-thinking.webp',
            'image_fallback' => 'assets/images/bubu-thinking.png',
            'conversation' => [
                ['speaker' => 'Bubu', 'text' => 'Wait... you didn\'t know THAT about me? 🧐'],
                ['speaker' => 'Bear', 'text' => 'Time for snacks, bobas, and a long conversation! 🧋']
            ],
            'animation'    => 'thinking-wobble',
            'badge_color'  => '#7E57C2',
            'badge_text'   => 'Date Night Required 🍿'
        ];
    }

    // 0 - 3
    return [
        'band'         => 'funny_angry',
        'headline'     => 'EXCUSE ME?! WHO ARE YOU? 😭',
        'subheadline'  => 'Are we even dating, or are you a secret stranger?!',
        'character'    => 'bubu-angry',
        'image'        => 'assets/images/bubu-angry.webp',
        'image_fallback' => 'assets/images/bubu-angry.png',
        'conversation' => [
            ['speaker' => 'Bubu', 'text' => 'So... do we even know each other?! 😤💢'],
            ['speaker' => 'Bear', 'text' => 'Quick! Bring snacks, flowers, and apologise! 🍫💐']
        ],
        'animation'    => 'angry-steam',
        'badge_color'  => '#E53935',
        'badge_text'   => 'In Bubu Trouble 🚨'
    ];
}

/**
 * Fetch all attempts for a quiz (Creator Dashboard)
 */
function getQuizAttempts(int $quizId): array {
    $db = getDb();
    $stmt = $db->prepare("
        SELECT id, participant_nickname, score, total_questions, submitted_at, completion_status
        FROM attempts
        WHERE quiz_id = :quiz_id
        ORDER BY submitted_at DESC
    ");
    $stmt->execute(['quiz_id' => $quizId]);
    return $stmt->fetchAll();
}

/**
 * Fetch detailed answers of an attempt
 */
function getAttemptDetailedAnswers(int $attemptId): array {
    $db = getDb();
    $stmt = $db->prepare("
        SELECT 
            aa.is_correct,
            q.question_text,
            q.question_order,
            o.option_text AS selected_text,
            o.option_emoji AS selected_emoji,
            co.option_text AS correct_text,
            co.option_emoji AS correct_emoji
        FROM attempt_answers aa
        JOIN questions q ON q.id = aa.question_id
        JOIN options o ON o.id = aa.selected_option_id
        JOIN options co ON co.question_id = q.id AND co.is_correct = 1
        WHERE aa.attempt_id = :attempt_id
        ORDER BY q.question_order ASC
    ");
    $stmt->execute(['attempt_id' => $attemptId]);
    return $stmt->fetchAll();
}

<?php
/**
 * Test of Bubu 💗 - Global Header Template
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/security.php';

sendSecurityHeaders();

$pageTitle = isset($pageTitle) ? $pageTitle . ' | ' . APP_NAME : APP_NAME . ' — ' . APP_TAGLINE;
$pageDesc  = $pageDesc ?? 'Take the adorable Test of Bubu! Create a cute 10-question quiz for your partner or bestie and see how well they really know you!';
$currentUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?= e($pageTitle) ?></title>
    <meta name="description" content="<?= e($pageDesc) ?>">
    
    <!-- OpenGraph / Social Sharing -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?= e($pageTitle) ?>">
    <meta property="og:description" content="<?= e($pageDesc) ?>">
    <meta property="og:image" content="<?= BASE_URL ?>/assets/images/bubu-hero.png">
    <meta property="og:url" content="<?= e($currentUrl) ?>">
    
    <!-- Twitter Cards -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= e($pageTitle) ?>">
    <meta name="twitter:description" content="<?= e($pageDesc) ?>">
    <meta name="twitter:image" content="<?= BASE_URL ?>/assets/images/bubu-hero.png">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/images/favicon.png">
    <link rel="apple-touch-icon" href="<?= BASE_URL ?>/assets/images/favicon.png">
    <meta name="theme-color" content="#FF82AC">
    
    <!-- Google Fonts: Fredoka & Nunito -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;500;600;700&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Main Style -->
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    
    <script>
        window.APP_CONFIG = {
            baseUrl: "<?= BASE_URL ?>",
            csrfToken: "<?= getCsrfToken() ?>"
        };
    </script>
</head>
<body>
    <div class="site-wrapper">
        <!-- Floating hearts background ambiance -->
        <div class="floating-bg-decor" aria-hidden="true">
            <span class="decor-heart h1">💗</span>
            <span class="decor-heart h2">✨</span>
            <span class="decor-heart h3">🌸</span>
            <span class="decor-heart h4">💖</span>
            <span class="decor-heart h5">🐻</span>
            <span class="decor-heart h6">⭐</span>
        </div>

        <!-- Main Header -->
        <header class="main-header" role="banner">
            <div class="container header-container">
                <a href="<?= BASE_URL ?>/" class="brand-logo" aria-label="Test of Bubu Home">
                    <span class="logo-icon">🐻💗</span>
                    <span class="logo-text">Test of Bubu</span>
                </a>

                <nav class="header-nav" aria-label="Main Navigation">
                    <a href="<?= BASE_URL ?>/#how-it-works" class="nav-link">How it works</a>
                    <a href="<?= BASE_URL ?>/create.php" class="btn btn-sm btn-primary">
                        <span class="btn-icon">💕</span> Create Quiz
                    </a>
                </nav>
            </div>
        </header>

        <main class="main-content" id="main-content">

        </main> <!-- /.main-content -->

        <footer class="main-footer" role="contentinfo">
            <div class="container footer-container">
                <div class="footer-character">
                    <span class="tiny-bear">🐻</span>
                    <span class="footer-heart">💗</span>
                    <span class="tiny-bear">🐻</span>
                </div>
                <p class="footer-title">Test of Bubu 💗</p>
                <p class="footer-tagline">Made with hugs & giggles for your favourite person in the world.</p>
                
                <div class="footer-links">
                    <a href="<?= BASE_URL ?>/" class="footer-link">Home</a>
                    <a href="<?= BASE_URL ?>/create.php" class="footer-link">Create Quiz</a>
                    <a href="#privacy-modal" class="footer-link" id="open-privacy-btn">Privacy & Retention</a>
                </div>

                <div class="footer-legal">
                    <p class="copyright">&copy; <?= date('Y') ?> Test of Bubu. All rights reserved.</p>
                    <p class="disclaimer">Quizzes automatically expire after their scheduled duration to keep things fresh and private.</p>
                </div>
            </div>
        </footer>
    </div> <!-- /.site-wrapper -->

    <!-- Global Toast Container -->
    <div id="toast-container" class="toast-container" role="status" aria-live="polite"></div>

    <!-- Privacy & Data Retention Modal -->
    <div id="privacy-modal" class="modal-backdrop" aria-hidden="true">
        <div class="modal-dialog" role="dialog" aria-modal="true" aria-labelledby="privacy-title">
            <div class="modal-header">
                <h3 id="privacy-title">🌸 Privacy & Retention Policy</h3>
                <button type="button" class="modal-close-btn" id="close-privacy-btn" aria-label="Close dialog">&times;</button>
            </div>
            <div class="modal-body">
                <p><strong>Test of Bubu</strong> is built with privacy-first values:</p>
                <ul>
                    <li>No mandatory accounts, emails, or phone numbers are ever required.</li>
                    <li>Each quiz link expires automatically (3 hours by default).</li>
                    <li>Expired quiz records and attempts are safely purged by our automated maintenance cleanup.</li>
                    <li>Only the quiz creator who has their private secret management link can see full attempt score breakdowns.</li>
                    <li>Uploaded images are strictly validated, renamed, and purged along with expired quizzes.</li>
                </ul>
                <p class="modal-note">Have fun testing your Bubu and enjoy the sweet banter! 🐻💕</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary btn-sm" id="ack-privacy-btn">Got it! 💗</button>
            </div>
        </div>
    </div>

    <!-- Main JavaScript -->
    <script src="<?= BASE_URL ?>/assets/js/app.js"></script>
    <?php if (isset($extraScripts)): ?>
        <?php foreach ($extraScripts as $script): ?>
            <script src="<?= BASE_URL ?>/<?= e($script) ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>

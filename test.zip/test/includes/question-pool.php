<?php
/**
 * Test of Bubu 💗 - Automatic 10 Questions Pool
 * Admin-editable via admin.php -> "Default Questions" section.
 * Override file: config/question_pool.json (written by admin panel).
 * Falls back to hardcoded defaults if the override file doesn't exist.
 */

/**
 * Returns the hardcoded default pool (always available as fallback).
 */
function getDefaultQuestionPool(): array {
    return [
        [
            'id' => 1,
            'question_text' => 'What is my favourite food? 🍕',
            'category' => 'food',
            'options' => [
                ['id' => 1, 'text' => 'Pizza', 'emoji' => '🍕', 'image' => 'assets/images/options/q1_opt1.svg'],
                ['id' => 2, 'text' => 'Momos / Dumplings', 'emoji' => '🥟', 'image' => 'assets/images/options/q1_opt2.svg'],
                ['id' => 3, 'text' => 'Biryani', 'emoji' => '🍛', 'image' => 'assets/images/options/q1_opt3.svg'],
                ['id' => 4, 'text' => 'Burger & Fries', 'emoji' => '🍔', 'image' => 'assets/images/options/q1_opt4.svg'],
                ['id' => 5, 'text' => 'Pasta / Lasagna', 'emoji' => '🍝', 'image' => 'assets/images/options/q1_opt5.svg'],
                ['id' => 6, 'text' => 'Noodles / Ramen', 'emoji' => '🍜', 'image' => 'assets/images/options/q1_opt6.svg'],
                ['id' => 7, 'text' => 'Ice Cream Sundae', 'emoji' => '🍦', 'image' => 'assets/images/options/q1_opt7.svg'],
                ['id' => 8, 'text' => 'Chocolate & Brownie', 'emoji' => '🍫', 'image' => 'assets/images/options/q1_opt8.svg'],
            ]
        ],
        [
            'id' => 2,
            'question_text' => 'Which app do I spend the most time on? 📱',
            'category' => 'apps',
            'options' => [
                ['id' => 1, 'text' => 'Instagram (Reels)', 'emoji' => '📸', 'image' => 'assets/images/options/q2_opt1.svg'],
                ['id' => 2, 'text' => 'WhatsApp (Chatting)', 'emoji' => '💬', 'image' => 'assets/images/options/q2_opt2.svg'],
                ['id' => 3, 'text' => 'YouTube', 'emoji' => '▶️', 'image' => 'assets/images/options/q2_opt3.svg'],
                ['id' => 4, 'text' => 'TikTok / Short Videos', 'emoji' => '🎵', 'image' => 'assets/images/options/q2_opt4.svg'],
                ['id' => 5, 'text' => 'Pinterest', 'emoji' => '📌', 'image' => 'assets/images/options/q2_opt5.svg'],
                ['id' => 6, 'text' => 'Spotify (Music)', 'emoji' => '🎧', 'image' => 'assets/images/options/q2_opt6.svg'],
                ['id' => 7, 'text' => 'Netflix / Shows', 'emoji' => '🍿', 'image' => 'assets/images/options/q2_opt7.svg'],
                ['id' => 8, 'text' => 'Snapchat', 'emoji' => '👻', 'image' => 'assets/images/options/q2_opt8.svg'],
            ]
        ],
        [
            'id' => 3,
            'question_text' => 'What is my favourite colour? 🎨',
            'category' => 'colors',
            'options' => [
                ['id' => 1, 'text' => 'Baby Pink', 'emoji' => '🌸', 'image' => 'assets/images/options/q3_opt1.svg'],
                ['id' => 2, 'text' => 'Sky Blue', 'emoji' => '🌊', 'image' => 'assets/images/options/q3_opt2.svg'],
                ['id' => 3, 'text' => 'Lavender Purple', 'emoji' => '💜', 'image' => 'assets/images/options/q3_opt3.svg'],
                ['id' => 4, 'text' => 'Classic Black', 'emoji' => '🖤', 'image' => 'assets/images/options/q3_opt4.svg'],
                ['id' => 5, 'text' => 'Mint / Pastel Green', 'emoji' => '🍃', 'image' => 'assets/images/options/q3_opt5.svg'],
                ['id' => 6, 'text' => 'Sunshine Yellow', 'emoji' => '🌻', 'image' => 'assets/images/options/q3_opt6.svg'],
                ['id' => 7, 'text' => 'Warm Peach / Coral', 'emoji' => '🍑', 'image' => 'assets/images/options/q3_opt7.svg'],
                ['id' => 8, 'text' => 'Warm White / Cream', 'emoji' => '🤍', 'image' => 'assets/images/options/q3_opt8.svg'],
            ]
        ],
        [
            'id' => 4,
            'question_text' => 'Where would I love to go on our dream date? ☕',
            'category' => 'dates',
            'options' => [
                ['id' => 1, 'text' => 'Cozy café with sweet desserts', 'emoji' => '🧁', 'image' => 'assets/images/options/q4_opt1.svg'],
                ['id' => 2, 'text' => 'Late night drive & street food', 'emoji' => '🚗', 'image' => 'assets/images/options/q4_opt2.svg'],
                ['id' => 3, 'text' => 'Cuddling at home watching movies', 'emoji' => '🛋️', 'image' => 'assets/images/options/q4_opt3.svg'],
                ['id' => 4, 'text' => 'Sunset beach walk holding hands', 'emoji' => '🌅', 'image' => 'assets/images/options/q4_opt4.svg'],
                ['id' => 5, 'text' => 'Fancy candlelit dinner', 'emoji' => '🕯️', 'image' => 'assets/images/options/q4_opt5.svg'],
                ['id' => 6, 'text' => 'Amusement park & rollercoasters', 'emoji' => '🎡', 'image' => 'assets/images/options/q4_opt6.svg'],
                ['id' => 7, 'text' => 'Stargazing picnic in the park', 'emoji' => '⛺', 'image' => 'assets/images/options/q4_opt7.svg'],
                ['id' => 8, 'text' => 'Arcade games & photo booths', 'emoji' => '🕹️', 'image' => 'assets/images/options/q4_opt8.svg'],
            ]
        ],
        [
            'id' => 5,
            'question_text' => 'What makes me angry or moody easily? 😤',
            'category' => 'habits',
            'options' => [
                ['id' => 1, 'text' => 'When I am hungry (Hangry)', 'emoji' => '🍔', 'image' => 'assets/images/options/q5_opt1.svg'],
                ['id' => 2, 'text' => 'Slow replies or being ignored', 'emoji' => '📵', 'image' => 'assets/images/options/q5_opt2.svg'],
                ['id' => 3, 'text' => 'Waking me up from sweet sleep', 'emoji' => '😴', 'image' => 'assets/images/options/q5_opt3.svg'],
                ['id' => 4, 'text' => 'Cancelled plans at the last minute', 'emoji' => '🗓️', 'image' => 'assets/images/options/q5_opt4.svg'],
                ['id' => 5, 'text' => 'Lies or hiding secrets', 'emoji' => '🙅', 'image' => 'assets/images/options/q5_opt5.svg'],
                ['id' => 6, 'text' => 'Hot sweating weather', 'emoji' => '🥵', 'image' => 'assets/images/options/q5_opt6.svg'],
                ['id' => 7, 'text' => 'Slow lagging Wi-Fi connection', 'emoji' => '📶', 'image' => 'assets/images/options/q5_opt7.svg'],
                ['id' => 8, 'text' => 'When someone steals my food', 'emoji' => '🍟', 'image' => 'assets/images/options/q5_opt8.svg'],
            ]
        ],
        [
            'id' => 6,
            'question_text' => 'What makes me happy instantly? 🧸',
            'category' => 'joy',
            'options' => [
                ['id' => 1, 'text' => 'Tasty snacks & Boba tea', 'emoji' => '🧋', 'image' => 'assets/images/options/q6_opt1.svg'],
                ['id' => 2, 'text' => 'Warm tight hugs from you', 'emoji' => '🫂', 'image' => 'assets/images/options/q6_opt2.svg'],
                ['id' => 3, 'text' => 'Surprise cute gifts or flowers', 'emoji' => '💐', 'image' => 'assets/images/options/q6_opt3.svg'],
                ['id' => 4, 'text' => 'Unplanned cuddles & nap time', 'emoji' => '🛌', 'image' => 'assets/images/options/q6_opt4.svg'],
                ['id' => 5, 'text' => 'A sweet heartfelt compliment', 'emoji' => '🥰', 'image' => 'assets/images/options/q6_opt5.svg'],
                ['id' => 6, 'text' => 'Spontaneous shopping trip', 'emoji' => '🛍️', 'image' => 'assets/images/options/q6_opt6.svg'],
                ['id' => 7, 'text' => 'Listening to my comfort song', 'emoji' => '🎶', 'image' => 'assets/images/options/q6_opt7.svg'],
                ['id' => 8, 'text' => 'Receiving a cute love text', 'emoji' => '💌', 'image' => 'assets/images/options/q6_opt8.svg'],
            ]
        ],
        [
            'id' => 7,
            'question_text' => 'What is my ultimate dream vacation? 🏖️',
            'category' => 'travel',
            'options' => [
                ['id' => 1, 'text' => 'Tropical beach resort in Maldives', 'emoji' => '🏝️', 'image' => 'assets/images/options/q7_opt1.svg'],
                ['id' => 2, 'text' => 'Tokyo, Japan (Anime & food)', 'emoji' => '🗼', 'image' => 'assets/images/options/q7_opt2.svg'],
                ['id' => 3, 'text' => 'Romantic Paris streets', 'emoji' => '🥐', 'image' => 'assets/images/options/q7_opt3.svg'],
                ['id' => 4, 'text' => 'Snowy cabin in Switzerland', 'emoji' => '🏔️', 'image' => 'assets/images/options/q7_opt4.svg'],
                ['id' => 5, 'text' => 'Disney World & fairy castles', 'emoji' => '🏰', 'image' => 'assets/images/options/q7_opt5.svg'],
                ['id' => 6, 'text' => 'Bali tropical island hopping', 'emoji' => '🥥', 'image' => 'assets/images/options/q7_opt6.svg'],
                ['id' => 7, 'text' => 'New York City skyline lights', 'emoji' => '🏙️', 'image' => 'assets/images/options/q7_opt7.svg'],
                ['id' => 8, 'text' => 'Cozy camper van road trip', 'emoji' => '🚐', 'image' => 'assets/images/options/q7_opt8.svg'],
            ]
        ],
        [
            'id' => 8,
            'question_text' => 'What is my biggest comfort food / guilty pleasure? 🍜',
            'category' => 'food',
            'options' => [
                ['id' => 1, 'text' => 'Hot spicy ramen / Maggie', 'emoji' => '🍜', 'image' => 'assets/images/options/q8_opt1.svg'],
                ['id' => 2, 'text' => 'Extra cheesy loaded pizza', 'emoji' => '🍕', 'image' => 'assets/images/options/q8_opt2.svg'],
                ['id' => 3, 'text' => 'Chocolate ice cream tub', 'emoji' => '🍨', 'image' => 'assets/images/options/q8_opt3.svg'],
                ['id' => 4, 'text' => 'Crunchy potato chips', 'emoji' => '🥔', 'image' => 'assets/images/options/q8_opt4.svg'],
                ['id' => 5, 'text' => 'Sweet glazed donuts', 'emoji' => '🍩', 'image' => 'assets/images/options/q8_opt5.svg'],
                ['id' => 6, 'text' => 'Crispy fried chicken', 'emoji' => '🍗', 'image' => 'assets/images/options/q8_opt6.svg'],
                ['id' => 7, 'text' => 'Fluffy pancakes with syrup', 'emoji' => '🥞', 'image' => 'assets/images/options/q8_opt7.svg'],
                ['id' => 8, 'text' => 'Warm chocolate chip cookies', 'emoji' => '🍪', 'image' => 'assets/images/options/q8_opt8.svg'],
            ]
        ],
        [
            'id' => 9,
            'question_text' => 'What is my favourite way to spend time with you? 💕',
            'category' => 'dates',
            'options' => [
                ['id' => 1, 'text' => 'Talking for hours about everything', 'emoji' => '🗣️', 'image' => 'assets/images/options/q9_opt1.svg'],
                ['id' => 2, 'text' => 'Silent comfortable cuddles', 'emoji' => '🛋️', 'image' => 'assets/images/options/q9_opt2.svg'],
                ['id' => 3, 'text' => 'Going out street-food hunting', 'emoji' => '🌮', 'image' => 'assets/images/options/q9_opt3.svg'],
                ['id' => 4, 'text' => 'Playful teasing and laughing', 'emoji' => '🤭', 'image' => 'assets/images/options/q9_opt4.svg'],
                ['id' => 5, 'text' => 'Long late-night car drives', 'emoji' => '🚗', 'image' => 'assets/images/options/q9_opt5.svg'],
                ['id' => 6, 'text' => 'Watching shows under warm blankets', 'emoji' => '🎬', 'image' => 'assets/images/options/q9_opt6.svg'],
                ['id' => 7, 'text' => 'Taking goofy cute selfies', 'emoji' => '📸', 'image' => 'assets/images/options/q9_opt7.svg'],
                ['id' => 8, 'text' => 'Playing games together', 'emoji' => '🎮', 'image' => 'assets/images/options/q9_opt8.svg'],
            ]
        ],
        [
            'id' => 10,
            'question_text' => 'What gift would make me the happiest? 🎁',
            'category' => 'gifts',
            'options' => [
                ['id' => 1, 'text' => 'A giant fluffy plush teddy bear', 'emoji' => '🧸', 'image' => 'assets/images/options/q10_opt1.svg'],
                ['id' => 2, 'text' => 'A handwritten love letter', 'emoji' => '💌', 'image' => 'assets/images/options/q10_opt2.svg'],
                ['id' => 3, 'text' => 'Pretty cute necklace or ring', 'emoji' => '💍', 'image' => 'assets/images/options/q10_opt3.svg'],
                ['id' => 4, 'text' => 'My favourite fragrance / perfume', 'emoji' => '🌸', 'image' => 'assets/images/options/q10_opt4.svg'],
                ['id' => 5, 'text' => 'Treating me to a luxury dinner', 'emoji' => '🍽️', 'image' => 'assets/images/options/q10_opt5.svg'],
                ['id' => 6, 'text' => 'Cozy oversized hoodie', 'emoji' => '🧥', 'image' => 'assets/images/options/q10_opt6.svg'],
                ['id' => 7, 'text' => 'Surprise trip or concert tickets', 'emoji' => '🎟️', 'image' => 'assets/images/options/q10_opt7.svg'],
                ['id' => 8, 'text' => 'Handmade memory scrapbook', 'emoji' => '📖', 'image' => 'assets/images/options/q10_opt8.svg'],
            ]
        ]
    ];
}

/**
 * Returns the question pool — from admin-edited JSON override if available,
 * otherwise falls back to the hardcoded defaults above.
 */
function getMasterQuestionPool(): array {
    $overridePath = __DIR__ . '/../config/question_pool.json';
    if (file_exists($overridePath)) {
        $json = file_get_contents($overridePath);
        if ($json !== false) {
            $pool = json_decode($json, true);
            if (is_array($pool) && count($pool) === 10) {
                return $pool;
            }
        }
    }
    return getDefaultQuestionPool();
}

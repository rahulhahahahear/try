<?php
/**
 * Test of Bubu 💗 - Security and Sanitization Utilities
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Send standard security headers
 */
function sendSecurityHeaders(): void {
    if (headers_sent()) {
        return;
    }
    header("X-Content-Type-Options: nosniff");
    header("X-Frame-Options: SAMEORIGIN");
    header("X-XSS-Protection: 1; mode=block");
    header("Referrer-Policy: strict-origin-when-cross-origin");
}

/**
 * HTML Escaping helper
 */
function e(?string $string): string {
    if ($string === null) {
        return '';
    }
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Generate cryptographically secure random public code (alphanumeric, friendly)
 */
function generatePublicCode(int $length = 10): string {
    // Exclude confusing characters like 0, O, 1, l, I
    $chars = '23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
    $charsLen = strlen($chars);
    $code = '';
    $bytes = random_bytes($length);
    for ($i = 0; $i < $length; $i++) {
        $code .= $chars[ord($bytes[$i]) % $charsLen];
    }
    return $code;
}

/**
 * Generate 32-character random token (for creator management and attempt idempotency)
 */
function generateToken(int $bytes = 24): string {
    return bin2hex(random_bytes($bytes));
}

/**
 * Hash creator token using SHA-256 for database lookup
 */
function hashCreatorToken(string $token): string {
    return hash('sha256', trim($token));
}

/**
 * Verify creator token hash
 */
function verifyCreatorToken(string $token, string $hash): bool {
    return hash_equals($hash, hashCreatorToken($token));
}

/**
 * Get or generate CSRF token
 */
function getCsrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 */
function verifyCsrfToken(?string $token): bool {
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Simple rate limiter per session/IP
 */
function checkRateLimit(string $action = 'general', int $maxAttempts = 15, int $decaySeconds = 60): bool {
    $now = time();
    $key = 'rate_' . $action;

    if (!isset($_SESSION[$key])) {
        $_SESSION[$key] = [
            'count' => 1,
            'start' => $now
        ];
        return true;
    }

    if ($now - $_SESSION[$key]['start'] > $decaySeconds) {
        $_SESSION[$key] = [
            'count' => 1,
            'start' => $now
        ];
        return true;
    }

    $_SESSION[$key]['count']++;

    return $_SESSION[$key]['count'] <= $maxAttempts;
}

/**
 * Validate and safely save uploaded image file
 * Returns array ['success' => bool, 'path' => string|null, 'error' => string|null]
 */
function handleImageUpload(array $file): array {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'error' => 'Upload error code: ' . $file['error']];
    }

    if ($file['size'] > MAX_UPLOAD_SIZE) {
        return ['success' => false, 'error' => 'Image size exceeds maximum limit of 2 MB.'];
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ALLOWED_IMAGE_EXTS, true)) {
        return ['success' => false, 'error' => 'Only JPG, PNG, and WebP images are allowed.'];
    }

    // Verify MIME type using fileinfo
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if (!in_array($mime, ALLOWED_IMAGE_TYPES, true)) {
        return ['success' => false, 'error' => 'Invalid image content type (' . $mime . ').'];
    }

    // Verify it is a valid image using getimagesize
    $imageInfo = @getimagesize($file['tmp_name']);
    if ($imageInfo === false) {
        return ['success' => false, 'error' => 'The uploaded file is not a valid image.'];
    }

    // Ensure uploads directory exists
    if (!is_dir(UPLOAD_DIR)) {
        @mkdir(UPLOAD_DIR, 0755, true);
    }

    // Generate safe unique filename
    $safeName = 'opt_' . bin2hex(random_bytes(10)) . '.' . $ext;
    $targetPath = UPLOAD_DIR . '/' . $safeName;

    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        return ['success' => false, 'error' => 'Failed to save uploaded file.'];
    }

    // Relative path for database and web access
    $webPath = 'assets/uploads/' . $safeName;
    return ['success' => true, 'path' => $webPath];
}

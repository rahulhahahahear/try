<?php
/**
 * Test of Bubu 💗 - Expired Quiz Notice
 */

$pageTitle = 'Quiz Expired 🫠 | ' . APP_NAME;
$pageDesc  = 'This Bubu quiz link has expired and melted away.';
require_once __DIR__ . '/includes/header.php';
?>

<div class="container" style="max-width: 540px; padding-top: 3.5rem; text-align: center;">
    <div class="card" style="padding: 2.5rem 1.5rem;">
        <div style="width: 170px; height: 170px; margin: 0 auto 1.5rem;">
            <picture>
                <source srcset="<?= BASE_URL ?>/assets/images/bubu-sad.webp" type="image/webp">
                <img src="<?= BASE_URL ?>/assets/images/bubu-sad.png" alt="Sad cute bear with broken heart" class="wiggle-gentle" style="width: 100%; height: 100%; object-fit: contain;">
            </picture>
        </div>

        <span class="badge badge-pink" style="margin-bottom: 0.5rem;">Time's Up ⏱️</span>
        <h2 style="font-family: var(--font-heading); font-size: 1.85rem; color: var(--text-dark); margin-bottom: 0.75rem;">
            Oops! This Bubu test has melted away. 🫠💗
        </h2>

        <p style="color: var(--text-muted); font-size: 1.05rem; margin-bottom: 2rem; line-height: 1.6;">
            Quiz links automatically expire after their scheduled time to protect your privacy and keep memories cozy. Ask your person to make a fresh one!
        </p>

        <div style="display: flex; flex-direction: column; gap: 0.75rem; max-width: 320px; margin: 0 auto;">
            <a href="<?= BASE_URL ?>/create.php" class="btn btn-primary btn-lg">
                <span>💕</span> Create a New Quiz
            </a>
            <a href="<?= BASE_URL ?>/" class="btn btn-secondary">
                <span>🏠</span> Return Home
            </a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
